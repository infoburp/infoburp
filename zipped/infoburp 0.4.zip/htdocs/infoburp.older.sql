-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 26, 2012 at 03:08 AM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `infoburp`
--

-- --------------------------------------------------------

--
-- Table structure for table `links`
--

CREATE TABLE IF NOT EXISTS `links` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `parent` bigint(20) NOT NULL,
  `child` bigint(20) NOT NULL,
  `whuffie` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `links`
--

INSERT INTO `links` (`id`, `parent`, `child`, `whuffie`) VALUES
(1, 0, 9, 2),
(2, 0, 10, 4),
(3, 0, 11, 8),
(4, 11, 12, 16),
(5, 11, 13, 32),
(6, 12, 14, 0),
(7, 12, 15, 0),
(8, 12, 16, 0),
(11, 0, 25, 1);

-- --------------------------------------------------------

--
-- Table structure for table `nodes`
--

CREATE TABLE IF NOT EXISTS `nodes` (
  `html` longtext,
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `whuffie` int(2) NOT NULL,
  `x` varchar(10) NOT NULL,
  `y` varchar(10) NOT NULL,
  `type` varchar(10) NOT NULL DEFAULT 'text',
  UNIQUE KEY `Sequence_UNIQUE` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `nodes`
--

INSERT INTO `nodes` (`html`, `id`, `whuffie`, `x`, `y`, `type`) VALUES
('infoburp.com', 0, 64, '0', '0', 'text'),
('test', 9, 4, '34.9904933', '0', 'text'),
('test2', 10, 8, '2.26501446', '36.9904933', 'text'),
('test3', 11, 16, '-88.990493', '1.08981922', 'text'),
('bbbbb', 12, 32, '12.2788745', '-76', 'text'),
('test578 test578', 13, 64, '-74.278874', '-76', 'text'),
('test', 14, 32, '43.3990621', '-76', 'text'),
('test', 15, 32, '-3.6995310', '-48.807614', 'text'),
('testetsetsetsetsetsetsetsetset', 16, 16, '0.30046894', '-96.264182', 'text'),
('', 25, 1, '-6.1521038', '-33.490493', 'text');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
