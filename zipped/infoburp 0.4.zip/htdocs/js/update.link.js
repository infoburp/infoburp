IB.update.link = function(link, parent, child){
	var zoom = IB.config.screen.zoom;
	var px = parent.x;
	var py = parent.y;
	var x = child.x;
	var y = child.y;
	var sw = IB.update.calc((child.whuffie+parent.whuffie)/2, IB.config.node.strokeWidth);
	sw = sw;
	px *= zoom;
	py *= zoom;
	x *= zoom;
	y *= zoom;
	sw *= zoom;
	link._.attr('path', 'M'+px+','+py+'L'+x+','+y)
		.attr('stroke-width',sw);
}



IB.update.linkSpringOld = function(node){
	if(node.id){
		//run spring
		var sibsVectorX = 0;
		var sibsVectorY = 0;
		var sibs = IB.node.siblings(node.id);
		for(var i in sibs){
			var sib = sibs[i];
			var sVectorX = sib.x - node.x;
			var sVectorY = sib.y - node.y;
			sibsVectorX += sVectorX;
			sibsVectorY += sVectorY;
		}

		var vectorX = sibsVectorX - node.x;
		var vectorY = sibsVectorY - node.y;
		var i = bods.i[node.id];
		var m = bods.mass[i];
		var kg = m*9.8;
		var vx = bods.vel.x[i];
		var vy = bods.vel.y[i];
		var xX = 1;
		var yX = 1;
		//calculate displacement
		//kg·m/s2 = -(kg/s2)*x
		var forceX = -(kg/(vectorX*vectorX))*xX;
		var forceY = -(kg/(vectorY*vectorY))*yX;
		//calculate the effect this force has on the mass of the node
		//Force = Mass * Acceleration 
		//acceleration = force / mass
		var accelerationX = forceX / m
		var accelerationY = forceY / m;
		//and finally add this effect to the x,y of the node
		bods.vel.x[i] += accelerationX;
		bods.vel.y[i] += accelerationY;
	}
}


IB.update.linkSpring = function(node){
	if(node.id){
		// run spring
		var sibs = IB.node.siblings(node.id);
		for(var i in sibs){
			// sibling
			var sib = sibs[i];
			// vector from sibling to node
			var vectorX = sib.x - node.x;
			var vectorY = sib.y - node.y;
			var slope = vectorY/vectorX;
			var magnitude = Math.sqrt(vectorX*vectorX+vectorY*vectorY);
			var radius = 200;
			var exceed = radius - magnitude;
			var i = bods.i[node.id];
			if(magnitude>=radius){
				var springFactor = .001;
				var velX = bods.vel.x[i];
				var velY = bods.vel.y[i];
				var vel = Math.sqrt(velX*velX+velY*velY);
				var tempSpringX = (bods.vel.x[i]+((vectorX*springFactor*vel)));
				var tempSpringY = (bods.vel.y[i]+((vectorY*springFactor*vel)));
				bods.vel.x[i] = tempSpringX;
				bods.vel.y[i] = tempSpringY;
			} else {}
		}
	}
}