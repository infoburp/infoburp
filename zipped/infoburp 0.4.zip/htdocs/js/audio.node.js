//code defining an audio node, a node containing audio which may often be a soundtrack linked
//to a video node.
