//take music as input, for example a midi input port
