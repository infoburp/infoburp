//connect to a git repository, push and pull project files.
//uses socket.io