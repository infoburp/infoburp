//code defining a video node, which contains video content only, typically linked to
//it's soundtrack which is in an audio node.
