//take keyboard input
