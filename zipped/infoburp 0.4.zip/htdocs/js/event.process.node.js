[Constructor]
interface WebCLEvent {
    readonly attribute CLenum status;
    readonly attribute WebCLMemoryObject buffer;
    
    any   getInfo(CLenum name);
    any   getProfilingInfo(CLenum name);
    void  setUserEventStatus(CLenum executionStatus);
    void  setCallback(CLenum executionStatus, WebCLCallback notify, optional any userdata);
};