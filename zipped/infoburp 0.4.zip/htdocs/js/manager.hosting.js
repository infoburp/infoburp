//manage hosting according to cost and demand

//from different hosts

//infoburp ambient cloud 	- free

//amazon ec2 			- paid

//google compute engine 	- paid

//storm on demand 		- paid (with ssds)

//peer 1 hpc cloud		- paid (with gpus)
//http://www.peer1hosting.co.uk/cloud-hosting/high-performance-cloud-computing/key-features 

//having these different hosts gives us protection if an entire cloud goes down.




