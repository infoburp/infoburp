//ping a remote machine.node using socket.io

function socket = io.ping('remote.machine.node');
  socket.on('news', function (data) {
    console.log(data);
    socket.emit('my other event', { my: 'data' });
  });
