//disconnect socket.io from a remote machine.node

var socket = io.disconnect('remoteurl');
  socket.on('news', function (data) {
    console.log(data);
    socket.emit('my other event', { my: 'data' });
  });
