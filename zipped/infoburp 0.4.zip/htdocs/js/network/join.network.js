//join a machine.node to the infoburp network using socket.io

var socket = io.join('remoteurl');
  socket.on('news', function (data) {
    console.log(data);
    socket.emit('my other event', { my: 'data' });
  });
