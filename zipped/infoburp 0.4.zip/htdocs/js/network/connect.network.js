//connect to a remote machine.node using socket.io

//fall back to plain http requests if socket is unavailable

if bestmethod.connect.network = socket.io 

	{
		
		function connect.network(remote.machine.node,socket.io)

			{

				var socket = io.connect('remote.machine.node');

  			}
	}
else
	{
		function connect.network(remote.machine.node,http)
		
			{	
							
			}
	
	}
