//tell socket.io to leave the infoburp network.

var socket = io.leave('remoteurl');
  socket.on('news', function (data) {
    console.log(data);
    socket.emit('my other event', { my: 'data' });
  });
