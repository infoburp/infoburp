//reconnect using socket.io

var socket = io.reconnect('remoteurl');
  socket.on('news', function (data) {
    console.log(data);
    socket.emit('my other event', { my: 'data' });
  });
