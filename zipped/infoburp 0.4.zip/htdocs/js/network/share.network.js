//provide access to, and maintain communication with a decentralised network
//sharing open source software content and ideas.

//http://socket.io/#faq
//uses socket.io

//distributed and decentralised, based on node/link network graph structure.

	//no single point of failure