IB.e.keys = {
	register: {},
	_keys: [],

	_map: {
		187: function(){
			IB.e.zoom(1);
		},
		189: function(){
			IB.e.zoom(-1);
		},
		37: function(){
			IB.e.moveX(10);
		},
		39: function(){
			IB.e.moveX(-10);
		},
		38: function(){
			IB.e.moveY(10);
		},
		40: function(){
			IB.e.moveY(-10);
		},
		13: function(){
			IB.e.startEditing();
		}
	},

	map: function(){
		for(var key in IB.e.keys._keys){
			var on = IB.e.keys._keys[key];
			if(on){
				if(IB.e.keys._map[key]){
					IB.e.keys._map[key]();
				}
			}
		}
	},
	
	down: function(e){
		e = e.which?e.which:e.keyCode;
		IB.e.keys._keys[e] = 1;
	},
	up: function(e){
		e = e.which?e.which:e.keyCode;
		IB.e.keys._keys[e] = 0;
	},
}