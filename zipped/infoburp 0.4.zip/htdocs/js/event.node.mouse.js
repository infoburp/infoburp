IB.e.node.mouse = {
	down: function(e, __html){
		e.stopPropagation();
		var node = IB.node.get($(__html).attr('IB_Id'));
		IB.e.node.startDragging();
		IB.e.node.select(e, node);
		return false;
	},
	up: function(e, __html){
		e.stopPropagation();
		var node = IB.node.get($(__html).attr('IB_Id'));
		IB.e.node.stopDragging();
		return false;
	},
	click: function(e, __html){
		e.stopPropagation();
		var node = IB.node.get($(__html).attr('IB_Id'));
		IB.e.node.clicking = 1;
		window.setTimeout(function(){
			if(IB.e.node.clicking){
				IB.e.node.stopDragging();
				IB.e.node.startEditing();
			}
		}, 500);
		return false;
	},
	edit:{
		save:{
			up:function(){

			},
			down:function(){
				
			}
		},
		cancel:{
			up:function(){

			},
			down:function(){
				
			}
		},
	},
	vote:{
		up:{
			up:function(){

			},
			down:function(){
				
			}
		},
		down:{
			up:function(){

			},
			down:function(){
				
			}
		},
	},
};