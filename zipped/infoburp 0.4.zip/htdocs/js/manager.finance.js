//calculate overall profit/loss

	//profit - advertising

	//profit - sale of whuffie

	//profit - commission

	//loss - programmer wages

	//loss - hosting costs

	//loss - other costs


