//http://en.wikipedia.org/wiki/Quorum_(distributed_computing)

