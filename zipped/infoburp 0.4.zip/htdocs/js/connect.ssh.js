//connect to a remote secure shell
