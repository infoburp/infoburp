IB.config = {
	//configure how the interface looks
	node: {
		fillColor: 'white',
		strokeColor: 'green',
		dragLineColor: '#FF7E00',
		strokeColorEditing: '#FF7E00',
		strokeWidth: .15,
		padding: 10,
		textAdjust: 1,
		attraction: {
			"coloumb":4000,
			"attraction":4,
			"jiggle":0.001,
			"dumping":.08,
			"tu":0.1,
			"X_MIN":20,
			"X_MAX":1000,
			"Y_MIN":20,
			"Y_MAX":1000
		},
		repulsion: {
			"coloumb":4000,
			"attraction":-.000004,
			"jiggle":0.001,
			"dumping":.08,
			"tu":0.1,
			"X_MIN":20,
			"X_MAX":1000,
			"Y_MIN":20,
			"Y_MAX":1000
		}
	},
	//configure the x,y,w,h,zoom
	screen: {
		x: 0,
		y: 0,
		w: null,
		h: null,
		zoom: 3
	},
};
