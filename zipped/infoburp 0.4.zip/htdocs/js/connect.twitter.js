//if user logs in with twitter id

//allow them to tweet any node

