//take audio input
