//when I add a node containing 
//<upload:path>
//the file is fetched and uploaded as the node content. if the path is a folder, all files in that path are uploaded.
//possibly use ocupload for this
