/*is a set of link effects, each with a direction and magnitude
we just need to combine these to form a resultant vector
so if you had a pool ball and pushed it in the directions and
 amounts set by the links, the resultant vector is the direction and speed
 it would travel
*/

resultvector = avg(linkvector);

resultvelocity = (barnes - hookes);

//................attraction
IB.update.nodeAttract = function(node1, node2){
	var P = IB.config.node.attraction;

	//nodes attract along link lines according to hookes law
	var xpDiff = node2.x-node1.x;
	var ypDiff = node2.y-node1.y;
	var xsign=xpDiff/Math.abs(xpDiff);
	var ysign=ypDiff/Math.abs(ypDiff);
	if (isNaN(xsign)) xsign=1;
	if (isNaN(ysign)) ysign=1;
	
	var Exceed = -(Math.sqrt(xpDiff*xpDiff+ypDiff*ypDiff))*P.attraction*node1.whuffie*node2.whuffie;
	
	var xExceed=xsign*Exceed;
	var yExceed=ysign*Exceed;
	var xpSpeed= P.dumping*(node2.xspeed+xExceed*P.tu);
	var ypSpeed= P.dumping*(node2.yspeed+yExceed*P.tu);
	var xInertion = xpSpeed*P.tu  + parseInt(xsign*xExceed)*P.tu*P.tu/2;
	var yInertion = ypSpeed*P.tu  + parseInt(ysign*yExceed)*P.tu*P.tu/2;
	if (isNaN(xInertion)) xInertion=0;
	if (isNaN(yInertion)) yInertion=0;
	
	node2.x += xInertion ; 
	node2.y += yInertion ; 
}