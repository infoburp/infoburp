IB.update.nodePosition = function(node1, node2){
	//................repulsion
	var P = IB.config.node.calc;

	if (!(node2.xspeed))node2.xspeed=0;
	if (!(node2.yspeed))node2.yspeed=0;
	
	node2.x = parseInt(node2.x);
	node2.y = parseInt(node2.y);
	node1.x = parseInt(node1.x);
	node1.y = parseInt(node1.y);
	var xDiff = (parseInt(node1.x)-parseInt(node2.x));
	var yDiff = (parseInt(node1.y)-parseInt(node2.y));

	var xsign=xDiff/Math.abs(xDiff);
	var ysign=yDiff/Math.abs(yDiff);
	if (isNaN(xsign)) xsign=1;
	if (isNaN(ysign)) ysign=1;

	var distance_squared = Math.sqrt(xDiff*xDiff+yDiff*yDiff);
	if (distance_squared<2) distance_squared=1;				
	var coloumb_like =-P.coloumb/distance_squared*node2.totalWhuffie*node1.totalWhuffie;

	var repulsion=coloumb_like;
	var xSpeed = P.dumping*(node2.xspeed + parseInt(repulsion*xsign)*P.tu);
	var ySpeed = P.dumping*( node2.yspeed + parseInt(repulsion*ysign)*P.tu);
	var temp_x=parseInt(node2.x)+ xSpeed*P.tu  + parseInt(repulsion*xsign)*P.tu*P.tu/2;
	var temp_y=parseInt(node2.y) +ySpeed*P.tu  + parseInt(repulsion*ysign)*P.tu*P.tu/2;

	
    if (isNaN(temp_x)) temp_x=P.X_MIN;
    if (temp_x>P.X_MAX) temp_x=P.X_MAX;
    if (isNaN(temp_y))temp_y=P.Y_MIN;
    if (temp_y>P.Y_MAX) temp_y=P.Y_MAX;
	
	node2.x = temp_x;
	node2.y = temp_y;
    if (node1.id!=0){
		var rerepulsion=-coloumb_like;
		var xnSpeed =  P.dumping*(node1.xspeed + parseInt(rerepulsion)*P.tu);
		var ynSpeed = P.dumping*( node1.yspeed + parseInt(rerepulsion)*P.tu);
		temp_x=parseInt(node1.x)+ xSpeed*P.tu  + parseInt(rerepulsion*xsign)*P.tu*P.tu/2;
		temp_y=parseInt(node1.y) +ySpeed*P.tu  + parseInt(rerepulsion*ysign)*P.tu*P.tu/2;
		
	    if (isNaN(temp_x)) temp_x=P.X_MIN;
	    if (temp_x>P.X_MAX) temp_x=P.X_MAX;
	    if (isNaN(temp_y))temp_y=P.Y_MIN;
	    if (temp_y>P.Y_MAX) temp_y=P.Y_MAX;

		node1.x = temp_x;
		node1.y = temp_y;
	}
	
	//childs attract along link lines
	var xpDiff = node2.x-node1.x;
	var ypDiff = node2.y-node1.y;
	
	var xsign=xpDiff/Math.abs(xpDiff);
	var ysign=ypDiff/Math.abs(ypDiff);
	if (isNaN(xsign)) xsign=1;
	if (isNaN(ysign)) ysign=1;
	
	var Exceed = -(Math.sqrt(xpDiff*xpDiff+ypDiff*ypDiff))*P.attraction*node1.whuffie*node2.whuffie;
	
	var xExceed=xsign*Exceed;
	var yExceed=ysign*Exceed;
	var xpSpeed= P.dumping*(node2.xspeed+xExceed*P.tu);
	var ypSpeed= P.dumping*(node2.yspeed+yExceed*P.tu);
	var xInertion = xpSpeed*P.tu  + parseInt(xsign*xExceed)*P.tu*P.tu/2;
	var yInertion = ypSpeed*P.tu  + parseInt(ysign*yExceed)*P.tu*P.tu/2;
	node2.x = node2.x + xInertion ; 
	node2.y = node2.y + yInertion ; 
}

IB.update.node = function(node){
	var zoom = IB.config.screen.zoom;
	var x = node.x-node.whuffie/4;
	var y = node.y-node.whuffie/4;
	var w = node.whuffie/2;
	var h = node.whuffie/2;
	var r = (w+h)/4;
	var childrenWhuffie = IB.node.childrenWhuffie(node);
	var children = IB.node.children(node);
	var childrenAverageWhuffie = 1;
	if(children.length)childrenAverageWhuffie = childrenWhuffie/children.length;
	var sw = IB.update.calc(node.whuffie/childrenAverageWhuffie, IB.config.node.strokeWidth);
	x *= zoom;
	y *= zoom;
	w *= zoom;
	h *= zoom;
	r *= zoom;
	sw *= zoom;
	node._.attr('x', x)
		.attr('y', y)
		.attr('width', w)
		.attr('height', h)
		.attr('r', r)
		.attr('stroke-width',sw);
}

IB.update.nodeHtml = function(node){
	var zoom = IB.config.screen.zoom;
	var x = node.x-node.whuffie/4;
	var y = node.y-node.whuffie/4;
	var cw = node.whuffie/2;
	var ch = node.whuffie/2;
	var rw = Math.sqrt(cw*cw/2);
	var rh = Math.sqrt(ch*ch/2);
	var rx = x+(cw-rw)/2;
	var ry = y+(ch-rh)/2;
	var childrenWhuffie = IB.node.childrenWhuffie(node);
	var children = IB.node.children(node);
	var childrenAverageWhuffie = 1;
	if(children.length)childrenAverageWhuffie = childrenWhuffie/children.length;
	var sw = IB.update.calc(node.whuffie/childrenAverageWhuffie, IB.config.node.strokeWidth);
	var fs = '';
	if(node.type=='text')fs = IB.update.calc((Math.pow((node.whuffie/2),2)/node.html.length), IB.config.node.textAdjust);
	var lh = fs/10;
	var lines =(Math.pow((node.whuffie/2),2)%node.html.length);
	lines = (lines>1)?(lines>1):2;
	var pt = (node.whuffie/2-(fs*lines));
	rx *= zoom;
	ry *= zoom;
	rw *= zoom;
	rh *= zoom;
	sw *= zoom;
	fs *= zoom;
	lh *= zoom;
	node._html.css('left', rx)
		.css('top', ry)
		.css('width', rw)
		.css('height', rh)
		.css('font-size', fs);
	node._html.find('.html').css('top', pt);
	node._html.find('.edit').css('borderWidth', sw);
	node._html.find('.vote').css('borderWidth', sw);
}

IB.update.nodePositions = function(node){
	IB.update.updateInstance++;
	IB.update.nodePositionsRecursive();
}
IB.update.nodePositionsRecursive = function(node){
	if(!node)node = IB.node.get(0);
	if(!node.updated || node.updated!=IB.update.updateInstance){
		node.updated = IB.update.updateInstance;
		IB.node.updateChildNodePositions(node);
	}
	var children = IB.node.children(node.id);
	for(var x in children){
		var child = children[x];
		IB.update.nodePositionsRecursive(child);
	}
}