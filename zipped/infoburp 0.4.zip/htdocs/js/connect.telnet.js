//connect to a remote shell
