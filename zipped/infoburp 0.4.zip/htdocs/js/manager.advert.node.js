//manager.advert.node.js
//manages the number of advert nodes visible to users to ensure profit after
//covering all costs

	//set desired profit per hour in GBP

		profit = 10;

	//get number of users

		usernum = IB.usernum;

	//get click rate

		clickrate = IB.clickrate;

	//get cpc

		cpc = IB.cpc;

	//calculate advertising revenue

		revenue = (usernum * clickrate) * cpc;

	//check costs

		cost = connect.amazon.hosting.get.cost

	//adjust hosting levels (cost), based on total(cost)

		if (cost > revenue)
			{
			//scale down the amazon cloud hosting, making the hosting cost go down
			connect.amazon.hosting.scale.down(1);
			//add an advert node
			advert.google.node.add(1)
			}
		if (revenue > (cost + profit)
			{
			//scale up the amazon cloud hosting, making the site core faster
			connect.amazon.hosting.scale.up(1);
			//remove an advert node
			advert.google.node.remove(1)
			}

	//check for and remove any advert nodes that do not give us revenue.

		check.advert.node();