//sell whuffie to other users or infoburp for products or services.
