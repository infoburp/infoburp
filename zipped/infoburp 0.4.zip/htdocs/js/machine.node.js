//a machine node is a computer attached to infoburp which:

//stores data - stores nodes, links and bubbles as files on the hard drive and in ram.

	//http://www.w3.org/TR/file-system-api/

//performs calculations on data using javascript run on the cpu and gpu.

	//http://www.khronos.org/webcl/

//freely shares all data and calculation results with the rest of infoburp.

	//http://socket.io/#faq

//distributed and decentralised, based on node/link network graph structure.

	//no single point of failure

//rather than being push/pull, data is stored as locally and as redundantly as possible
//and "flows" around the graph to meet spikes in demand for certain content, while
//providing consistant, delay tolerant service, even on poor quality connections.

	//takes as input
	//the address of a few known other machine nodes

machine.node0.address="www.infoburp.com"
machine.node1.address="www.prubofni.com"
machine.node2.address="10.0.0.2"

//checks for succesful connection to network

	network.init();

//once connected, bootstrap process begins

	//download a list of servers you can connect to, and add them to the machine.node list on disk.

		network.get.machine.node(list,disk);

	//download the root node(0) to disk

		network.get.rootnode(disk);

	//download the most popular nodes to disk

		network.get.hotnodes(disk);

	//bootstrap done

	//begin normal operation, store process and communicate to/for the rest of infoburp

		network.server.start(store,process,communicate)

//loop 
	{
	//download an available node from a remote machine.node, that the local machine.node
	//does not already have, and store on the disk.
		network.get.newnode(disk);
	//check if normal node or executable node
		if newnode.type = "1" then 
  			{
			//normal node - store(do nothing)
			}
			{
			//executable node - process then store
			executable.node.run(node,disk);
			}
	//upload an available node from storage to a remote machine.node
		network.upload(disk);
	}
//end loop





