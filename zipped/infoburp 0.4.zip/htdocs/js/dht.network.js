//code implementing the infoburp distributed hash table network

//the hashes are the locality sensitive hashes produced by hash.process.node.js

//http://en.wikipedia.org/wiki/Distributed_hash_table

