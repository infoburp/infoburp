interface WebCLMemoryObject : Transferable {
  any getInfo(CLenum name);
  WebCLGLObjectInfo getGLObjectInfo();
};