IB.e.node = {
	editing: false,
	dragging: false,
	
	startDragLine: function(e, node){
		if(IB.e.node.dragging){
			if(node.id==IB.e.node._selected.id && !IB.e.node.dragLine){
				//create new node
				var zoom = IB.config.screen.zoom;
				var sw = IB.update.calc((node.whuffie), IB.config.node.strokeWidth);
				sw *= zoom;
				var x1 = node.x*zoom;
				var y1 = node.y*zoom;
				var x2 = IB.e.mouse.x-IB.config.screen.w/2;
				var y2 = IB.e.mouse.y-IB.config.screen.h/2;
				IB.e.node.dragLine = IB._.path('M'+x1+','+y1+'L'+x2+','+y2+'')
					.attr('stroke',IB.config.node.dragLineColor)
					.attr('stroke-width',sw);
				IB.e.node.dragLine.toBack();
			}
		}
	},
	moveDragLine: function(e, node){
		if(IB.e.node.dragging){
			//create new node
			if(IB.e.node.dragLine){
				var zoom = IB.config.screen.zoom;
				var x1 = node.x*zoom;
				var y1 = node.y*zoom;
				var x2 = IB.e.mouse.x-IB.config.screen.w/2-IB.config.screen.x*zoom;
				var y2 = IB.e.mouse.y-IB.config.screen.h/2-IB.config.screen.y*zoom;
				IB.e.node.dragLine.attr('path','M'+x1+','+y1+'L'+x2+','+y2);
			}
		}
	},
	stopDragLine: function(e, node){
		if(IB.e.node.dragLine){
			IB.e.node.dragLine.remove();
			IB.e.node.dragLine = 0;
		}
	},
	createChild: function(e){
		if(IB.e.node.dragging){
			//create new node
			var zoom = IB.config.screen.zoom;
			var x = (IB.e.mouse.x-IB.config.screen.w/2-IB.config.screen.x)/zoom;
			var y = (IB.e.mouse.y-IB.config.screen.h/2-IB.config.screen.y)/zoom;
			IB.node.createChild(IB.e.node._selected, x, y);
			IB.config.screen.x = -x;
			IB.config.screen.y = -y;
		}
		IB.e.node.edit.save();
		IB.e.node.drag.stop(e);
		IB.e.node.unselect();
		IB.e.node.stopDragLine();
	},
	createLink: function(e, child){
		if(IB.e.node.dragging){
			//create new node
			if(IB.e.node._selected.id!=child.id){
				IB.node.createLink(IB.e.node._selected, child);
				IB.e.node.edit.save();
				IB.e.node.drag.stop(e);
				IB.e.node.unselect();
			}
		}
		IB.e.node.stopDragLine();
	},
	setCenter: function(e, __html){
		e.stopPropagation();
		e.preventDefault();
		var node = IB.node.get($(__html).attr('IB_Id'));
		IB.e.node.clicking = 0;
		IB.e.move2XY(-node.x, -node.y);
		return false;
	},
	select: function(e, node){
		e.stopPropagation(e);
		if(IB.e.node._selected != node){
			e.preventDefault();
			IB.e.node.unselect();
			IB.e.node._selected = node;
			IB.e.node._selected._html.addClass('selected');
			IB.e.node._selected._.attr('stroke', IB.config.node.strokeColorEditing);
		}
		return false;
	},
	drag:{
		start: function(e){
			e.preventDefault();
			e.stopPropagation();
			IB.e.node.dragging = 1;
			IB.__html.parent().addClass('creating');
			return false;
		},
		stop: function(e){
			e.preventDefault();
			e.stopPropagation();
			window.setTimeout(function(){
				IB.e.node.dragging = 0;
			}, 100);
			IB.__html.parent().removeClass('creating');
			return false;
		},
	},
	unselect: function(node){
		if(!node)node = IB.e.node._selected;
		IB.e.node.edit.stop();
		if(IB.e.node._selected){
			node._html.removeClass('selected');
			node._.attr('stroke', IB.config.node.strokeColor);
		}
		IB.e.node._selected = null;
	},
	edit:{
		start: function(e){
			if(IB.e.node._selected && !IB.e.node.editing){
				IB.e.node.editing = 1;
				var html = IB.e.node._selected.html;
				IB.e.node._selected._html.find('.textbox').val(html);
				IB.e.node._selected._html.addClass('editing');
				IB.e.node._selected._html.find('.html').hide();
				IB.e.node._selected._html.find('.textbox').focus();
			}
		},
		stop: function(e){
			if(e)e.stopPropagation();
			if(IB.e.node._selected){
				IB.e.node.editing = 0;
				IB.e.node._selected._html.removeClass('editing');
				IB.e.node._selected._html.find('.html').show();
			}
		},
		save: function(e){
			if(IB.e.node._selected){
				IB.e.node.edit.stop();
				var node = IB.e.node._selected;
				var val = node._html.find('.textbox').val();
				IB.action.save(node.id, val, function(success){
					IB.e.node.edit.stop();
					if(success){
						node.html = val;
						node._html.find('.html').html(val);
					}
				});
			}
		},
	},
	vote:{
		up: function(e){
			e.stopPropagation();
			var id = IB.e.node._selected.id;
			IB.action.voteUp(id);
		},
		down: function(e){
			e.stopPropagation();
			var id = IB.e.node._selected.id;
			IB.action.voteDown(id);
		}
	}
};