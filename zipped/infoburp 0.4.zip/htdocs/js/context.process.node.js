interface WebCLContext {

    WebCLBuffer createBuffer(CLenum memFlags, CLuint sizeInBytes, optional ArrayBuffer srcBuffer);

    WebCLCommandQueue createCommandQueue(optional WebCLDevice[]? devices, optional CLenum properties);

    WebCLBuffer createFromGLBuffer(CLenum memFlags, WebGLBuffer buffer);

    WebCLImage createFromGLRenderBuffer(CLenum memFlags, WebGLRenderbuffer renderbuffer);

    WebCLImage createFromGLTexture2D(CLenum memFlags, GLenum textureTarget, 
                                      GLint miplevel, WebGLTexture texture);

    WebCLImage createImage(CLenum memFlags, 
                           WebCLImageDescriptor descriptor,
                           optional ArrayBuffer srcBuffer);

    WebCLProgram createProgram(DOMString source);

    WebCLSampler createSampler(CLboolean normalizedCoords,
                               CLenum addressingMode,
                               CLenum filterMode);

    WebCLEvent createUserEvent();

    any getInfo(CLenum name);

    WebCLImageDescriptor[] getSupportedImageFormats(CLenum memFlags,
                                                    CLenum imageType);
};
dictionary WebCLImageDescriptor {
  CLenum channelOrder = 0x10B5;            // 0x10B5 == WebCL.RGBA
  CLenum channelType = 0x10D2;             // 0x10D2 == WebCL.UNORM_INT8, 8-bit colors normalized to [0, 1]
  CLuint width = 0, height = 0;
  CLuint rowPitch = 0;
};