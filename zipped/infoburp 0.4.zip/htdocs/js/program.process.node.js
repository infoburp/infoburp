interface WebCLProgram {
    any getInfo(CLenum name);

    any getBuildInfo(WebCLDevice device, CLenum name);

    void build(WebCLDevice[] devices, 
               DOMString? options, 
               optional WebCLCallback whenFinished,
               optional any userdata);

    WebCLKernel createKernel(DOMString kernelName);

    WebCLKernel[] createKernelsInProgram();
};