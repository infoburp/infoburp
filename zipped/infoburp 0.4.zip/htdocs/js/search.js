//search functions
//as a user types their query, zoom in on the nearest matching nodes, and highlight them.
//once they press return, zoom to matching node, or create a new node
//containing the search string.

IB.search = {
	__: $('#_search'),

	load: function(){
		IB.search.__ = $('#_search');
		IB.search.__.bind('keyup', function(e){
		//***change this to on press return
		//do a search
			IB.search.do();
		});
		IB.search.__.bind('focus', function(e){
			var value = IB.search.__.val();
			if(value=='search')$(this).val('');
		});
		IB.search.__.bind('blur', function(e){
			var value = IB.search.__.val();
			if(value=='')$(this).val('search');
		});
	},
	do: function(CB){
		if((typeof CB)!='function')CB = function(){};
		var value = IB.search.__.val();
		if(value!=''){
			IB.search.results(value, function(results){
				CB(results);
			});
		}
	},
	results: function(value, CB){
		$.ajax({
			url:'/action/action.php',
			data:{
				action:'search',
				value:value
			},
			success:function(results){
				CB(results);
			}
		})
	}
}