//read the node.html
//if it contains links to other urls, these urls are added as new nodes containing the urls
//linked to.
//in time these pages will be fetched, also.
