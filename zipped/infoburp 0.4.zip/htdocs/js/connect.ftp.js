//connect to a remote ftp server. upload and download files.
//uses socket.io