//update the positions of nodes
IB.update = {
	updateInstance: 0,

	load: function(){
		window.setInterval(function(){
			IB.update.nodeDetract();
			IB.update.loop();
			IB.update.view();
			IB.e.keys.map();
		}, 10);
	},
	
    loop: function(){
		for(var x in IB._nodes){
			var node = IB._nodes[x];
			IB.update.linkSpring(node);
			// update nodes
			IB.update.node(node);
			// update nodes html
			IB.update.nodeHtml(node);
		}
		for(var x in IB._links){
			var link = IB._links[x];
			var parent = IB.node.get(link.parent);
			var child = IB.node.get(link.child);
			// update links
			IB.update.link(link, parent, child);
		}
	},

	view: function(){
		var w = IB.config.screen.w;
		var h = IB.config.screen.h;
		var x = IB.config.screen.x;
		var y = IB.config.screen.y;
		var zoom = IB.config.screen.zoom;
		x = (x*zoom)+(w/2);
		y = (y*zoom)+(h/2);
		IB._.setViewBox(-x, -y, w, h);
		IB.__html.css('left', x);
		IB.__html.css('top', y);
	},

	calc: function(i, multiplier){
		if(!multiplier)multiplier = 1;
		return Math.log(i)*multiplier;
	}
};
