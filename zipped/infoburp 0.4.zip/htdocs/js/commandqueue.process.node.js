interface WebCLCommandQueue {

  ////////////////////////////////////////////////////////////////////////////
  //
  // Copying: Buffer <-> Buffer, Image <-> Image, Buffer <-> Image
  //

void enqueueCopyBuffer(
                    WebCLBuffer             srcBuffer,
                    WebCLBuffer             dstBuffer,
                    CLuint                  srcOffset,
                    CLuint                  dstOffset,
                    CLuint                  sizeInBytes, 
                    optional WebCLEvent[]?  eventWaitList,
                    optional WebCLEvent?    event);
                            
void enqueueCopyBufferRect(
                    WebCLBuffer             srcBuffer,
                    WebCLBuffer             dstBuffer, 
                    CLuint[3]               srcOrigin,
                    CLuint[3]               dstOrigin,
                    CLuint[3]               region, 
                    CLuint                  srcRowPitch,
                    CLuint                  srcSlicePitch,
                    CLuint                  dstRowPitch,
                    CLuint                  dstSlicePitch,
                    optional WebCLEvent[]?  eventWaitList,
                    optional WebCLEvent?    event);

void enqueueCopyImage(
                    WebCLImage              srcImage,
                    WebCLImage              dstImage, 
                    CLuint[3]               srcOrigin,
                    CLuint[3]               dstOrigin,
                    CLuint[3]               region, 
                    optional WebCLEvent[]?  eventWaitList,
                    optional WebCLEvent?    event);

void enqueueCopyImageToBuffer(
                    WebCLImage              srcImage,
                    WebCLBuffer             dstBuffer, 
                    CLuint[3]               srcOrigin,
                    CLuint[3]               region, 
                    CLuint                  dstOffset,
                    optional WebCLEvent[]?  eventWaitList,
                    optional WebCLEvent?    event);

void enqueueCopyBufferToImage(
                    WebCLBuffer             srcBuffer,
                    WebCLImage              dstImage, 
                    CLuint                  srcOffset,
                    CLuint[3]               dstOrigin,
                    CLuint[3]               region, 
                    optional WebCLEvent[]?  eventWaitList,
                    optional WebCLEvent?    event);

  ////////////////////////////////////////////////////////////////////////////
  //
  // Reading: Buffer -> Host, Image -> Host
  //

void enqueueReadBuffer(
                    WebCLBuffer             buffer,
                    CLboolean               blockingRead,
                    CLuint                  offset,
                    CLuint                  sizeInBytes, 
                    ArrayBuffer             ptr,
                    optional WebCLEvent[]?  eventWaitList, 
                    optional WebCLEvent?    event);
                            
void enqueueReadBufferRect(
                    WebCLBuffer             buffer,
                    CLboolean               blockingRead,
                    CLuint[3]               bufferOrigin,
                    CLuint[3]               hostOrigin, 
                    CLuint[3]               region,
                    CLuint                  bufferRowPitch,
                    CLuint                  bufferSlicePitch,
                    CLuint                  hostRowPitch,
                    CLuint                  hostSlicePitch,
                    ArrayBuffer             ptr,
                    optional WebCLEvent[]?  eventWaitList, 
                    optional WebCLEvent?    event);
  
void enqueueReadImage(
                    WebCLImage              image,
                    CLboolean               blockingRead, 
                    CLuint[3]               origin,
                    CLuint[3]               region,
                    CLuint                  rowPitch,
                    CLuint                  slicePitch, 
                    ArrayBuffer             ptr,
                    optional WebCLEvent[]?  eventWaitList,
                    optional WebCLEvent?    event);

  ////////////////////////////////////////////////////////////////////////////
  //
  // Writing: Host -> Buffer, Host -> Image
  //

void enqueueWriteBuffer(
                    WebCLBuffer             buffer,
                    CLboolean               blockingWrite, 
                    CLuint                  offset, 
                    CLuint                  sizeInBytes, 
                    ArrayBuffer             ptr,
                    optional WebCLEvent[]?  eventWaitList, 
                    optional WebCLEvent?    event);
                            
void enqueueWriteBufferRect(
                    WebCLBuffer             buffer,
                    CLboolean               blockingWrite,
                    CLuint[3]               bufferOrigin,
                    CLuint[3]               hostOrigin,
                    CLuint[3]               region,
                    CLuint                  bufferRowPitch,
                    CLuint                  bufferSlicePitch,
                    CLuint                  hostRowPitch,
                    CLuint                  hostSlicePitch,
                    ArrayBuffer             ptr,
                    optional WebCLEvent[]?  eventWaitList,
                    optional WebCLEvent?    event);
  
void enqueueWriteImage(
                    WebCLImage              image,
                    CLboolean               blockingWrite, 
                    CLuint[3]               origin,
                    CLuint[3]               region,
                    CLuint                  inputRowPitch,
                    CLuint                  inputSlicePitch, 
                    ArrayBuffer             ptr,
                    optional WebCLEvent[]?  eventWaitList,
                    optional WebCLEvent?    event);

  ////////////////////////////////////////////////////////////////////////////
  //
  // Acquiring and releasing WebGL objects
  //

  void enqueueAcquireGLObjects(WebCLMemoryObject[] memObjects,
                               optional WebCLEvent[]? eventWaitList,
                               optional WebCLEvent? event);
 
  void enqueueReleaseGLObjects(WebCLMemoryObject[] memObjects,
                               optional WebCLEvent[]? eventWaitList,
                               optional WebCLEvent? event);
  
  ////////////////////////////////////////////////////////////////////////////
  //
  // Executing kernels
  //

  void enqueueNDRangeKernel(WebCLKernel kernel, 
                            CLuint[]? offsets, CLuint[]? globals, CLuint[]? locals, 
                            optional WebCLEvent[]? eventWaitList,
                            optional WebCLEvent? event);
  
  void enqueueTask(WebCLKernel kernel, 
                   optional WebCLEvent[]? eventWaitList,
                   optional WebCLEvent? event);
  
  ////////////////////////////////////////////////////////////////////////////
  //
  // Synchronization
  //

  void enqueueMarker(optional WebCLEvent[]? eventWaitList, optional WebCLEvent? event);

  void enqueueBarrier(optional WebCLEvent[]? eventWaitList, optional WebCLEvent? event);
  
  void finish();
  
  void flush();

  ////////////////////////////////////////////////////////////////////////////
  //
  // Querying command queue information
  //

  any getInfo(CLenum name);
};