//allow a user to broadcast live from a microphone or webcam onto infoburp,
//where their video/audio is stored as a node as it is streamed, and can be watched later.
//support html5 getusermedia, and flash for older browsers.

//Grab the elements

var video = document.getElementsByTagName('video')[0],

heading = document.getElementsByTagName('h1')[0];

//test for getUserMedia

if(navigator.getUserMedia) {

  //setup callbacks

  navigator.getUserMedia('video', successCallback, errorCallback);

 

  //if everything if good then set the source of the video element to the mediastream

  function successCallback( stream ) {

    video.src = stream;

  }

 

  //If everything isn't ok then say so

  function errorCallback( error ) {

    heading.textContent =

        "An error occurred: [CODE " + error.code + "]";

  }

}

else {

  //show no support for getUserMedia

  message.tooltip =

      "Web camera streaming is not supported in this browser!";

}
