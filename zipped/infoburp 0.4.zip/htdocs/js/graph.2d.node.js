//present a node to the user containing a flot graph of one of a few types.

//http://code.google.com/p/flot/