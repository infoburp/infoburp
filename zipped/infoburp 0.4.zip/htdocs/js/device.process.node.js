interface WebCLDevice {
    any getInfo(CLenum name);
    object getExtension(DOMString extensionName);
    sequence<DOMString> getSupportedExtensions();
};