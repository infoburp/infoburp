//music output, for example a midi output port
