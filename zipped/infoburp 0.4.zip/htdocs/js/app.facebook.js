//allow users to comment, like, friend and upload to infoburp nodes and links from facebook.com (app)
//after adding the infoburp app to their page