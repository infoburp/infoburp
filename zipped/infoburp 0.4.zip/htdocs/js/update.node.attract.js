//................attraction
IB.update.nodeAttract = function(node1, node2){
	var P = IB.config.node.attraction;

	//nodes attract along link lines according to hookes law
	var xpDiff = node2.x-node1.x;
	var ypDiff = node2.y-node1.y;
	var xsign=xpDiff/Math.abs(xpDiff);
	var ysign=ypDiff/Math.abs(ypDiff);
	if (isNaN(xsign)) xsign=1;
	if (isNaN(ysign)) ysign=1;
	
	var Exceed = -(Math.sqrt(xpDiff*xpDiff+ypDiff*ypDiff))*P.attraction*node1.whuffie*node2.whuffie;
	
	var xExceed=xsign*Exceed;
	var yExceed=ysign*Exceed;
	var xpSpeed= P.dumping*(node2.xspeed+xExceed*P.tu);
	var ypSpeed= P.dumping*(node2.yspeed+yExceed*P.tu);
	var xInertion = xpSpeed*P.tu  + parseInt(xsign*xExceed)*P.tu*P.tu/2;
	var yInertion = ypSpeed*P.tu  + parseInt(ysign*yExceed)*P.tu*P.tu/2;
	if (isNaN(xInertion)) xInertion=0;
	if (isNaN(yInertion)) yInertion=0;
	
	node2.x += xInertion ; 
	node2.y += yInertion ; 
	//jiggle the node a bit to avoid stuck nodes
		var rando=Math.floor(Math.random()*5)
		if (rando = 1) node2.x += 1;
		if (rando = 2) node2.x -= 1;
		if (rando = 3) node2.y += 1;
		if (rando = 4) node2.y -= 1;
}