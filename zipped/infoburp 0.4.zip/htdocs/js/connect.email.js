//send and receive emails from a remote email server
//uses socket.io

//every node,link and bubble is given a unique email adress like graeme.wolfendale@infoburp.com
//the infoburp system acts as an email system, storing, forwarding, sending and receiving
//emails.