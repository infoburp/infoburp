//adds a node which contains an item for sale on ebay, earns infoburp commision income.

//http://developer.ebay.com/DevZone/javascript/docs/readme.html

//http://developer.ebay.com/devzone/finding/howto/gettingstarted_js_nv_json/gettingstarted_js_nv_json.html

//this gives us ebay products matching a keyword 

	keyword = parent.node.html

// Construct the request

	var url = "http://svcs.ebay.com/services/search/FindingService/v1";
    	url += "?OPERATION-NAME=findItemsByKeywords";
    	url += "&SERVICE-VERSION=1.0.0";
    	url += "&SECURITY-APPNAME=infoburp";
    	url += "&GLOBAL-ID=EBAY-US";
    	url += "&RESPONSE-DATA-FORMAT=JSON";
    	url += "&callback=_cb_findItemsByKeywords";
    	url += "&REST-PAYLOAD";
    	url += "&keywords=keyword";
    	url += "&paginationInput.entriesPerPage=1";

//execute the request


	var result = root.findItemsByKeywordsResponse[0].searchResult[0].item || [];

//add the result to infoburp as an advert node

	IB.advert.node.add(result)