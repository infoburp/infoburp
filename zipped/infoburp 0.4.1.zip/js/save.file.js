//save data - stores nodes, links and bubbles as files on the hard drive and in ram.

	//http://www.w3.org/TR/file-system-api/

//ask user before storing any data

//store node to disk

//use best available storage method

//cookies

//file api
	save.file(filename)

		{		
			function useAsyncFS(fs) {
 
  				// now we write to the file; see [FILE-WRITER-ED].
  				fs.root.getFile("filename", {create: true}, function (f) {
    				f.createWriter(writeDataToLogFile);
  						});
		}
			requestFileSystem(TEMPORARY, 1024 * 1024, function(fs) {
  		useAsyncFS(fs);
		});

	// In a worker:

		var tempFS = requestFileSystem(TEMPORARY, 1024 * 1024);
		var filename = tempFS.root.getFile("filename", {create: true});
		var writer = filename.createWriter();
		writer.seek(writer.length);
		writeDataToLogFile(writer);
		}



