IB.node = {
	// get functions
	get: function(id){
		for(var x in IB._nodes){
			var node = IB._nodes[x];
			if(node.id==id)return node;
		}
	},
	children: function(id){
		var children = [];
		for(var x in IB._links){
			var link = IB._links[x];
			if(link.parent==id){
				children.push(IB.node.get(link.child));
			}
		}
		return children;
	},
	siblings: function(id){
		var siblings = [];
		for(var x in IB._links){
			var link = IB._links[x];
			if(link.parent==id || link.child==id){
				if(link.parent==id)siblings.push(IB.node.get(link.child));
				if(link.child==id)siblings.push(IB.node.get(link.parent));
			}
		}
		return siblings;
	},
	childrenWhuffie: function(id){
		var whuffie = 0;
		for(var x in IB._links){
			var link = IB._links[x];
			if(link.parent==id){
				whuffie += IB.node.get(link.child).whuffie;
			}
		}
		return whuffie;
	},
	totalWhuffie: function(id){
		var node = IB.node.get(id);
		var childrenWhuffie = IB.node.childrenWhuffie(id);
		return node.whuffie+childrenWhuffie;
	},

	//set functions
	updateChildNodePositions: function(node){
		var children = IB.node.children(node.id);
		var totalChildren = children.length;
		var childrenWhuffie = IB.node.childrenWhuffie(node.id);
		var circumference = childrenWhuffie;
		var averageTheta = circumference/totalChildren;
		var diameter = circumference/Math.PI;
		var radius = diameter/2;
		var theta = 0;
		var averageChildRadius = averageTheta/2;
		for(var x in children){
			var child = children[x];
			var childRadius = child.whuffie/2;
			var degrees = (theta/circumference)*360;
			var radians = degrees*(Math.PI/180);
			var childChildrenWhuffieRadius = IB.node.childrenWhuffie(child.id)/2;
			var whuffieRadius = node.whuffie/2;
			var extend = (whuffieRadius+childRadius+childChildrenWhuffieRadius)-averageChildRadius;
			child.x = parseInt(node.x) + (radius+extend)*Math.cos(radians);
			child.y = parseInt(node.y) + (radius+extend)*Math.sin(radians);
			theta += averageTheta;
		}
		IB.action.post({
			id:node.id,
			action:'updateChildNodePositions'
		});
	},
	createChild: function(parent, x, y){
		IB.action.post({
			id:parent.id,
			x:x,
			y:y,
			action:'createChild'
		}, function(data){
			IB.load.refresh();
		});
	},
	createLink: function(parent, child){
		IB.action.post({
			id:parent.id,
			child:child.id,
			action:'createLink'
		}, function(data){
			IB.load.refresh();
		});
	}
};