//put a node, link or bubble onto the dht network.

//data is node, link or bubble to be stored.
data = in;
//address is locality sensitive hash for that data.
address = hash.process.node(data);
network.put(address,data);

function network.put(address,data)
	{
	//put data to the infoburp dht network.
	}