//perform action such as save on a node
IB.action = {
	//do action
	serve: function(data, CB, method){
		if((typeof CB)!='function')CB = function(){};
		$.ajax({
			url: 'action/action.php',
			data: data,
			dataType: 'json',
			method: method,
			success: function(data){
				CB(data);
			}
		});
	},
	//post action
	post: function(data, CB){
		IB.action.serve(data, CB, 'post');
	},
	//get action
	get: function(data, CB){
		IB.action.serve(data, CB, 'get');
	},
	
	//save the node
	save: function(id, html, CB){
		var data = {
			action:'save',
			id:id,
			html:html
		};
		IB.action.post(data, CB);
	},
	//vote the node up
	voteUp: function(id, CB){
		var data = {
			action:'voteUp',
			id:id
		};
		IB.action.post(data, CB);
	},
	//vote the node down
	voteDown: function(id, CB){
		var data = {
			action:'voteDown',
			id:id
		};
		IB.action.post(data, CB);
	},
};
