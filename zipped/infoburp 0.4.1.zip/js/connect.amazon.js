//scale down hosting by amount

hosting.scale.down(amount)

	{

	}

//scale up hosting by amount

hosting.scale.up(amount)

	{

	}