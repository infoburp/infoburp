//e handler for keyboard and mouse interaction
IB.e = {
	x: 0,
	y: 0,
	sx: 0,
	sy: 0,
	dragging: false,

	load: function(){
		$(document.body).bind('mousedown', function(e){ IB.e.mouse.down(e); });
		$(document.body).bind('mouseup', function(e){ IB.e.mouse.up(e); });
		$(document.body).bind('mousemove', function(e){ IB.e.mouse.move(e); });
		$(document.body).bind('mousewheel', function(e){ IB.e.mouse.scroll(e); });
		$(document.body).bind('keydown', function(e){ IB.e.keys.down(e); });
		$(document.body).bind('keyup', function(e){ IB.e.keys.up(e); });
		IB.__html.find('.node').bind('mousedown', function(e){ IB.e.mouse.node.down(e, this); });
		IB.__html.find('.node').bind('mouseup', function(e){ IB.e.mouse.node.up(e, this); });
		IB.__html.find('.node').bind('click', function(e){ IB.e.mouse.node.click(e, this); });
		IB.__html.find('.node').bind('dblclick', function(e){ IB.e.mouse.node.dblclick(e, this); });
		IB.__html.find('.node').bind('mouseout', function(e){ IB.e.mouse.node.out(e, this); });
		IB.__html.find('.node *').not('.html').bind('mousedown', function(e){ e.stopPropagation() });
		IB.__html.find('.node .editSave').bind('mouseup', function(e){ IB.e.mouse.node.edit.save.up(e) });
		IB.__html.find('.node .editCancel').bind('mouseup', function(e){ IB.e.mouse.node.edit.cancel.up(e) });
		IB.__html.find('.node .voteUp').bind('mouseup', function(e){ IB.e.mouse.node.vote.up.up(e) });
		IB.__html.find('.node .voteDown').bind('mouseup', function(e){ IB.e.mouse.node.vote.down.up(e) });
		IB.e.mouse.followRegister($('#infoburp #addNode'));
	},
	
	moveX: function(x){
		var zoom = IB.config.screen.zoom;
		IB.config.screen.x += x/zoom;
	},
	moveY: function(y){
		var zoom = IB.config.screen.zoom;
		IB.config.screen.y += y/zoom;
	},
	moveXY: function(x, y){
		var zoom = IB.config.screen.zoom;
		IB.config.screen.x += x/zoom;
		IB.config.screen.y += y/zoom;
	},
	move2XY: function(x, y){
		IB.config.screen.x = x;
		IB.config.screen.y = y;
	},

	zoom: function(i){
		i /= 10;
		IB.config.screen.zoom = (IB.config.screen.zoom+i);
		if(IB.config.screen.zoom<.1)IB.config.screen.zoom = .1;
	},
};
