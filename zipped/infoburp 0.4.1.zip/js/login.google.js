//login with google id
//https://developers.google.com/gdata/docs/js-authsub

 function doLogin(){
    scope = "http://www.google.com/calendar/feeds";
    var token = google.accounts.user.login(scope);
  }
