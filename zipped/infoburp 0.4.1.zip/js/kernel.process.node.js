interface WebCLKernel {
    any getInfo(CLenum name);
    any getWorkGroupInfo(WebCLDevice device, CLenum name);
    void setArg(CLuint index, any value, optional CLtype type);
};
//The following enumerated values are available for specifying the type of kernel arguments in setArg. Vector types are specified by bitwise-OR'ing one of the scalar enums with exactly one of the vector enums (VEC2, VEC3, VEC4, VEC8, or VEC16). The special type LOCAL_MEMORY_SIZE is used to allocate memory for local variables.

interface WebCLKernelArgumentTypes {

  // Scalar types; may be bitwise-OR'ed with a vector type

  CLtype CHAR   = 0;
  CLtype UCHAR  = 1;
  CLtype SHORT  = 2;
  CLtype USHORT = 3;
  CLtype INT    = 4;
  CLtype UINT   = 5;
  CLtype LONG   = 6;
  CLtype ULONG  = 7;
  CLtype FLOAT  = 8;
  CLtype HALF   = 9;    // not supported in all implementations
  CLtype DOUBLE = 10;   // not supported in all implementations

  // Vector types; must be bitwise-OR'ed with a scalar type

  CLtype VEC2  = 0x0100;
  CLtype VEC3  = 0x0200;
  CLtype VEC4  = 0x0400;
  CLtype VEC8  = 0x0800;
  CLtype VEC16 = 0x1000;

  // Special types; must not be bitwise-OR'ed with any other type

  CLtype LOCAL_MEMORY_SIZE = 255;
};