//connect to a webserver using http protocol
//uses socket.io

	//take input remote url

		url=node.html

	//pull the requested url

		connect.network(url,data)

	//add the html returned as a node on infoburp

		IB.node.add(data)

