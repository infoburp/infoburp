//allow users to tweet directly into nodes from twitter.com (app)
//after adding the infoburp app to their page