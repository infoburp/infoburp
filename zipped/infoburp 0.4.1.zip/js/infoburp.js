//run this to add the computer it is run on to infoburp
//as a machine node with varying levels

//0-machine node only
//1-machine node + user interface node - text only
//2-machine node + user interface node - 2d graphical
//3-machine node + user interface node - 3d graphical
//4-machine node + user interface node - 2d graphical + sound out
//5-machine node + user interface node - 3d graphical + video out
//6-machine node + user interface node - 2d graphical + sound in
//7-machine node + user interface node - 3d graphical + video in
//8-machine node + user interface node - 2d graphical + sound in/out
//9-machine node + user interface node - 3d graphical + video in/out

	//loop until crash 
	
	{
		init.infoburp(runlevel)
		kernel.infoburp(runlevel)
	}

	//error handler

	{

	}