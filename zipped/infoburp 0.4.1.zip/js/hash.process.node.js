//produce a 256 bit long locality sensitive hash based on the node html.
//http://en.wikipedia.org/wiki/Locality-sensitive_hashing
//this hash is then used for idea gravity and the distributed hash table network.

