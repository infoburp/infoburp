//load all nodes from database
IB.load = {
	self:function(){
		IB.__ = $('#infoburp');
		IB.__html = IB.__.find('.html');
		var h = $(window).height();
		var w = $(window).width();
		IB.config.screen.h = h;
		IB.config.screen.w = w;
		IB._ = Raphael('infoburp', w, h);
		IB.e.move2XY(0, 0);
		IB.load.refresh();
	},
	refresh: function(){
		IB._.clear();
		IB.__html.html('');
		IB.load.nodes(function(){
			IB.load.links(function(){
				IB.load.rest();
			});
		});
	},
	nodes: function(CB){
		IB.action.get({
			action:'getNodes'
		}, function(data){
			IB._nodes = data;
			CB();
		});
	},
	links: function(CB){
		IB.action.get({
			action:'getLinks'
		}, function(data){
			IB._links = data;
			CB();
		});
	},
	rest: function(){
		IB.search.load();
		// create nodes and links
	    IB.create.load();
	    // default zoom
		//IB.config.screen.zoom = IB.config.screen.h/(IB.update.calc(IB._nodes.totalWhuffie)/2);
		// begin updating nodes
		IB.update.load();
		//event control
		IB.e.load();
	},
};
