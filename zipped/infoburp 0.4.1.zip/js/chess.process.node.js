//take a node containing a boardmap with a flag stating whose move it is as input

//output possible moves as links to other boardmaps

//in this way, eventually every possible chess game is played.
	
	//find pieces that are free to move

	//find moves those pieces can take

	//output moves as links to resultant boardmaps

	//give the boardmap a whuffie score based on the current player's position + future.