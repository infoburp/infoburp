//code for field programmable gate arrays
