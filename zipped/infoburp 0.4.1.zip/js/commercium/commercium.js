//core .js for the commercium in browser development environment.


