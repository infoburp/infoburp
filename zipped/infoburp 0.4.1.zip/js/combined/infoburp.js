//enable custom 2d user interfaces, raphael?
//webGL 3d engine
//perform action such as save on a node
IB.action = {
	//do action
	serve: function(data, CB, method){
		if((typeof CB)!='function')CB = function(){};
		$.ajax({
			url: 'action/action.php',
			data: data,
			dataType: 'json',
			method: method,
			success: function(data){
				CB(data);
			}
		});
	},
	//post action
	post: function(data, CB){
		IB.action.serve(data, CB, 'post');
	},
	//get action
	get: function(data, CB){
		IB.action.serve(data, CB, 'get');
	},
	
	//save the node
	save: function(id, html, CB){
		var data = {
			action:'save',
			id:id,
			html:html
		};
		IB.action.post(data, CB);
	},
	//vote the node up
	voteUp: function(id, CB){
		var data = {
			action:'voteUp',
			id:id
		};
		IB.action.post(data, CB);
	},
	//vote the node down
	voteDown: function(id, CB){
		var data = {
			action:'voteDown',
			id:id
		};
		IB.action.post(data, CB);
	},
};
////code defining an advert node, which contains an advert, which when clicked by a user
//produces income for infoburp

//advert nodes cannot have children, have the whuffie of the parent node, and cannot
//be voted up or down. this means they can be freely added and removed from the 
//graph as requirements change.


		//amazon product buy advert - commission

		//https://github.com/Exeu/Amazon-ECS-PHP-Library

		//http://petewilliams.info/blog/2009/07/javascript-amazon-associate-link-localiser/
	
		//for example, I add a node a about a book, and the book is 
		//sold to me through amazon.

//set the subject of the advert node (parent node html)
		subject = parent.node.html;

		//spawn an advertising node with a suitable subject for it's parent node
		spawn.advert.amazon.node(subject)
		
			{
			/**
 * Search for any AMAZON product links and replace with a referral link to the visitor's local Amazon site
 * @author Pete Williams
 * @url http://petewilliams.info/blog/2009/07/javascript-amazon-associate-link-localiser/
 * @version 1.7.2
 */
 
/* ENTER YOUR AFFILIATE IDs BELOW - You can leave any blank that you don't have accounts for */
var arrAffiliates = {
	'com'   : '',
	'co.uk'	: '',
	'de'	: '',
	'fr'	: '',
	'ca'	: '',
	'co.jp'	: '',
	'jp'	: '',
	'it'	: '',
	'cn'	: '',
	'es'	: ''
};

// OPTIONAL - if your PHP file is in the same directory as the current page, then leave this as it is. Otherwise insert the path to the file here
var strUrlAjax = 'action/localise.advert.amazon.node.php';

var arrLinksToCheck=[];
var strTld;
var strAffiliateId;

function linkAmazon(objLink,strAsin)
{
this.arrLinkObjects=new Array(objLink);
if(strAsin){this.strAsin=strAsin}
this.affiliateLink=function()
{
for(intLink=0;
intLink<this.arrLinkObjects.length;intLink++)
{this.arrLinkObjects[intLink].href="http://www.amazon."+this.getActualTld()+"/exec/obidos/ASIN/"+this.strAsin+"/"+getAffiliateId(arrTldActual[1])}};
this.searchLink=function()
{
var objRegexTitle=new RegExp("amazon.[a-zA-Z.]{2,5}/([A-Za-z-]*)/dp");
arrResult=objRegexTitle.exec(this.arrLinkObjects[0].href);if(arrResult)
{strTitle=arrResult[1].replace(/-/g,"%20");
this.writeSearchLink(strTitle)
}
else
{
strUrlProduct=strUrlAjax+"?strAction=search&strLink="+this.arrLinkObjects[0].href;
objScript=document.createElement("script");
objScript.src=strUrlProduct;
document.getElementsByTagName("head")[0].appendChild(objScript)}};
this.addLink=function(objLink){this.arrLinkObjects.push(objLink)};
this.writeSearchLink=function(strTitle)
{
for(intSearchLink=0;
intSearchLink<this.arrLinkObjects.length;intSearchLink++)
{
this.arrLinkObjects[intSearchLink].href="http://www.amazon."+strTld+"/s?keywords="+strTitle+"&tag="+strAffiliateId}};
this.getAffiliateUrl=function()
{
return"http://www.amazon."+strTld+"/exec/obidos/ASIN/"+this.strAsin+"/"+strAffiliateId};
this.localiseLink=function()
{
for(i=0;i<this.arrLinkObjects.length;i++)
{
this.arrLinkObjects[i].href=this.getAffiliateUrl()}};
this.getActualTld=function(){var c=new RegExp("amazon.(.*?)/");
arrTldActual=c.exec(this.arrLinkObjects[0].href);
return arrTldActual[1]
}}
function findLocation()
{
if(typeof google!="undefined"&&google.loader.ClientLocation!=null)
{
var strCountry=google.loader.ClientLocation.address.country_code;
checkAmazonLinks(strCountry)}else{objScript=document.createElement("script");
objScript.src="http://freegeoip.net/json/?callback=checkAmazonLinks";
document.getElementsByTagName("head")[0].appendChild(objScript)
}}
function checkAmazonLinks(strCountry)
{
var objRegexAsin=new RegExp("/([A-Z0-9]{10})");
if(strCountry)
{
if(typeof strCountry.country_code!="undefined")
{
strCountry=strCountry.country_code
}
switch(strCountry)
{
case'GB':case'IE':strTld='co.uk';break;case'AT':strTld='de';
break;case'PT':strTld='es';
break;
default:strTld=(arrAffiliates[strCountry.toLowerCase()]!=null?strCountry.toLowerCase():'com');
break}strAffiliateId=getAffiliateId(strTld)
}
var arrLinks=document.getElementsByTagName("a");
for(i=0,j=arrLinks.length;i<j;i++)
{
var intIndex=arrLinks[i].href.toLowerCase().indexOf("amazon.");
if(intIndex>0&&intIndex<arrLinks[i].href.substring(8).indexOf("/")+8&&arrLinks[i].href.indexOf("/review/")<0)
{
var arrResults=objRegexAsin.exec(arrLinks[i].href);
if(arrResults){if(typeof(arrLinksToCheck[arrResults[1]])=="undefined")
{
objLink=new linkAmazon(arrLinks[i],arrResults[1]);
if(strTld&&strTld==objLink.getActualTld())
{
objLink.affiliateLink()
}
else
{
arrLinksToCheck[arrResults[1]]=objLink
}}
else
{
arrLinksToCheck[arrResults[1]].addLink(arrLinks[i])
}}
else
{
var intPreTag=arrLinks[i].href.indexOf("tag=");
if(!strTld){objLink=new linkAmazon(arrLinks[i]);
strTldChecked=objLink.getActualTld()
}
else
{
strTldChecked=strTld
}
if(intPreTag>0)
{
intPreTag+=4;var intPostTag=arrLinks[i].href.substring(intPreTag).indexOf("&");
if(intPostTag<0)
{
intPostTag=arrLinks[i].href.length-intPreTag
}
arrLinks[i].href=arrLinks[i].href.substring(0,intPreTag)+getAffiliateId(strTldChecked)+arrLinks[i].href.substring((intPostTag+intPreTag));
intPath=arrLinks[i].href.indexOf("/",arrLinks[i].href.indexOf("amazon"));
arrLinks[i].href="http://www.amazon."+strTldChecked+arrLinks[i].href.substring(intPath)
}
else
{
intPath=arrLinks[i].href.indexOf("/",arrLinks[i].href.indexOf("amazon"));
arrLinks[i].href=arrLinks[i].href.substring(0,arrLinks[i].href.indexOf("amazon."))+"amazon."+strTldChecked+arrLinks[i].href.substring(intPath)+(arrLinks[i].href.indexOf("?")>0?"&":"?")+"tag="+getAffiliateId(strTldChecked)
}
}
}
}
if(strTld)
{
var strLinksToCheck="";
for(strKey in arrLinksToCheck)
{
if(typeof arrLinksToCheck[strKey].strAsin!="undefined")
{
strLinksToCheck+=arrLinksToCheck[strKey].strAsin+"|"
}
}
if(strLinksToCheck.length)
{
var strUrlAjaxLinks=strUrlAjax+"?strTld="+strTld+"&strAffiliateId="+strAffiliateId+"&strLinks="+strLinksToCheck;
strUrlAjaxLinks=strUrlAjaxLinks.substring(0,strUrlAjaxLinks.length-1);
objScript=document.createElement("script");
objScript.src=strUrlAjaxLinks;
document.getElementsByTagName("head")[0].appendChild(objScript)
}
}
}
function getAffiliateId(strTLD)
{
return(arrAffiliates[strTLD]?arrAffiliates[strTLD]:arrAffiliatesSpares[strTLD])
}
if(window.addEventListener)
{
window.addEventListener("load",findLocation,false)
}
else
{
window.attachEvent("onload",findLocation)
}
var arrAffiliatesSpares={'co.uk':'pcrev05','com':'petewill-20','de':'petewill05-21','fr':'petewill-21','ca':'petewill00-20','co.jp':'petewill-22','jp':'petewill-22','it':'petewill04-21','cn':'petewill-23','es':'petewill0d4-21'};	
			}

//adds a node which contains an item for sale on ebay, earns infoburp commision income.

//http://developer.ebay.com/DevZone/javascript/docs/readme.html

//http://developer.ebay.com/devzone/finding/howto/gettingstarted_js_nv_json/gettingstarted_js_nv_json.html

//this gives us ebay products matching a keyword 

	keyword = parent.node.html

// Construct the request

	var url = "http://svcs.ebay.com/services/search/FindingService/v1";
    	url += "?OPERATION-NAME=findItemsByKeywords";
    	url += "&SERVICE-VERSION=1.0.0";
    	url += "&SECURITY-APPNAME=infoburp";
    	url += "&GLOBAL-ID=EBAY-US";
    	url += "&RESPONSE-DATA-FORMAT=JSON";
    	url += "&callback=_cb_findItemsByKeywords";
    	url += "&REST-PAYLOAD";
    	url += "&keywords=keyword";
    	url += "&paginationInput.entriesPerPage=1";

//execute the request


	var result = root.findItemsByKeywordsResponse[0].searchResult[0].item || [];

//add the result to infoburp as an advert node

	IB.advert.node.add(result)//code defining an advert node, which contains an advert, which when clicked by a user
//produces income for infoburp

//advert nodes cannot have children, have the whuffie of the parent node, and cannot
//be voted up or down. this means they can be freely added and removed from the 
//graph as requirements change.

//the node to which the advert node is attached is given whuffie according to the cpc,
//nodes with high cpc ads attached will earn more whuffie in this way.

//when an advert node is removed, the whuffie it gave to the node it spawned from is
//taken back, also.

//this encourages infoburp to concentrate on the most profitable topics, to ensure good 
//income.

		//google adsense advert - income per click
		
		//set the subject of the advert node (parent node html)
		subject = parent.node.html;

		//spawn an advertising node with a suitable subject for it's parent node
		add.advert.google.node(parentnode)
		
			{

			IB.advert.google.node.add(parentnode);	

			}
		//remove a specific ad node
		remove.advert.google.node(parentnode)
		
			{

			IB.advert.google.node.add(parentnode);	

			}
		//spawn a high cpc ad node
		high.cpc.add()

			{
			//search for high cpc keywords

			//add ads based on those keywords
			IB.advert.google.node.add(subject);
			}

		//despawn a high cpc ad node
		high.cpc.remove()

			{
			//search for high cpc keywords

			//remove ads based on those keywords
			IB.advert.google.node.remove(subject);
			}

		//spawn a low cpc ad node
		low.cpc.add()

			{
			//search for low cpc keywords

			//add ads based on those keywords
			IB.advert.google.node.add(subject);
			}

		//despawn a low cpc ad node
		low.cpc.remove()
			
			{
			//search for low cpc keywords, currently in use

			//remove ads based on those keywords
			IB.advert.google.node.remove(subject);
			}

// Pseudo-namespaces with automatic evaluation. 
(function(){
    
    // Associative arrays for URL-relevant strings.  I don't see an 
    // obvious reason for the two separate arrays. 
    // 
    var gStrDefs = {
	google_ad_channel:"channel",
	google_ad_host:"host",
	google_ad_region:"region",
	google_ad_section:"region",
	google_ad_type:"ad_type",
	google_adtest:"adtest",
	google_alternate_ad_url:"alternate_ad_url",
	google_alternate_color:"alt_color",
	google_bid:"bid",
	google_city:"gcs",
	google_color_bg:"color_bg",
	google_color_border:"color_border",
	google_color_line:"color_line",
	google_color_link:"color_link",
	google_color_text:"color_text",
	google_color_url:"color_url",
	google_contents:"contents",
	google_country:"gl",
	google_cust_age:"cust_age",
	google_cust_ch:"cust_ch",
	google_cust_gender:"cust_gender",
	google_cust_id:"cust_id",
	google_cust_interests:"cust_interests",
	google_cust_job:"cust_job",
	google_cust_l:"cust_l",
	google_cust_lh:"cust_lh",
	google_cust_u_url:"cust_u_url",
	google_disable_video_autoplay:"disable_video_autoplay",
	google_ed:"ed",
	google_encoding:"oe",
	google_feedback:"feedback_link",
	google_flash_version:"flash",
	google_gl:"gl",
	google_hints:"hints",
	google_kw:"kw",
	google_kw_type:"kw_type",
	google_language:"hl",
	google_referrer_url:"ref",
	google_region:"gr",
	google_reuse_colors:"reuse_colors",
	google_safe:"adsafe",
	google_targeting:"targeting",
	google_ui_features:"ui"},
	
	gStrDefsAddl = {
        google_ad_format:"format",
	google_ad_output:"output",
	google_ad_callback:"callback",
	google_ad_override:"google_ad_override",
	google_ad_slot:"slotname",
	google_analytics_webpropids:"ga_wpids",
	google_correlator:"correlator",
	google_cpa_choice:"cpa_choice",
	google_image_size:"image_size",
	google_last_modified_time:"lmt",
	google_max_num_ads:"num_ads",
	google_max_radlink_len:"max_radlink_len",
	google_num_radlinks:"num_radlinks",
	google_num_radlinks_per_unit:"num_radlinks_per_unit",
	google_only_ads_with_video:"only_ads_with_video",
	google_page_location:"loc",
	google_page_url:"url",
	google_rl_dest_url:"rl_dest_url",
	google_rl_filtering:"rl_filtering",
	google_rl_mode:"rl_mode",
	google_rt:"rt",
	google_skip:"skip"};


    // Looks up a string in the global associative arrays, and returns 
    // null on failure. 
    // 
    function lookupGoogleString(key) {
	return gStrDefs[key] || gStrDefsAddl[key] || null;
    }

    var Doc = document;

    // This extracts Google Analytics information from any available 
    // cookies, and if not available, generates suitable numerical 
    // identifiers as needed. 
    // 
    // The resulting object is hooked into the window object as 
    // window.gaGlobal and also returned. 
    // 
    function establishAnalyticsState() {
	var cookie = Doc.cookie,

	    // A crude random number or numerical identifier 
	    a = Math.round((new Date).getTime() / 1000),

	    // predicates testing for various Google Analytics cookies 
	    hasGaCookieA = cookie.indexOf("__utma=") > -1,
	    hasGaCookieB = cookie.indexOf("__utmb=") > -1,
	    hasGaCookieC = cookie.indexOf("__utmc=") > -1,
	    f,
	    g = {};

	if (hasGaCookieA) {
	    // Separate out the numbers of a utma-style cookie. Example: 
	    // 173272373.449341548.1193258541.1194650238.1195068298.3 
	    // 
	    f = cookie.split("__utma=")[1].split(";")[0].split(".");

	    // If not all cookies exist, use new value. 
	    g.sid = (!hasGaCookieB || !hasGaCookieC ? a : f[4]) + "";
	    g.vid = f[1] + "." + f[2];
	    g.from_cookie = true;
	} else {
	    g.sid = window && window.gaGlobal && window.gaGlobal.sid ?
		window.gaGlobal.sid : a + "";
	    g.vid = window && window.gaGlobal && window.gaGlobal.vid ?
		window.gaGlobal.vid : Math.round(Math.random()*2147483647) + "." + a;
	    g.from_cookie = false;
	}

	g.hid = window && window.gaGlobal && window.gaGlobal.hid ?
	    window.gaGlobal.hid : Math.round(Math.random()*2147483647);

	window.gaGlobal = g;

	return g;
    }

    // ---- Construction of "IDICommon" componenet ----------------------- 
    // =================================================================== 

    (function() {

	function b(){}

	// Returns everything following the first occurrence of "#" in 
	// the input string, or an empty string if "#" does not exist. 
	// 
	b.prototype.getHash = function(e) {
	    var c = e.indexOf("#") + 1;
	    return c ? e.substr(c) : "";
	};

	b.prototype.htmlEscape = function(e) {
	    return /[&<>\"]/.test(e) ? e.replace(/&/g,"&amp;")
                                               .replace(/</g,"&lt;")
                                               .replace(/>/g,"&gt;")
                                               .replace(/\"/g,"&quot;") : e;
	};

	// Creates and returns an iframe tag, given an associative 
	// array of attributes. 
	// 
	b.prototype.makeIframeTag = function(e) {
	    var c = "<iframe";
	    for (var f in e) {
		c += " " + f + '="' + this.htmlEscape(e[f]) + '"';
	    }

	    return c + "></iframe>";
	};

	// Returns an iframe of name frameId for the given window. 
	// 
	b.prototype.getIframe = function(win, frameId) {
	    try {
		return win.frames[frameId];
	    } catch (e) {
		return null;
	    }
	};

	b.prototype.makeIframeNode = function(attribs) {
	    var el = document.createElement("iframe");
	    for (var a in attribs) {
		el.setAttribute(a, attribs[a]);
	    }

	    return el;
	};

	b.prototype.appendHiddenIframe = function(name, url) {
	    var f = this;

	    // This launches a separate "thread" of sorts to append 
	    // the iframe to the document as soon as possible. 
	    // 
	    setTimeout(function() {
	                   document.body.appendChild(f.makeIframeNode({id:name,
                                                                       name:name,
                                                                       src:url,
                                                                       width:0,
                                                                       height:0,
                                                                       frameBorder:0}))
		       }, 0);
	};

	b.prototype.writeHiddenIframe = function(name, url) {
	    var f = this;
	    document.write(f.makeIframeTag({id:name, name:name, src:url,
                                            width:0, height:0, frameBorder:0}));
	};

	// This method chops a URI argument string into substrings 
	// that do not cut %-encoded values in half, while each 
	// substring is no longer than the provided maximum length. 
	// The resulting vector of substrings is returned. 
	// 
	b.prototype.splitURIComponent = function(argStr, maxLen) {
	    var results = [],
	        len = argStr.length,
	        k = 0;

	    while (k < len) {
		var argSub = argStr.substr(k, maxLen),
		    argSubLen = argSub.length;

		if (k + argSubLen < len) {
		    for (var i = 1; i < 3; ++i) {
			if (argSub.charAt(argSubLen - i) == "%") {
			    argSub = argSub.substr(0, argSubLen -= i);
			}
		    }
		}

		results.push(argSub);
		k += argSubLen;
	    }

	    return results;
	};

	b.prototype.exportSingleton = function(name, obj, attrTable) {
	    if (! window[name]) {
		var g = window[name] = new obj;

		// Hook the methods/variables into the new object 
		for (var k = 0; k < attrTable.length; ++k) {
		    g[attrTable[k][0]] = attrTable[k][1];
		}
	    }
	};

	var proto = b.prototype,
	    attrTable = [["getHash", proto.getHash],
			 ["htmlEscape", proto.htmlEscape],
			 ["makeIframeTag", proto.makeIframeTag],
			 ["getIframe", proto.getIframe],
			 ["makeIframeNode", proto.makeIframeNode],
			 ["appendHiddenIframe", proto.appendHiddenIframe],
			 ["writeHiddenIframe", proto.writeHiddenIframe],
			 ["splitURIComponent", proto.splitURIComponent],
			 ["exportSingleton", proto.exportSingleton],
			 ["MAX_URL_LENGTH", 4095],
			 ["IDI_DEFAULT_POLLING_INTERVAL", 1000]];

	// Hook the functions defined above into the window 
	// object under key "IDICommon", thus making available 
	// globally the IDICommon object. 
	// 
	b.prototype.exportSingleton("IDICommon", b, attrTable);

    }) ();

    // ---- Construction of "IDIHost" componenet ------------------------- 
    // =================================================================== 

    (function() {
	function addAttrs(dst, src) {
	    for (var g in src) {
		dst[g] = src[g];
	    }
	}

	function a() {
	    // Take URL as originally requested and change it to the 
	    // robots.txt URL. 
	    // 
	    this.hostRelayUrl =
                window.location.href.replace(/([^:\/])\/.*$/, "$1/robots.txt");
	    this.moduleRelayUrl = "";
	    this.frameUses = {};
	    this.moduleIds = {};
	    this.frameHashes = {};
	    this.frameUrls = {};
	    this.frameListeners = {};
	}

	// A way to dispatch messages to individual iframe modules, 
	// presumably for external use, since the method is not 
	// actually used in this code. 
	// 
	a.prototype.postMessageToModule = function(frameId, msg, obj) {
	    var url;

	    if (typeof obj == "object") {
		url = obj.moduleRelayUrl;
	    }

	    var id = this.moduleIds[frameId];

	    if (isNaN(id)) {
		throw new Error("Invalid module id");
	    } else {
		var mru = (typeof url == "string") ?
		           url :
		           this.getModuleRelayUrl(this.frameUrls[frameId]),
		    encMsg = encodeURIComponent(msg) + "$",
		    lenAvail = IDICommon.MAX_URL_LENGTH - 1 - mru.length,
		    argsChunks = IDICommon.splitURIComponent(encMsg, lenAvail),
		    numargsChunks = argsChunks.length;

		for (var p = 0; p < numArgsChunks; ++p) {
		    IDICommon.appendHiddenIframe(frameId + "_" + (id + p),
						 mru + "#" + argsChunks[p]);
		}
		
		this.moduleIds[frameId] += numArgsChunks;
	    }
	};

	a.prototype.registerListener = function(frameId, callback, g) {
	    this.unregisterListener(frameId);
	    this.frameListeners[frameId] =
	        window.setInterval(function() { this.dispatch(frameId, callback) },
				   typeof g == "object" && g.pollingInterval
				   || IDICommon.IDI_DEFAULT_POLLING_INTERVAL);
	};

	a.prototype.unregisterListener = function(frameId) {
	    window.clearInterval(this.frameListeners[frameId]);
	    this.frameListeners[frameId] = 0;
	};
	
	a.prototype.setHostRelayUrl = function(c) {
	    this.hostRelayUrl = c;
	};
	
	a.prototype.setModuleRelayUrl = function(c) {
	    this.moduleRelayUrl = c;
	};
	
	a.prototype.getModuleRelayUrl = function(c) {
	    return this.moduleRelayUrl ||
	           c.replace(/([^:\/]\/).*$/,"$1ig/idi_relay");
	};

	// This function is called by the the listeners established by 
	// registerListener() above. The given frame is looked up, its 
	// usage recorded, and the given callback dispatched for each 
	// physical frame affected. 
	// 
	a.prototype.dispatch = function(frameId, callback) {
	    var win = window.frames[frameId];

	    if (win) {
		var j;
		while (j = IDICommon.getIframe(win, frameId + "_"
                                                            + this.frameUses[frameId])) {
		    try {
			if (j.location.href == "about:blank") {
			    break;
			}
		    } catch(l) {
			break;
		    }

		    this.frameHashes[frameId] += IDICommon.getHash(j.location.href);
		    ++this.frameUses[frameId];
		}

		var i = this.frameHashes[frameId].split("$"),
		    o = i.length - 1;

		if (o > 0) {
		    this.frameHashes[frameId] = i[o];
		    for (var q = 0; q < o; ++q) {
		       callback(decodeURIComponent(i[q]), frameId);
		    }
		}
	    }
	};

	// This is the main method that generates the iframe content. 
	// 
	a.prototype.createModule = function(gau, frameId, adWidth, adHeight, params) {

	    var attrs = { frameBorder:0, scrolling:"no" },
	        ia, cb, up, pi, pd;

	    if (typeof params == "object") {
		ia = params.iframeAttrs;
		cb = params.callback;
		up = params.userPrefs;
		pi = params.pollingInterval; // unused 
		pd = params.parentDivId;
	    }

	    if (typeof ia == "object") {
		addAttrs(attrs, ia)
	    }

	    addAttrs(attrs, {id:frameId, name:frameId, src:gau,
                             width:adWidth, height:adHeight});

	    this.frameUses[frameId] = 0;
	    this.moduleIds[frameId] = 0;
	    this.frameHashes[frameId] = "";
	    this.frameUrls[frameId] = gau;

	    var addlArgs = [];

	    if (typeof up == "object") {
		for (var s in up) {
		    addlArgs.push(encodeURIComponent(s)
                                  + "="
                                  + encodeURIComponent(up[s]));
		}
	    }

	    if (typeof cb == "function") {
		addlArgs.push("idi_hr=" + encodeURIComponent(this.hostRelayUrl));
		this.registerListener(frameId, cb, params);
	    }

	    if (addlArgs.length) {
		var argsStr = addlArgs.join("&");

		// If resulting iframe URL is too long, trigger 
		// relay processing. 
		// 
		if (attrs.src.length + 1 + argsStr.length > IDICommon.MAX_URL_LENGTH) {

		    // Add separator to argument string. 
		    argsStr += "$";

		    // The arguments are cut into pieces, and multiple 
		    // iframes are requested, one for each chunk. 
		    // 
		    var mru = this.getModuleRelayUrl(gau),
			lenAvail = IDICommon.MAX_URL_LENGTH - 1 - mru.length,
			argsChunks = IDICommon.splitURIComponent(argsStr, lenAvail),
			numArgsChunks = argsChunks.length;

		    for (var s = 0; s < numArgsChunks; ++s) {
			var frameIdCount = frameId + "_" + s,
			    chunkUrl = mru + "#" + argsChunks[s];

			if (pd) {
			    var div = document.getElementById(pd);

                            // This is bizarre -- it looks like this is 
			    // supposed to call IDICommon.makeIframeNode(), 
			    // since a.e() was that function's original 
                            // name. However, "this.e" doesn't seem to be 
                            // defined for function a() (i.e., this). 
                            // 
                            // How does this work? 
			    // 
			    div.innerHTML =
				div.innerHTML +
				this.e( {id:frameIdCount, name:frameIdCount, src:chunkUrl,
					 width:0, height:0, frameBorder:0});
			} else {
			    IDICommon.writeHiddenIframe(frameIdCount, chunkUrl);
			}
		    }
		    
		    this.moduleIds[frameId] += numArgsChunks;
		    argsStr = "";
	        }

		attrs.src += "#" + argsStr;
	    }

	    if (pd) {
		var div = document.getElementById(pd);
		div.innerHTML = div.innerHTML + IDICommon.makeIframeTag(attrs);
	    } else {
		document.write(IDICommon.makeIframeTag(attrs));
	    }
	};

	var proto = a.prototype,
	    attrTable = [["setHostRelayUrl", proto.setHostRelayUrl],
			 ["setModuleRelayUrl", proto.setModuleRelayUrl],
			 ["getModuleRelayUrl", proto.getModuleRelayUrl],
			 ["createModule", proto.createModule],
			 ["postMessageToModule", proto.postMessageToModule],
			 ["registerListener", proto.registerListener],
			 ["unregisterListener", proto.unregisterListener]];

	// Make the function set available globally under IDIHost. 
	// 
	IDICommon.exportSingleton("IDIHost", a , attrTable);
    }) ();

    // ---- Non-modularized code ----------------------------------------- 
    // =================================================================== 

    function quoteString(b) {
	return b != null ? '"' + b + '"' : '""';
    }

    function encodeUri(uri) {
	if (typeof encodeURIComponent == "function") { 
	    return encodeURIComponent(uri);
	} else {
	    return escape(uri);
	}
    }

    function appendToQuery(key, val) {
	if (key && val) {
	    window.google_ad_url += "&" + key + "=" + val;
	}
    }

    function appendItemToQuery(id) {
	var win = window,
	    key = lookupGoogleString(id),
	    val = win[key];

	appendToQuery(key, val);
    }

    function appendToQueryEscaped(b,a) {
	if (a) {
	    appendToQuery(b, encodeUri(a));
	}
    }

    function appendItemToQueryEscaped(id) {
	var win = window,
	    key = lookupGoogleString(id),
	    val = win[id];

	appendToQueryEscaped(key, val);
    }

    function appendIndexedItemToQuery(id, index) {
	var win = window,
	    key = lookupGoogleString(id),
	    val = win[id];

	if(key && val && typeof val == "object") {
	    val = val[index % val.length];
	}

	appendToQuery(key, val);
    }

    // This function is adding a "fingerprint" of browser capabilities 
    // to the google_ad_url, collecting all kinds of things about your 
    // browser setup and usage. 
    // 
    function appendBrowserCapabilities(b,a) {
	var scr = b.screen,
	    e = navigator.javaEnabled(),
	    c =- a.getTimezoneOffset();
	
	// If we have screen information via the window, 
	// add information to the window's google_ad_url. 
	// 
	if (d) {
	    appendToQuery("u_h", scr.height);
	    appendToQuery("u_w", scr.width);
	    appendToQuery("u_ah", scr.availHeight);
	    appendToQuery("u_aw", scr.availWidth);
	    appendToQuery("u_cd", scr.colorDepth);
	}

	// Add timezone delta + java status, and length of history. 
	// 
	appendToQuery("u_tz", c);
	appendToQuery("u_his", history.length);
	appendToQuery("u_java", e);

	// Add number of plugins 
	// 
	if (navigator.plugins) {
	    appendToQuery("u_nplug",navigator.plugins.length);
	}

        // Add number of mimetypes 
        // 
	if(navigator.mimeTypes){
	    appendToQuery("u_nmime",navigator.mimeTypes.length);
	}
    }

    function convertToCaName(b) {
	if (b) {
	    b = b.toLowerCase();
	    if (b.substring(0,3) != "ca-") {
		b = "ca-" + b;
	    }
	}

	return b;
    }

    function ensureDistAffPrefix(b) {
	if (b) {
	    b = b.toLowerCase();
	    if (b.substring(0,9) != "dist-aff-") {
		b = "dist-aff-" + b;
	    }
	}

	return b;
    }

    // Retrieves an element from the DOM and sets 
    // its height to the given value. 
    // 
    function setElementHeight(id, height) {
	var el = document.getElementById(id);
	el.style.height = height + "px";
    }

    function setFlashAdHeight(str, elementId, timer) {
	window.clearTimeout(timer);
	var re = /^google_resize_flash_ad_idi\((\d+)\)/,
	    results = str.match(re);

	if (results) {
	    setElementHeight(elementId, results[1]);
	}
    }

    // This function generates the Google ads output, either 
    // indirectly via JavaScript code being written to the document, 
    // or via an iframe and HTML. 
    // 
    function createAds(win, doc, gau /* Google ad url */, e /* always null */) {
	gau = gau.substring(0,2000);
	gau = gau.replace(/%\w?$/,"");

	if ((win.google_ad_output == "js" || win.google_ad_output == "json_html") &&
	    (win.google_ad_request_done || win.google_radlink_request_done)) {
	    doc.write('<script language="JavaScript1.1" src='
                      + quoteString(gau)
                      + "><\/script>");
	} else if (win.google_ad_output == "html") {
	    if (win.name != "google_ads_frame") {
		if (e != null) { // This cannot currently happen 
		    doc.write('<div id="' + e + '">');
		}

		if (isSpecialAdClient(win.google_ad_output, win.google_ad_client)) {
		    IDIHost.setModuleRelayUrl("http://pagead2.googlesyndication.com/"
                                              + "pagead/idi_relay.html");
		    var c = 0;

		    if (win.google_num_0ad_slots) {
			c += win.google_num_0ad_slots;
		    }

		    if (win.google_num_ad_slots) {
			c += win.google_num_ad_slots;
		    }

		    if (win.google_num_sdo_slots) {
			c += win.google_num_sdo_slots;
		    }
		    
		    var f = "google_inline_div" + c,
			g = "<div id=" + quoteString(f)
                            + ' style="position:relative;width:' + win.google_ad_width
                            + 'px"></div><div style="position:relative;width:'
                            +  win.google_ad_width + "px;height:" + win.google_ad_height
                            + 'px;z-index:-1"></div>';
		    
		    doc.write(g);

		    var frameId = "google_frame" + c,
			timer = win.setTimeout(function(){ IDIHost.unregisterListener(k) },
                                               5000);
		    
		    IDIHost.createModule(gau, frameId,
                                         win.google_ad_width,
                                         win.google_ad_height,
					 { callback:function(str, elmentId)
                                             { setFlashAdHeight(str, elementId, timer) },
					   pollingInterval:500,
					   iframeAttrs:{ style:"position: absolute;left:0px",
                                                         marginWidth:"0",
						         marginHeight:"0",
                                                         vspace:"0", hspace:"0", 
						         allowTransparency:"true"},
					   parentDivId:f});
		} else {
		    doc.write('<iframe name="google_ads_frame" width='
                              + quoteString(win.google_ad_width)
			      + " height=" + quoteString(win.google_ad_height)
			      + " frameborder=" + quoteString(win.google_ad_frameborder)
			      + " src=" + quoteString(gau)
			      + ' marginwidth="0" marginheight="0" vspace="0" hspace="0" '
                              + ' allowtransparency="true" scrolling="no">');
		    doc.write("</iframe>");
		}
		
		if (e != null) {
		    doc.write("</div>");
		}
	    }
	} else if (win.google_ad_output == "textlink") {
            
	    // This has the same effect as the initial if()-clause 
	    // above. 
	    // 
	    doc.write('<script language="JavaScript1.1" src='
                      + quoteString(gau)
                      + "><\/script>");
	}
    }

    // This is an initializer, taking all the string definitions and 
    // initializing them to null as members of the window. 
    // 
    function initVars(win) {
	for (var def in gStrDefs) {
	    win[def] = null;
	}

	for (var a in gStrDefsAddl) {
	    win[def] = null;
	}
    }

    // Returns true if we are using link units (one of the alternative 
    // display formats). I don't know the radlinks stuff. 
    // 
    function usingLinkUnits(win) {
	if (win.google_ad_format) {
	    return win.google_ad_format.indexOf("_0ads") > 0;
	}

	return win.google_ad_output != "html" && win.google_num_radlinks > 0;
    }

    function isSDOFormat(b) {
	return b && b.indexOf("_sdo") != -1;
    }

    function buildQueryUrl() {
	var win = window,
	    doc = document,
	    date = new Date,
	    rnd = e.getTime(),
	    adFormat = win.google_ad_format;

	// Cost per Action choice -- Defined only in the some of the 
	// snippets the hoster carries in his webpages. 
	// 
	if (win.google_cpa_choice != null) {
	    win.google_ad_url = "http://pagead2.googlesyndication.com/cpa/ads?";
	    win.google_ad_url += "client="
                                 + escape(convertToCaName(win.google_ad_client));
	    win.google_ad_region = "_google_cpa_region_";
	    appendItemToQuery("google_cpa_choice");

	    if (typeof doc.characterSet != "undefined") {
		appendToQueryEscaped("oe", doc.characterSet);
	    } else if (typeof doc.charset != "undefined") {
		appendToQueryEscaped("oe", doc.charset);
	    }
	} else if (isSDOFormat(adFormat)) {
	    win.google_ad_url = "http://pagead2.googlesyndication.com/pagead/sdo?";
	    win.google_ad_url += "client="
                                 + escape(ensureDistAffPrefix(win.google_ad_client));
	} else {
	    win.google_ad_url = "http://pagead2.googlesyndication.com/pagead/ads?";
	    win.google_ad_url += "client="
                                 + escape(convertToCaName(win.google_ad_client));
	}

	appendItemToQuery("google_ad_host");

	var ad_slots_client = win.google_num_slots_by_client,
	    ad_slots_channel = win.google_num_slots_by_channel,
	    adFormats = win.google_prev_ad_formats_by_region,
	    ad_slotnames = win.google_prev_ad_slotnames_by_region;

	if (win.google_ad_region == null && win.google_ad_section != null) {
	    win.google_ad_region = win.google_ad_section;
	}

	var adRegion = win.google_ad_region == null ? "" : win.google_ad_region;

	// I believe the below somehow implement selection of the ad 
	// block in case multiple blocks are placed on a single page, 
	// but I'm currently unclear on the details. 
	// 
	if (isSDOFormat(adFormat)) {
	    if (win.google_num_sdo_slots) {
		win.google_num_sdo_slots = win.google_num_sdo_slots + 1;
	    } else {
		win.google_num_sdo_slots = 1;
	    }

	    if (win.google_num_sdo_slots > 4) {
		return false;
	    }
	} else if (usingLinkUnits(win)) {
	    if (win.google_num_0ad_slots) {
		win.google_num_0ad_slots = win.google_num_0ad_slots + 1;
	    } else {
		win.google_num_0ad_slots = 1;
	    }

	    if (win.google_num_0ad_slots > 3) {
		return false;
	    }
	} else if (win.google_cpa_choice == null) {
	    if (win.google_num_ad_slots) {
		win.google_num_ad_slots = win.google_num_ad_slots + 1;
	    } else {
		win.google_num_ad_slots = 1;
	    }

	    if (win.google_num_slots_to_rotate) {
		adFormats[adRegion] = null;
		ad_slotnames[adRegion] = null;

		if (win.google_num_slot_to_show == null) {
		    win.google_num_slot_to_show
                      = rnd % win.google_num_slots_to_rotate + 1;
		}

		if (win.google_num_slot_to_show != win.google_num_ad_slots) {
		    return false;
		}
	    } else if (win.google_num_ad_slots > 6 && adRegion == "") {
		return false;
	    }
	}

	appendToQuery("dt", date.getTime());
	appendItemToQuery("google_language");

	if (win.google_country) {
	    appendItemToQuery("google_country");
	} else {
	    appendItemToQuery("google_gl");
	}

	appendItemToQuery("google_region");
	appendItemToQueryEscaped("google_city");
	appendItemToQueryEscaped("google_hints");
	appendItemToQuery("google_safe");
	appendItemToQuery("google_encoding");
	appendItemToQuery("google_last_modified_time");
	appendItemToQueryEscaped("google_alternate_ad_url");
	appendItemToQuery("google_alternate_color");
	appendItemToQuery("google_skip");
	appendItemToQuery("google_targeting");

	var o = win.google_ad_client;

	if (! ad_slots_client[o]) {
	    ad_slots_client[o] = 1;
	    ad_slots_client.length += 1;
	} else{
	    ad_slots_client[o] += 1;
	}
	
	if (adFormats[adRegion]) {
	    if (!isSDOFormat(adFormat)) {
		appendToQueryEscaped("prev_fmts", adFormats[adRegion].toLowerCase());

		if (ad_slots_client.length > 1) {
		    appendToQuery("slot", ad_slots_client[o]);
		}
	    }
	}

	if (ad_slotnames[adRegion]) {
	    appendToQueryEscaped("prev_slotnames",
                                 ad_slotnames[adRegion].toLowerCase());
	}

	if (adFormat && !win.google_ad_slot) {
	    appendToQueryEscaped("format", adFormat.toLowerCase());
	    if (!isSDOFormat(adFormat)) {
		if(adFormats[adRegion]) {
		    adFormats[adRegion] = adFormats[adRegion] + "," + adFormat;
		} else{
		    adFormats[adRegion] = adFormat;
		}
	    }
	}

	if (win.google_ad_slot) {
	    if (ad_slotnames[adRegion]) {
		ad_slotnames[adRegion] = ad_slotnames[adRegion]
                                          + ","
                                          + win.google_ad_slot;
	    } else {
		ad_slotnames[adRegion] = win.google_ad_slot;
	    }
	}

	appendItemToQuery("google_max_num_ads");
	appendToQuery("output",win.google_ad_output);
	appendItemToQuery("google_adtest");
	appendItemToQuery("google_ad_callback");
	appendItemToQuery("google_ad_slot");
	appendItemToQueryEscaped("google_correlator");

	if (win.google_ad_channel) {
	    appendItemToQueryEscaped("google_ad_channel");

	    var result = "",
		channels = win.google_ad_channel.split("+");
	    
	    for(var t = 0; t < channels.length; t++) {
		var chan = channels[t];
		if (! ad_slots_channel[chan]) {
		    ad_slots_channel[chan] = 1;
		} else {
		    result += chan + "+";
		}
	    }

	    appendToQueryEscaped("pv_ch", result);
	}

	appendItemToQueryEscaped("google_page_url");
	appendIndexedItemToQuery("google_color_bg", rnd);
	appendIndexedItemToQuery("google_color_text", rnd);
	appendIndexedItemToQuery("google_color_link", rnd);
	appendIndexedItemToQuery("google_color_url", rnd);
	appendIndexedItemToQuery("google_color_border", rnd);
	appendIndexedItemToQuery("google_color_line", rnd);

	if (win.google_reuse_colors)
	    appendToQuery("reuse_colors",1);
	else 
	    appendToQuery("reuse_colors",0);

	appendItemToQuery("google_kw_type");
	appendItemToQueryEscaped("google_kw");
	appendItemToQueryEscaped("google_contents");
	appendItemToQuery("google_num_radlinks");
	appendItemToQuery("google_max_radlink_len");
	appendItemToQuery("google_rl_filtering");
	appendItemToQuery("google_rl_mode");
	appendItemToQuery("google_rt");
	appendItemToQueryEscaped("google_rl_dest_url");
	appendItemToQuery("google_num_radlinks_per_unit");
	appendItemToQuery("google_ad_type");
	appendItemToQuery("google_image_size");
	appendItemToQuery("google_ad_region");
	appendItemToQuery("google_feedback");
	appendItemToQueryEscaped("google_referrer_url");
	appendItemToQueryEscaped("google_page_location");
	appendItemToQuery("google_bid");
	appendItemToQuery("google_cust_age");
	appendItemToQuery("google_cust_gender");
	appendItemToQuery("google_cust_interests");
	appendItemToQuery("google_cust_id");
	appendItemToQuery("google_cust_job");
	appendItemToQuery("google_cust_u_url");
	appendItemToQuery("google_cust_l");
	appendItemToQuery("google_cust_lh");
	appendItemToQuery("google_cust_ch");
	appendItemToQuery("google_ed");
	appendItemToQueryEscaped("google_ui_features");
	appendItemToQueryEscaped("google_only_ads_with_video");
	appendItemToQueryEscaped("google_disable_video_autoplay");

	if (pageLocationMatches(win, doc) && doc.body) {
	    var v = doc.body.scrollHeight, // full document height 
		s = doc.body.clientHeight; // window height 

	    if (s && v) {
		appendToQueryEscaped("cc", Math.round(s*100/v));
	    }
	}

	establishAnalyticsState();

	appendToQuery("ga_vid", win.gaGlobal.vid);
	appendToQuery("ga_sid", win.gaGlobal.sid);
	appendToQuery("ga_hid", win.gaGlobal.hid);
	appendToQuery("ga_fc", win.gaGlobal.from_cookie);
	appendItemToQueryEscaped("google_analytics_webpropids");
	appendItemToQuery("google_ad_override");
	appendItemToQuery("google_flash_version");
	
	appendBrowserCapabilities(win, date);

	return true;
    }

    function makeAds() {
	var win = window,
	    doc = document;

	if (! buildQueryUrl()) {
	    return;
	}

	createAds(win, doc, win.google_ad_url, null);
	initVars(win);
    }

    function errorHandler(unused1, unused2, unused3) {
	makeAds();
	return true;
    }

    function pageLocationMatches(win, doc) {
	return win.top.location == doc.location;
    }

    // Tests whether we cannot render the ads in the given space? 
    // 
    function isTooSmall(win, doc) {
	var d = a.documentElement;

	if (pageLocationMatches(win, doc))
	    return false;

	if (win.google_ad_width && win.google_ad_height) {
	    var w = 1,
		h = 1;

	    if (win.innerHeight) {
		w = win.innerWidth;
		h = win.innerHeight;
	    } else if (d && d.clientHeight) {
		w = d.clientWidth;
		h = d.clientHeight;
	    } else if (doc.body) {
		w = doc.body.clientWidth;
		h = doc.body.clientHeight;
	    }

	    if (h > 2 * win.google_ad_height || w > 2 * win.google_ad_width) {
		return false;
	    }
	}
	
	return true;
    }

    function fillInUnsetVars(errorHandler) {
	var win = window,
	    origErrorHandler = win.onerror;

	win.onerror = errorHandler;

	if (win.google_ad_frameborder == null) {
	    win.google_ad_frameborder = 0;
	}

	if (win.google_ad_output == null) {
	    win.google_ad_output = "html";
	}

	if (isSDOFormat(win.google_ad_format)) {
	    var c = win.google_ad_format.match(/^(\d+)x(\d+)_.*/);

	    if (c) {
		win.google_ad_width=parseInt(c[1]);
		win.google_ad_height=parseInt(c[2]);
		win.google_ad_output="html";
	    }
	}

	if (win.google_ad_format == null && win.google_ad_output == "html") {
	    win.google_ad_format = win.google_ad_width + "x" + win.google_ad_height;
	}

	setLocation(win, document);

	if (win.google_num_slots_by_channel == null) {
	    win.google_num_slots_by_channel = [];
	}

	if (win.google_num_slots_by_client == null) {
	    win.google_num_slots_by_client =[];
	}

	if (win.google_prev_ad_formats_by_region == null) {
	    win.google_prev_ad_formats_by_region = [];
	}

	if (win.google_prev_ad_slotnames_by_region == null) {
	    win.google_prev_ad_slotnames_by_region = [];
	}
	
	if (win.google_correlator == null) {
	    win.google_correlator = (new Date).getTime();
	}

	if (win.google_adslot_loaded == null) {
	    win.google_adslot_loaded = {};
	}

	if (win.google_adContentsBySlot == null) {
	    win.google_adContentsBySlot = {};
	}
	
	if (win.google_flash_version == null) {
	    win.google_flash_version = detectFlashVersion().toString();
	}

	win.onerror = origErrorHandler;
    }

    function detectBrowser(str) {
	if (str in userAgentSubstrings) {
	    return userAgentSubstrings[str];
	}

	return userAgentSubstrings[str]
            = navigator.userAgent.toLowerCase().indexOf(str) != -1;
    }

    var userAgentSubstrings = {};

    function isSpecialAdClient(adOutput, adClient) {
	if (adOutput != "html") {
	    // This cannot currently happen, given how we're called. 
	    return false;
	}

	var d = {};

	d["ca-pub-7027491298716603"] = true;
	d["ca-pub-8344185808443527"] = true;
	d["ca-pub-9812682548211238"] = true;	
	d["ca-pub-4424308218891706"] = true;
	d["ca-pub-6922559858235084"] = true;
	d["ca-pub-6477563040863705"] = true;
	d["ca-google"] = true;

	return d[convertToCaName(adClient)] != null;
    }

    function splitQueryString(b) {

	// For this method's explanation, see 
	// http://gandolf.homelinux.org/~smhanov/blog/?id=21 

	var a = {},
	    d = b.split("?"),
	    e = d[d.length - 1].split("&");

	for(var c = 0; c < e.length; c++) {
	    var f = e[c].split("=");

	    if (f[0]) {
		try {
		    a[f[0].toLowerCase()] = f.length > 1 ?
			(window.decodeURIComponent ?
			   decodeURIComponent(f[1].replace(/\+/g," ")) : unescape(f[1]))
			: "";
		} catch(g) {}
	    }
	}

	return a;
    }

    function handleAdOverride() {
	var win = window,
	    args = splitQueryString(document.URL);

	if (args.google_ad_override) {
	    win.google_ad_override = args.google_ad_override;
	}
    }

    function detectFlashVersion() {
	var b = 0;

	if (navigator.plugins && navigator.mimeTypes.length) {
	    var a = navigator.plugins["Shockwave Flash"];
	    if (a && a.description) {
		b = a.description.replace(/([a-zA-Z]|\s)+/,"").split(".")[0];
	    }
	} else if (navigator.userAgent &&
                   navigator.userAgent.indexOf("Windows CE") >= 0) {
	    b = 3;
	    var d = 1;

	    while (d) {
		try {
		    d = new ActiveXObject("ShockwaveFlash.ShockwaveFlash." + (b+1));
		    b++;
		} catch(e) {
		    d = null;
		}
	    }
	} else if (detectBrowser("msie") && !window.opera) {
	    try {
		var d = new ActiveXObject("ShockwaveFlash.ShockwaveFlash.7");
	    } catch (e) {
		try{
		    var d = new ActiveXObject("ShockwaveFlash.ShockwaveFlash.6");
		    b = 6;
		    d.AllowScriptAccess = "always";
		} catch(e) {
		    if (b == 6) {
			return b;
		    }
		}

		try {
		    d = new ActiveXObject("ShockwaveFlash.ShockwaveFlash");
		} catch(e) {}
	    }

	    if (d != null) {
		b = d.GetVariable("$version").split(" ")[1].split(",")[0];
	    }
	}

	return b;
    };

    // This function establishes the location URL at which the 
    // ads are shown. 
    // 
    function setLocation(win, doc) {
	if (win.google_page_url == null) {

	    // Wow -- special URL massaging to extract meaningful values 
	    // from yieldmanager.com URLs. 
	    // 
	    if (specialSites[doc.domain] && doc.domain == "ad.yieldmanager.com") {
		var d = doc.URL.substring(doc.URL.lastIndexOf("http"));
		win.google_page_url = d;
		win.google_page_location = doc.location;
		win.google_referrer_url = d;
	    } else {
		win.google_page_url = doc.referrer;
		if (! isTooSmall(win, doc)) {
		    win.google_page_url = doc.location;
		    win.google_last_modified_time = Date.parse(doc.lastModified) / 1000;
		    win.google_referrer_url = doc.referrer;
		}
	    }
	} else {
	    win.google_page_location = doc.referrer;
	    if (! isTooSmall(win, doc)) {
		win.google_page_location = doc.location;
	    }
	}
    }

    var specialSites = {};
    specialSites["ad.yieldmanager.com"] = true;

    handleAdOverride();
    fillInUnsetVars(errorHandler);
    makeAds();
}) ()//enable custom 2d user interfaces, raphael?
//webGL 3d engine
//perform action such as save on a node
IB.action = {
	//do action
	serve: function(data, CB, method){
		if((typeof CB)!='function')CB = function(){};
		$.ajax({
			url: 'action/action.php',
			data: data,
			dataType: 'json',
			method: method,
			success: function(data){
				CB(data);
			}
		});
	},
	//post action
	post: function(data, CB){
		IB.action.serve(data, CB, 'post');
	},
	//get action
	get: function(data, CB){
		IB.action.serve(data, CB, 'get');
	},
	
	//save the node
	save: function(id, html, CB){
		var data = {
			action:'save',
			id:id,
			html:html
		};
		IB.action.post(data, CB);
	},
	//vote the node up
	voteUp: function(id, CB){
		var data = {
			action:'voteUp',
			id:id
		};
		IB.action.post(data, CB);
	},
	//vote the node down
	voteDown: function(id, CB){
		var data = {
			action:'voteDown',
			id:id
		};
		IB.action.post(data, CB);
	},
};
////code defining an advert node, which contains an advert, which when clicked by a user
//produces income for infoburp

//advert nodes cannot have children, have the whuffie of the parent node, and cannot
//be voted up or down. this means they can be freely added and removed from the 
//graph as requirements change.


		//amazon product buy advert - commission

		//https://github.com/Exeu/Amazon-ECS-PHP-Library

		//http://petewilliams.info/blog/2009/07/javascript-amazon-associate-link-localiser/
	
		//for example, I add a node a about a book, and the book is 
		//sold to me through amazon.

//set the subject of the advert node (parent node html)
		subject = parent.node.html;

		//spawn an advertising node with a suitable subject for it's parent node
		spawn.advert.amazon.node(subject)
		
			{
			/**
 * Search for any AMAZON product links and replace with a referral link to the visitor's local Amazon site
 * @author Pete Williams
 * @url http://petewilliams.info/blog/2009/07/javascript-amazon-associate-link-localiser/
 * @version 1.7.2
 */
 
/* ENTER YOUR AFFILIATE IDs BELOW - You can leave any blank that you don't have accounts for */
var arrAffiliates = {
	'com'   : '',
	'co.uk'	: '',
	'de'	: '',
	'fr'	: '',
	'ca'	: '',
	'co.jp'	: '',
	'jp'	: '',
	'it'	: '',
	'cn'	: '',
	'es'	: ''
};

// OPTIONAL - if your PHP file is in the same directory as the current page, then leave this as it is. Otherwise insert the path to the file here
var strUrlAjax = 'action/localise.advert.amazon.node.php';

var arrLinksToCheck=[];
var strTld;
var strAffiliateId;

function linkAmazon(objLink,strAsin)
{
this.arrLinkObjects=new Array(objLink);
if(strAsin){this.strAsin=strAsin}
this.affiliateLink=function()
{
for(intLink=0;
intLink<this.arrLinkObjects.length;intLink++)
{this.arrLinkObjects[intLink].href="http://www.amazon."+this.getActualTld()+"/exec/obidos/ASIN/"+this.strAsin+"/"+getAffiliateId(arrTldActual[1])}};
this.searchLink=function()
{
var objRegexTitle=new RegExp("amazon.[a-zA-Z.]{2,5}/([A-Za-z-]*)/dp");
arrResult=objRegexTitle.exec(this.arrLinkObjects[0].href);if(arrResult)
{strTitle=arrResult[1].replace(/-/g,"%20");
this.writeSearchLink(strTitle)
}
else
{
strUrlProduct=strUrlAjax+"?strAction=search&strLink="+this.arrLinkObjects[0].href;
objScript=document.createElement("script");
objScript.src=strUrlProduct;
document.getElementsByTagName("head")[0].appendChild(objScript)}};
this.addLink=function(objLink){this.arrLinkObjects.push(objLink)};
this.writeSearchLink=function(strTitle)
{
for(intSearchLink=0;
intSearchLink<this.arrLinkObjects.length;intSearchLink++)
{
this.arrLinkObjects[intSearchLink].href="http://www.amazon."+strTld+"/s?keywords="+strTitle+"&tag="+strAffiliateId}};
this.getAffiliateUrl=function()
{
return"http://www.amazon."+strTld+"/exec/obidos/ASIN/"+this.strAsin+"/"+strAffiliateId};
this.localiseLink=function()
{
for(i=0;i<this.arrLinkObjects.length;i++)
{
this.arrLinkObjects[i].href=this.getAffiliateUrl()}};
this.getActualTld=function(){var c=new RegExp("amazon.(.*?)/");
arrTldActual=c.exec(this.arrLinkObjects[0].href);
return arrTldActual[1]
}}
function findLocation()
{
if(typeof google!="undefined"&&google.loader.ClientLocation!=null)
{
var strCountry=google.loader.ClientLocation.address.country_code;
checkAmazonLinks(strCountry)}else{objScript=document.createElement("script");
objScript.src="http://freegeoip.net/json/?callback=checkAmazonLinks";
document.getElementsByTagName("head")[0].appendChild(objScript)
}}
function checkAmazonLinks(strCountry)
{
var objRegexAsin=new RegExp("/([A-Z0-9]{10})");
if(strCountry)
{
if(typeof strCountry.country_code!="undefined")
{
strCountry=strCountry.country_code
}
switch(strCountry)
{
case'GB':case'IE':strTld='co.uk';break;case'AT':strTld='de';
break;case'PT':strTld='es';
break;
default:strTld=(arrAffiliates[strCountry.toLowerCase()]!=null?strCountry.toLowerCase():'com');
break}strAffiliateId=getAffiliateId(strTld)
}
var arrLinks=document.getElementsByTagName("a");
for(i=0,j=arrLinks.length;i<j;i++)
{
var intIndex=arrLinks[i].href.toLowerCase().indexOf("amazon.");
if(intIndex>0&&intIndex<arrLinks[i].href.substring(8).indexOf("/")+8&&arrLinks[i].href.indexOf("/review/")<0)
{
var arrResults=objRegexAsin.exec(arrLinks[i].href);
if(arrResults){if(typeof(arrLinksToCheck[arrResults[1]])=="undefined")
{
objLink=new linkAmazon(arrLinks[i],arrResults[1]);
if(strTld&&strTld==objLink.getActualTld())
{
objLink.affiliateLink()
}
else
{
arrLinksToCheck[arrResults[1]]=objLink
}}
else
{
arrLinksToCheck[arrResults[1]].addLink(arrLinks[i])
}}
else
{
var intPreTag=arrLinks[i].href.indexOf("tag=");
if(!strTld){objLink=new linkAmazon(arrLinks[i]);
strTldChecked=objLink.getActualTld()
}
else
{
strTldChecked=strTld
}
if(intPreTag>0)
{
intPreTag+=4;var intPostTag=arrLinks[i].href.substring(intPreTag).indexOf("&");
if(intPostTag<0)
{
intPostTag=arrLinks[i].href.length-intPreTag
}
arrLinks[i].href=arrLinks[i].href.substring(0,intPreTag)+getAffiliateId(strTldChecked)+arrLinks[i].href.substring((intPostTag+intPreTag));
intPath=arrLinks[i].href.indexOf("/",arrLinks[i].href.indexOf("amazon"));
arrLinks[i].href="http://www.amazon."+strTldChecked+arrLinks[i].href.substring(intPath)
}
else
{
intPath=arrLinks[i].href.indexOf("/",arrLinks[i].href.indexOf("amazon"));
arrLinks[i].href=arrLinks[i].href.substring(0,arrLinks[i].href.indexOf("amazon."))+"amazon."+strTldChecked+arrLinks[i].href.substring(intPath)+(arrLinks[i].href.indexOf("?")>0?"&":"?")+"tag="+getAffiliateId(strTldChecked)
}
}
}
}
if(strTld)
{
var strLinksToCheck="";
for(strKey in arrLinksToCheck)
{
if(typeof arrLinksToCheck[strKey].strAsin!="undefined")
{
strLinksToCheck+=arrLinksToCheck[strKey].strAsin+"|"
}
}
if(strLinksToCheck.length)
{
var strUrlAjaxLinks=strUrlAjax+"?strTld="+strTld+"&strAffiliateId="+strAffiliateId+"&strLinks="+strLinksToCheck;
strUrlAjaxLinks=strUrlAjaxLinks.substring(0,strUrlAjaxLinks.length-1);
objScript=document.createElement("script");
objScript.src=strUrlAjaxLinks;
document.getElementsByTagName("head")[0].appendChild(objScript)
}
}
}
function getAffiliateId(strTLD)
{
return(arrAffiliates[strTLD]?arrAffiliates[strTLD]:arrAffiliatesSpares[strTLD])
}
if(window.addEventListener)
{
window.addEventListener("load",findLocation,false)
}
else
{
window.attachEvent("onload",findLocation)
}
var arrAffiliatesSpares={'co.uk':'pcrev05','com':'petewill-20','de':'petewill05-21','fr':'petewill-21','ca':'petewill00-20','co.jp':'petewill-22','jp':'petewill-22','it':'petewill04-21','cn':'petewill-23','es':'petewill0d4-21'};	
			}

//adds a node which contains an item for sale on ebay, earns infoburp commision income.

//http://developer.ebay.com/DevZone/javascript/docs/readme.html

//http://developer.ebay.com/devzone/finding/howto/gettingstarted_js_nv_json/gettingstarted_js_nv_json.html

//this gives us ebay products matching a keyword 

	keyword = parent.node.html

// Construct the request

	var url = "http://svcs.ebay.com/services/search/FindingService/v1";
    	url += "?OPERATION-NAME=findItemsByKeywords";
    	url += "&SERVICE-VERSION=1.0.0";
    	url += "&SECURITY-APPNAME=infoburp";
    	url += "&GLOBAL-ID=EBAY-US";
    	url += "&RESPONSE-DATA-FORMAT=JSON";
    	url += "&callback=_cb_findItemsByKeywords";
    	url += "&REST-PAYLOAD";
    	url += "&keywords=keyword";
    	url += "&paginationInput.entriesPerPage=1";

//execute the request


	var result = root.findItemsByKeywordsResponse[0].searchResult[0].item || [];

//add the result to infoburp as an advert node

	IB.advert.node.add(result)//code defining an advert node, which contains an advert, which when clicked by a user
//produces income for infoburp

//advert nodes cannot have children, have the whuffie of the parent node, and cannot
//be voted up or down. this means they can be freely added and removed from the 
//graph as requirements change.

//the node to which the advert node is attached is given whuffie according to the cpc,
//nodes with high cpc ads attached will earn more whuffie in this way.

//when an advert node is removed, the whuffie it gave to the node it spawned from is
//taken back, also.

//this encourages infoburp to concentrate on the most profitable topics, to ensure good 
//income.

		//google adsense advert - income per click
		
		//set the subject of the advert node (parent node html)
		subject = parent.node.html;

		//spawn an advertising node with a suitable subject for it's parent node
		add.advert.google.node(parentnode)
		
			{

			IB.advert.google.node.add(parentnode);	

			}
		//remove a specific ad node
		remove.advert.google.node(parentnode)
		
			{

			IB.advert.google.node.add(parentnode);	

			}
		//spawn a high cpc ad node
		high.cpc.add()

			{
			//search for high cpc keywords

			//add ads based on those keywords
			IB.advert.google.node.add(subject);
			}

		//despawn a high cpc ad node
		high.cpc.remove()

			{
			//search for high cpc keywords

			//remove ads based on those keywords
			IB.advert.google.node.remove(subject);
			}

		//spawn a low cpc ad node
		low.cpc.add()

			{
			//search for low cpc keywords

			//add ads based on those keywords
			IB.advert.google.node.add(subject);
			}

		//despawn a low cpc ad node
		low.cpc.remove()
			
			{
			//search for low cpc keywords, currently in use

			//remove ads based on those keywords
			IB.advert.google.node.remove(subject);
			}

// Pseudo-namespaces with automatic evaluation. 
(function(){
    
    // Associative arrays for URL-relevant strings.  I don't see an 
    // obvious reason for the two separate arrays. 
    // 
    var gStrDefs = {
	google_ad_channel:"channel",
	google_ad_host:"host",
	google_ad_region:"region",
	google_ad_section:"region",
	google_ad_type:"ad_type",
	google_adtest:"adtest",
	google_alternate_ad_url:"alternate_ad_url",
	google_alternate_color:"alt_color",
	google_bid:"bid",
	google_city:"gcs",
	google_color_bg:"color_bg",
	google_color_border:"color_border",
	google_color_line:"color_line",
	google_color_link:"color_link",
	google_color_text:"color_text",
	google_color_url:"color_url",
	google_contents:"contents",
	google_country:"gl",
	google_cust_age:"cust_age",
	google_cust_ch:"cust_ch",
	google_cust_gender:"cust_gender",
	google_cust_id:"cust_id",
	google_cust_interests:"cust_interests",
	google_cust_job:"cust_job",
	google_cust_l:"cust_l",
	google_cust_lh:"cust_lh",
	google_cust_u_url:"cust_u_url",
	google_disable_video_autoplay:"disable_video_autoplay",
	google_ed:"ed",
	google_encoding:"oe",
	google_feedback:"feedback_link",
	google_flash_version:"flash",
	google_gl:"gl",
	google_hints:"hints",
	google_kw:"kw",
	google_kw_type:"kw_type",
	google_language:"hl",
	google_referrer_url:"ref",
	google_region:"gr",
	google_reuse_colors:"reuse_colors",
	google_safe:"adsafe",
	google_targeting:"targeting",
	google_ui_features:"ui"},
	
	gStrDefsAddl = {
        google_ad_format:"format",
	google_ad_output:"output",
	google_ad_callback:"callback",
	google_ad_override:"google_ad_override",
	google_ad_slot:"slotname",
	google_analytics_webpropids:"ga_wpids",
	google_correlator:"correlator",
	google_cpa_choice:"cpa_choice",
	google_image_size:"image_size",
	google_last_modified_time:"lmt",
	google_max_num_ads:"num_ads",
	google_max_radlink_len:"max_radlink_len",
	google_num_radlinks:"num_radlinks",
	google_num_radlinks_per_unit:"num_radlinks_per_unit",
	google_only_ads_with_video:"only_ads_with_video",
	google_page_location:"loc",
	google_page_url:"url",
	google_rl_dest_url:"rl_dest_url",
	google_rl_filtering:"rl_filtering",
	google_rl_mode:"rl_mode",
	google_rt:"rt",
	google_skip:"skip"};


    // Looks up a string in the global associative arrays, and returns 
    // null on failure. 
    // 
    function lookupGoogleString(key) {
	return gStrDefs[key] || gStrDefsAddl[key] || null;
    }

    var Doc = document;

    // This extracts Google Analytics information from any available 
    // cookies, and if not available, generates suitable numerical 
    // identifiers as needed. 
    // 
    // The resulting object is hooked into the window object as 
    // window.gaGlobal and also returned. 
    // 
    function establishAnalyticsState() {
	var cookie = Doc.cookie,

	    // A crude random number or numerical identifier 
	    a = Math.round((new Date).getTime() / 1000),

	    // predicates testing for various Google Analytics cookies 
	    hasGaCookieA = cookie.indexOf("__utma=") > -1,
	    hasGaCookieB = cookie.indexOf("__utmb=") > -1,
	    hasGaCookieC = cookie.indexOf("__utmc=") > -1,
	    f,
	    g = {};

	if (hasGaCookieA) {
	    // Separate out the numbers of a utma-style cookie. Example: 
	    // 173272373.449341548.1193258541.1194650238.1195068298.3 
	    // 
	    f = cookie.split("__utma=")[1].split(";")[0].split(".");

	    // If not all cookies exist, use new value. 
	    g.sid = (!hasGaCookieB || !hasGaCookieC ? a : f[4]) + "";
	    g.vid = f[1] + "." + f[2];
	    g.from_cookie = true;
	} else {
	    g.sid = window && window.gaGlobal && window.gaGlobal.sid ?
		window.gaGlobal.sid : a + "";
	    g.vid = window && window.gaGlobal && window.gaGlobal.vid ?
		window.gaGlobal.vid : Math.round(Math.random()*2147483647) + "." + a;
	    g.from_cookie = false;
	}

	g.hid = window && window.gaGlobal && window.gaGlobal.hid ?
	    window.gaGlobal.hid : Math.round(Math.random()*2147483647);

	window.gaGlobal = g;

	return g;
    }

    // ---- Construction of "IDICommon" componenet ----------------------- 
    // =================================================================== 

    (function() {

	function b(){}

	// Returns everything following the first occurrence of "#" in 
	// the input string, or an empty string if "#" does not exist. 
	// 
	b.prototype.getHash = function(e) {
	    var c = e.indexOf("#") + 1;
	    return c ? e.substr(c) : "";
	};

	b.prototype.htmlEscape = function(e) {
	    return /[&<>\"]/.test(e) ? e.replace(/&/g,"&amp;")
                                               .replace(/</g,"&lt;")
                                               .replace(/>/g,"&gt;")
                                               .replace(/\"/g,"&quot;") : e;
	};

	// Creates and returns an iframe tag, given an associative 
	// array of attributes. 
	// 
	b.prototype.makeIframeTag = function(e) {
	    var c = "<iframe";
	    for (var f in e) {
		c += " " + f + '="' + this.htmlEscape(e[f]) + '"';
	    }

	    return c + "></iframe>";
	};

	// Returns an iframe of name frameId for the given window. 
	// 
	b.prototype.getIframe = function(win, frameId) {
	    try {
		return win.frames[frameId];
	    } catch (e) {
		return null;
	    }
	};

	b.prototype.makeIframeNode = function(attribs) {
	    var el = document.createElement("iframe");
	    for (var a in attribs) {
		el.setAttribute(a, attribs[a]);
	    }

	    return el;
	};

	b.prototype.appendHiddenIframe = function(name, url) {
	    var f = this;

	    // This launches a separate "thread" of sorts to append 
	    // the iframe to the document as soon as possible. 
	    // 
	    setTimeout(function() {
	                   document.body.appendChild(f.makeIframeNode({id:name,
                                                                       name:name,
                                                                       src:url,
                                                                       width:0,
                                                                       height:0,
                                                                       frameBorder:0}))
		       }, 0);
	};

	b.prototype.writeHiddenIframe = function(name, url) {
	    var f = this;
	    document.write(f.makeIframeTag({id:name, name:name, src:url,
                                            width:0, height:0, frameBorder:0}));
	};

	// This method chops a URI argument string into substrings 
	// that do not cut %-encoded values in half, while each 
	// substring is no longer than the provided maximum length. 
	// The resulting vector of substrings is returned. 
	// 
	b.prototype.splitURIComponent = function(argStr, maxLen) {
	    var results = [],
	        len = argStr.length,
	        k = 0;

	    while (k < len) {
		var argSub = argStr.substr(k, maxLen),
		    argSubLen = argSub.length;

		if (k + argSubLen < len) {
		    for (var i = 1; i < 3; ++i) {
			if (argSub.charAt(argSubLen - i) == "%") {
			    argSub = argSub.substr(0, argSubLen -= i);
			}
		    }
		}

		results.push(argSub);
		k += argSubLen;
	    }

	    return results;
	};

	b.prototype.exportSingleton = function(name, obj, attrTable) {
	    if (! window[name]) {
		var g = window[name] = new obj;

		// Hook the methods/variables into the new object 
		for (var k = 0; k < attrTable.length; ++k) {
		    g[attrTable[k][0]] = attrTable[k][1];
		}
	    }
	};

	var proto = b.prototype,
	    attrTable = [["getHash", proto.getHash],
			 ["htmlEscape", proto.htmlEscape],
			 ["makeIframeTag", proto.makeIframeTag],
			 ["getIframe", proto.getIframe],
			 ["makeIframeNode", proto.makeIframeNode],
			 ["appendHiddenIframe", proto.appendHiddenIframe],
			 ["writeHiddenIframe", proto.writeHiddenIframe],
			 ["splitURIComponent", proto.splitURIComponent],
			 ["exportSingleton", proto.exportSingleton],
			 ["MAX_URL_LENGTH", 4095],
			 ["IDI_DEFAULT_POLLING_INTERVAL", 1000]];

	// Hook the functions defined above into the window 
	// object under key "IDICommon", thus making available 
	// globally the IDICommon object. 
	// 
	b.prototype.exportSingleton("IDICommon", b, attrTable);

    }) ();

    // ---- Construction of "IDIHost" componenet ------------------------- 
    // =================================================================== 

    (function() {
	function addAttrs(dst, src) {
	    for (var g in src) {
		dst[g] = src[g];
	    }
	}

	function a() {
	    // Take URL as originally requested and change it to the 
	    // robots.txt URL. 
	    // 
	    this.hostRelayUrl =
                window.location.href.replace(/([^:\/])\/.*$/, "$1/robots.txt");
	    this.moduleRelayUrl = "";
	    this.frameUses = {};
	    this.moduleIds = {};
	    this.frameHashes = {};
	    this.frameUrls = {};
	    this.frameListeners = {};
	}

	// A way to dispatch messages to individual iframe modules, 
	// presumably for external use, since the method is not 
	// actually used in this code. 
	// 
	a.prototype.postMessageToModule = function(frameId, msg, obj) {
	    var url;

	    if (typeof obj == "object") {
		url = obj.moduleRelayUrl;
	    }

	    var id = this.moduleIds[frameId];

	    if (isNaN(id)) {
		throw new Error("Invalid module id");
	    } else {
		var mru = (typeof url == "string") ?
		           url :
		           this.getModuleRelayUrl(this.frameUrls[frameId]),
		    encMsg = encodeURIComponent(msg) + "$",
		    lenAvail = IDICommon.MAX_URL_LENGTH - 1 - mru.length,
		    argsChunks = IDICommon.splitURIComponent(encMsg, lenAvail),
		    numargsChunks = argsChunks.length;

		for (var p = 0; p < numArgsChunks; ++p) {
		    IDICommon.appendHiddenIframe(frameId + "_" + (id + p),
						 mru + "#" + argsChunks[p]);
		}
		
		this.moduleIds[frameId] += numArgsChunks;
	    }
	};

	a.prototype.registerListener = function(frameId, callback, g) {
	    this.unregisterListener(frameId);
	    this.frameListeners[frameId] =
	        window.setInterval(function() { this.dispatch(frameId, callback) },
				   typeof g == "object" && g.pollingInterval
				   || IDICommon.IDI_DEFAULT_POLLING_INTERVAL);
	};

	a.prototype.unregisterListener = function(frameId) {
	    window.clearInterval(this.frameListeners[frameId]);
	    this.frameListeners[frameId] = 0;
	};
	
	a.prototype.setHostRelayUrl = function(c) {
	    this.hostRelayUrl = c;
	};
	
	a.prototype.setModuleRelayUrl = function(c) {
	    this.moduleRelayUrl = c;
	};
	
	a.prototype.getModuleRelayUrl = function(c) {
	    return this.moduleRelayUrl ||
	           c.replace(/([^:\/]\/).*$/,"$1ig/idi_relay");
	};

	// This function is called by the the listeners established by 
	// registerListener() above. The given frame is looked up, its 
	// usage recorded, and the given callback dispatched for each 
	// physical frame affected. 
	// 
	a.prototype.dispatch = function(frameId, callback) {
	    var win = window.frames[frameId];

	    if (win) {
		var j;
		while (j = IDICommon.getIframe(win, frameId + "_"
                                                            + this.frameUses[frameId])) {
		    try {
			if (j.location.href == "about:blank") {
			    break;
			}
		    } catch(l) {
			break;
		    }

		    this.frameHashes[frameId] += IDICommon.getHash(j.location.href);
		    ++this.frameUses[frameId];
		}

		var i = this.frameHashes[frameId].split("$"),
		    o = i.length - 1;

		if (o > 0) {
		    this.frameHashes[frameId] = i[o];
		    for (var q = 0; q < o; ++q) {
		       callback(decodeURIComponent(i[q]), frameId);
		    }
		}
	    }
	};

	// This is the main method that generates the iframe content. 
	// 
	a.prototype.createModule = function(gau, frameId, adWidth, adHeight, params) {

	    var attrs = { frameBorder:0, scrolling:"no" },
	        ia, cb, up, pi, pd;

	    if (typeof params == "object") {
		ia = params.iframeAttrs;
		cb = params.callback;
		up = params.userPrefs;
		pi = params.pollingInterval; // unused 
		pd = params.parentDivId;
	    }

	    if (typeof ia == "object") {
		addAttrs(attrs, ia)
	    }

	    addAttrs(attrs, {id:frameId, name:frameId, src:gau,
                             width:adWidth, height:adHeight});

	    this.frameUses[frameId] = 0;
	    this.moduleIds[frameId] = 0;
	    this.frameHashes[frameId] = "";
	    this.frameUrls[frameId] = gau;

	    var addlArgs = [];

	    if (typeof up == "object") {
		for (var s in up) {
		    addlArgs.push(encodeURIComponent(s)
                                  + "="
                                  + encodeURIComponent(up[s]));
		}
	    }

	    if (typeof cb == "function") {
		addlArgs.push("idi_hr=" + encodeURIComponent(this.hostRelayUrl));
		this.registerListener(frameId, cb, params);
	    }

	    if (addlArgs.length) {
		var argsStr = addlArgs.join("&");

		// If resulting iframe URL is too long, trigger 
		// relay processing. 
		// 
		if (attrs.src.length + 1 + argsStr.length > IDICommon.MAX_URL_LENGTH) {

		    // Add separator to argument string. 
		    argsStr += "$";

		    // The arguments are cut into pieces, and multiple 
		    // iframes are requested, one for each chunk. 
		    // 
		    var mru = this.getModuleRelayUrl(gau),
			lenAvail = IDICommon.MAX_URL_LENGTH - 1 - mru.length,
			argsChunks = IDICommon.splitURIComponent(argsStr, lenAvail),
			numArgsChunks = argsChunks.length;

		    for (var s = 0; s < numArgsChunks; ++s) {
			var frameIdCount = frameId + "_" + s,
			    chunkUrl = mru + "#" + argsChunks[s];

			if (pd) {
			    var div = document.getElementById(pd);

                            // This is bizarre -- it looks like this is 
			    // supposed to call IDICommon.makeIframeNode(), 
			    // since a.e() was that function's original 
                            // name. However, "this.e" doesn't seem to be 
                            // defined for function a() (i.e., this). 
                            // 
                            // How does this work? 
			    // 
			    div.innerHTML =
				div.innerHTML +
				this.e( {id:frameIdCount, name:frameIdCount, src:chunkUrl,
					 width:0, height:0, frameBorder:0});
			} else {
			    IDICommon.writeHiddenIframe(frameIdCount, chunkUrl);
			}
		    }
		    
		    this.moduleIds[frameId] += numArgsChunks;
		    argsStr = "";
	        }

		attrs.src += "#" + argsStr;
	    }

	    if (pd) {
		var div = document.getElementById(pd);
		div.innerHTML = div.innerHTML + IDICommon.makeIframeTag(attrs);
	    } else {
		document.write(IDICommon.makeIframeTag(attrs));
	    }
	};

	var proto = a.prototype,
	    attrTable = [["setHostRelayUrl", proto.setHostRelayUrl],
			 ["setModuleRelayUrl", proto.setModuleRelayUrl],
			 ["getModuleRelayUrl", proto.getModuleRelayUrl],
			 ["createModule", proto.createModule],
			 ["postMessageToModule", proto.postMessageToModule],
			 ["registerListener", proto.registerListener],
			 ["unregisterListener", proto.unregisterListener]];

	// Make the function set available globally under IDIHost. 
	// 
	IDICommon.exportSingleton("IDIHost", a , attrTable);
    }) ();

    // ---- Non-modularized code ----------------------------------------- 
    // =================================================================== 

    function quoteString(b) {
	return b != null ? '"' + b + '"' : '""';
    }

    function encodeUri(uri) {
	if (typeof encodeURIComponent == "function") { 
	    return encodeURIComponent(uri);
	} else {
	    return escape(uri);
	}
    }

    function appendToQuery(key, val) {
	if (key && val) {
	    window.google_ad_url += "&" + key + "=" + val;
	}
    }

    function appendItemToQuery(id) {
	var win = window,
	    key = lookupGoogleString(id),
	    val = win[key];

	appendToQuery(key, val);
    }

    function appendToQueryEscaped(b,a) {
	if (a) {
	    appendToQuery(b, encodeUri(a));
	}
    }

    function appendItemToQueryEscaped(id) {
	var win = window,
	    key = lookupGoogleString(id),
	    val = win[id];

	appendToQueryEscaped(key, val);
    }

    function appendIndexedItemToQuery(id, index) {
	var win = window,
	    key = lookupGoogleString(id),
	    val = win[id];

	if(key && val && typeof val == "object") {
	    val = val[index % val.length];
	}

	appendToQuery(key, val);
    }

    // This function is adding a "fingerprint" of browser capabilities 
    // to the google_ad_url, collecting all kinds of things about your 
    // browser setup and usage. 
    // 
    function appendBrowserCapabilities(b,a) {
	var scr = b.screen,
	    e = navigator.javaEnabled(),
	    c =- a.getTimezoneOffset();
	
	// If we have screen information via the window, 
	// add information to the window's google_ad_url. 
	// 
	if (d) {
	    appendToQuery("u_h", scr.height);
	    appendToQuery("u_w", scr.width);
	    appendToQuery("u_ah", scr.availHeight);
	    appendToQuery("u_aw", scr.availWidth);
	    appendToQuery("u_cd", scr.colorDepth);
	}

	// Add timezone delta + java status, and length of history. 
	// 
	appendToQuery("u_tz", c);
	appendToQuery("u_his", history.length);
	appendToQuery("u_java", e);

	// Add number of plugins 
	// 
	if (navigator.plugins) {
	    appendToQuery("u_nplug",navigator.plugins.length);
	}

        // Add number of mimetypes 
        // 
	if(navigator.mimeTypes){
	    appendToQuery("u_nmime",navigator.mimeTypes.length);
	}
    }

    function convertToCaName(b) {
	if (b) {
	    b = b.toLowerCase();
	    if (b.substring(0,3) != "ca-") {
		b = "ca-" + b;
	    }
	}

	return b;
    }

    function ensureDistAffPrefix(b) {
	if (b) {
	    b = b.toLowerCase();
	    if (b.substring(0,9) != "dist-aff-") {
		b = "dist-aff-" + b;
	    }
	}

	return b;
    }

    // Retrieves an element from the DOM and sets 
    // its height to the given value. 
    // 
    function setElementHeight(id, height) {
	var el = document.getElementById(id);
	el.style.height = height + "px";
    }

    function setFlashAdHeight(str, elementId, timer) {
	window.clearTimeout(timer);
	var re = /^google_resize_flash_ad_idi\((\d+)\)/,
	    results = str.match(re);

	if (results) {
	    setElementHeight(elementId, results[1]);
	}
    }

    // This function generates the Google ads output, either 
    // indirectly via JavaScript code being written to the document, 
    // or via an iframe and HTML. 
    // 
    function createAds(win, doc, gau /* Google ad url */, e /* always null */) {
	gau = gau.substring(0,2000);
	gau = gau.replace(/%\w?$/,"");

	if ((win.google_ad_output == "js" || win.google_ad_output == "json_html") &&
	    (win.google_ad_request_done || win.google_radlink_request_done)) {
	    doc.write('<script language="JavaScript1.1" src='
                      + quoteString(gau)
                      + "><\/script>");
	} else if (win.google_ad_output == "html") {
	    if (win.name != "google_ads_frame") {
		if (e != null) { // This cannot currently happen 
		    doc.write('<div id="' + e + '">');
		}

		if (isSpecialAdClient(win.google_ad_output, win.google_ad_client)) {
		    IDIHost.setModuleRelayUrl("http://pagead2.googlesyndication.com/"
                                              + "pagead/idi_relay.html");
		    var c = 0;

		    if (win.google_num_0ad_slots) {
			c += win.google_num_0ad_slots;
		    }

		    if (win.google_num_ad_slots) {
			c += win.google_num_ad_slots;
		    }

		    if (win.google_num_sdo_slots) {
			c += win.google_num_sdo_slots;
		    }
		    
		    var f = "google_inline_div" + c,
			g = "<div id=" + quoteString(f)
                            + ' style="position:relative;width:' + win.google_ad_width
                            + 'px"></div><div style="position:relative;width:'
                            +  win.google_ad_width + "px;height:" + win.google_ad_height
                            + 'px;z-index:-1"></div>';
		    
		    doc.write(g);

		    var frameId = "google_frame" + c,
			timer = win.setTimeout(function(){ IDIHost.unregisterListener(k) },
                                               5000);
		    
		    IDIHost.createModule(gau, frameId,
                                         win.google_ad_width,
                                         win.google_ad_height,
					 { callback:function(str, elmentId)
                                             { setFlashAdHeight(str, elementId, timer) },
					   pollingInterval:500,
					   iframeAttrs:{ style:"position: absolute;left:0px",
                                                         marginWidth:"0",
						         marginHeight:"0",
                                                         vspace:"0", hspace:"0", 
						         allowTransparency:"true"},
					   parentDivId:f});
		} else {
		    doc.write('<iframe name="google_ads_frame" width='
                              + quoteString(win.google_ad_width)
			      + " height=" + quoteString(win.google_ad_height)
			      + " frameborder=" + quoteString(win.google_ad_frameborder)
			      + " src=" + quoteString(gau)
			      + ' marginwidth="0" marginheight="0" vspace="0" hspace="0" '
                              + ' allowtransparency="true" scrolling="no">');
		    doc.write("</iframe>");
		}
		
		if (e != null) {
		    doc.write("</div>");
		}
	    }
	} else if (win.google_ad_output == "textlink") {
            
	    // This has the same effect as the initial if()-clause 
	    // above. 
	    // 
	    doc.write('<script language="JavaScript1.1" src='
                      + quoteString(gau)
                      + "><\/script>");
	}
    }

    // This is an initializer, taking all the string definitions and 
    // initializing them to null as members of the window. 
    // 
    function initVars(win) {
	for (var def in gStrDefs) {
	    win[def] = null;
	}

	for (var a in gStrDefsAddl) {
	    win[def] = null;
	}
    }

    // Returns true if we are using link units (one of the alternative 
    // display formats). I don't know the radlinks stuff. 
    // 
    function usingLinkUnits(win) {
	if (win.google_ad_format) {
	    return win.google_ad_format.indexOf("_0ads") > 0;
	}

	return win.google_ad_output != "html" && win.google_num_radlinks > 0;
    }

    function isSDOFormat(b) {
	return b && b.indexOf("_sdo") != -1;
    }

    function buildQueryUrl() {
	var win = window,
	    doc = document,
	    date = new Date,
	    rnd = e.getTime(),
	    adFormat = win.google_ad_format;

	// Cost per Action choice -- Defined only in the some of the 
	// snippets the hoster carries in his webpages. 
	// 
	if (win.google_cpa_choice != null) {
	    win.google_ad_url = "http://pagead2.googlesyndication.com/cpa/ads?";
	    win.google_ad_url += "client="
                                 + escape(convertToCaName(win.google_ad_client));
	    win.google_ad_region = "_google_cpa_region_";
	    appendItemToQuery("google_cpa_choice");

	    if (typeof doc.characterSet != "undefined") {
		appendToQueryEscaped("oe", doc.characterSet);
	    } else if (typeof doc.charset != "undefined") {
		appendToQueryEscaped("oe", doc.charset);
	    }
	} else if (isSDOFormat(adFormat)) {
	    win.google_ad_url = "http://pagead2.googlesyndication.com/pagead/sdo?";
	    win.google_ad_url += "client="
                                 + escape(ensureDistAffPrefix(win.google_ad_client));
	} else {
	    win.google_ad_url = "http://pagead2.googlesyndication.com/pagead/ads?";
	    win.google_ad_url += "client="
                                 + escape(convertToCaName(win.google_ad_client));
	}

	appendItemToQuery("google_ad_host");

	var ad_slots_client = win.google_num_slots_by_client,
	    ad_slots_channel = win.google_num_slots_by_channel,
	    adFormats = win.google_prev_ad_formats_by_region,
	    ad_slotnames = win.google_prev_ad_slotnames_by_region;

	if (win.google_ad_region == null && win.google_ad_section != null) {
	    win.google_ad_region = win.google_ad_section;
	}

	var adRegion = win.google_ad_region == null ? "" : win.google_ad_region;

	// I believe the below somehow implement selection of the ad 
	// block in case multiple blocks are placed on a single page, 
	// but I'm currently unclear on the details. 
	// 
	if (isSDOFormat(adFormat)) {
	    if (win.google_num_sdo_slots) {
		win.google_num_sdo_slots = win.google_num_sdo_slots + 1;
	    } else {
		win.google_num_sdo_slots = 1;
	    }

	    if (win.google_num_sdo_slots > 4) {
		return false;
	    }
	} else if (usingLinkUnits(win)) {
	    if (win.google_num_0ad_slots) {
		win.google_num_0ad_slots = win.google_num_0ad_slots + 1;
	    } else {
		win.google_num_0ad_slots = 1;
	    }

	    if (win.google_num_0ad_slots > 3) {
		return false;
	    }
	} else if (win.google_cpa_choice == null) {
	    if (win.google_num_ad_slots) {
		win.google_num_ad_slots = win.google_num_ad_slots + 1;
	    } else {
		win.google_num_ad_slots = 1;
	    }

	    if (win.google_num_slots_to_rotate) {
		adFormats[adRegion] = null;
		ad_slotnames[adRegion] = null;

		if (win.google_num_slot_to_show == null) {
		    win.google_num_slot_to_show
                      = rnd % win.google_num_slots_to_rotate + 1;
		}

		if (win.google_num_slot_to_show != win.google_num_ad_slots) {
		    return false;
		}
	    } else if (win.google_num_ad_slots > 6 && adRegion == "") {
		return false;
	    }
	}

	appendToQuery("dt", date.getTime());
	appendItemToQuery("google_language");

	if (win.google_country) {
	    appendItemToQuery("google_country");
	} else {
	    appendItemToQuery("google_gl");
	}

	appendItemToQuery("google_region");
	appendItemToQueryEscaped("google_city");
	appendItemToQueryEscaped("google_hints");
	appendItemToQuery("google_safe");
	appendItemToQuery("google_encoding");
	appendItemToQuery("google_last_modified_time");
	appendItemToQueryEscaped("google_alternate_ad_url");
	appendItemToQuery("google_alternate_color");
	appendItemToQuery("google_skip");
	appendItemToQuery("google_targeting");

	var o = win.google_ad_client;

	if (! ad_slots_client[o]) {
	    ad_slots_client[o] = 1;
	    ad_slots_client.length += 1;
	} else{
	    ad_slots_client[o] += 1;
	}
	
	if (adFormats[adRegion]) {
	    if (!isSDOFormat(adFormat)) {
		appendToQueryEscaped("prev_fmts", adFormats[adRegion].toLowerCase());

		if (ad_slots_client.length > 1) {
		    appendToQuery("slot", ad_slots_client[o]);
		}
	    }
	}

	if (ad_slotnames[adRegion]) {
	    appendToQueryEscaped("prev_slotnames",
                                 ad_slotnames[adRegion].toLowerCase());
	}

	if (adFormat && !win.google_ad_slot) {
	    appendToQueryEscaped("format", adFormat.toLowerCase());
	    if (!isSDOFormat(adFormat)) {
		if(adFormats[adRegion]) {
		    adFormats[adRegion] = adFormats[adRegion] + "," + adFormat;
		} else{
		    adFormats[adRegion] = adFormat;
		}
	    }
	}

	if (win.google_ad_slot) {
	    if (ad_slotnames[adRegion]) {
		ad_slotnames[adRegion] = ad_slotnames[adRegion]
                                          + ","
                                          + win.google_ad_slot;
	    } else {
		ad_slotnames[adRegion] = win.google_ad_slot;
	    }
	}

	appendItemToQuery("google_max_num_ads");
	appendToQuery("output",win.google_ad_output);
	appendItemToQuery("google_adtest");
	appendItemToQuery("google_ad_callback");
	appendItemToQuery("google_ad_slot");
	appendItemToQueryEscaped("google_correlator");

	if (win.google_ad_channel) {
	    appendItemToQueryEscaped("google_ad_channel");

	    var result = "",
		channels = win.google_ad_channel.split("+");
	    
	    for(var t = 0; t < channels.length; t++) {
		var chan = channels[t];
		if (! ad_slots_channel[chan]) {
		    ad_slots_channel[chan] = 1;
		} else {
		    result += chan + "+";
		}
	    }

	    appendToQueryEscaped("pv_ch", result);
	}

	appendItemToQueryEscaped("google_page_url");
	appendIndexedItemToQuery("google_color_bg", rnd);
	appendIndexedItemToQuery("google_color_text", rnd);
	appendIndexedItemToQuery("google_color_link", rnd);
	appendIndexedItemToQuery("google_color_url", rnd);
	appendIndexedItemToQuery("google_color_border", rnd);
	appendIndexedItemToQuery("google_color_line", rnd);

	if (win.google_reuse_colors)
	    appendToQuery("reuse_colors",1);
	else 
	    appendToQuery("reuse_colors",0);

	appendItemToQuery("google_kw_type");
	appendItemToQueryEscaped("google_kw");
	appendItemToQueryEscaped("google_contents");
	appendItemToQuery("google_num_radlinks");
	appendItemToQuery("google_max_radlink_len");
	appendItemToQuery("google_rl_filtering");
	appendItemToQuery("google_rl_mode");
	appendItemToQuery("google_rt");
	appendItemToQueryEscaped("google_rl_dest_url");
	appendItemToQuery("google_num_radlinks_per_unit");
	appendItemToQuery("google_ad_type");
	appendItemToQuery("google_image_size");
	appendItemToQuery("google_ad_region");
	appendItemToQuery("google_feedback");
	appendItemToQueryEscaped("google_referrer_url");
	appendItemToQueryEscaped("google_page_location");
	appendItemToQuery("google_bid");
	appendItemToQuery("google_cust_age");
	appendItemToQuery("google_cust_gender");
	appendItemToQuery("google_cust_interests");
	appendItemToQuery("google_cust_id");
	appendItemToQuery("google_cust_job");
	appendItemToQuery("google_cust_u_url");
	appendItemToQuery("google_cust_l");
	appendItemToQuery("google_cust_lh");
	appendItemToQuery("google_cust_ch");
	appendItemToQuery("google_ed");
	appendItemToQueryEscaped("google_ui_features");
	appendItemToQueryEscaped("google_only_ads_with_video");
	appendItemToQueryEscaped("google_disable_video_autoplay");

	if (pageLocationMatches(win, doc) && doc.body) {
	    var v = doc.body.scrollHeight, // full document height 
		s = doc.body.clientHeight; // window height 

	    if (s && v) {
		appendToQueryEscaped("cc", Math.round(s*100/v));
	    }
	}

	establishAnalyticsState();

	appendToQuery("ga_vid", win.gaGlobal.vid);
	appendToQuery("ga_sid", win.gaGlobal.sid);
	appendToQuery("ga_hid", win.gaGlobal.hid);
	appendToQuery("ga_fc", win.gaGlobal.from_cookie);
	appendItemToQueryEscaped("google_analytics_webpropids");
	appendItemToQuery("google_ad_override");
	appendItemToQuery("google_flash_version");
	
	appendBrowserCapabilities(win, date);

	return true;
    }

    function makeAds() {
	var win = window,
	    doc = document;

	if (! buildQueryUrl()) {
	    return;
	}

	createAds(win, doc, win.google_ad_url, null);
	initVars(win);
    }

    function errorHandler(unused1, unused2, unused3) {
	makeAds();
	return true;
    }

    function pageLocationMatches(win, doc) {
	return win.top.location == doc.location;
    }

    // Tests whether we cannot render the ads in the given space? 
    // 
    function isTooSmall(win, doc) {
	var d = a.documentElement;

	if (pageLocationMatches(win, doc))
	    return false;

	if (win.google_ad_width && win.google_ad_height) {
	    var w = 1,
		h = 1;

	    if (win.innerHeight) {
		w = win.innerWidth;
		h = win.innerHeight;
	    } else if (d && d.clientHeight) {
		w = d.clientWidth;
		h = d.clientHeight;
	    } else if (doc.body) {
		w = doc.body.clientWidth;
		h = doc.body.clientHeight;
	    }

	    if (h > 2 * win.google_ad_height || w > 2 * win.google_ad_width) {
		return false;
	    }
	}
	
	return true;
    }

    function fillInUnsetVars(errorHandler) {
	var win = window,
	    origErrorHandler = win.onerror;

	win.onerror = errorHandler;

	if (win.google_ad_frameborder == null) {
	    win.google_ad_frameborder = 0;
	}

	if (win.google_ad_output == null) {
	    win.google_ad_output = "html";
	}

	if (isSDOFormat(win.google_ad_format)) {
	    var c = win.google_ad_format.match(/^(\d+)x(\d+)_.*/);

	    if (c) {
		win.google_ad_width=parseInt(c[1]);
		win.google_ad_height=parseInt(c[2]);
		win.google_ad_output="html";
	    }
	}

	if (win.google_ad_format == null && win.google_ad_output == "html") {
	    win.google_ad_format = win.google_ad_width + "x" + win.google_ad_height;
	}

	setLocation(win, document);

	if (win.google_num_slots_by_channel == null) {
	    win.google_num_slots_by_channel = [];
	}

	if (win.google_num_slots_by_client == null) {
	    win.google_num_slots_by_client =[];
	}

	if (win.google_prev_ad_formats_by_region == null) {
	    win.google_prev_ad_formats_by_region = [];
	}

	if (win.google_prev_ad_slotnames_by_region == null) {
	    win.google_prev_ad_slotnames_by_region = [];
	}
	
	if (win.google_correlator == null) {
	    win.google_correlator = (new Date).getTime();
	}

	if (win.google_adslot_loaded == null) {
	    win.google_adslot_loaded = {};
	}

	if (win.google_adContentsBySlot == null) {
	    win.google_adContentsBySlot = {};
	}
	
	if (win.google_flash_version == null) {
	    win.google_flash_version = detectFlashVersion().toString();
	}

	win.onerror = origErrorHandler;
    }

    function detectBrowser(str) {
	if (str in userAgentSubstrings) {
	    return userAgentSubstrings[str];
	}

	return userAgentSubstrings[str]
            = navigator.userAgent.toLowerCase().indexOf(str) != -1;
    }

    var userAgentSubstrings = {};

    function isSpecialAdClient(adOutput, adClient) {
	if (adOutput != "html") {
	    // This cannot currently happen, given how we're called. 
	    return false;
	}

	var d = {};

	d["ca-pub-7027491298716603"] = true;
	d["ca-pub-8344185808443527"] = true;
	d["ca-pub-9812682548211238"] = true;	
	d["ca-pub-4424308218891706"] = true;
	d["ca-pub-6922559858235084"] = true;
	d["ca-pub-6477563040863705"] = true;
	d["ca-google"] = true;

	return d[convertToCaName(adClient)] != null;
    }

    function splitQueryString(b) {

	// For this method's explanation, see 
	// http://gandolf.homelinux.org/~smhanov/blog/?id=21 

	var a = {},
	    d = b.split("?"),
	    e = d[d.length - 1].split("&");

	for(var c = 0; c < e.length; c++) {
	    var f = e[c].split("=");

	    if (f[0]) {
		try {
		    a[f[0].toLowerCase()] = f.length > 1 ?
			(window.decodeURIComponent ?
			   decodeURIComponent(f[1].replace(/\+/g," ")) : unescape(f[1]))
			: "";
		} catch(g) {}
	    }
	}

	return a;
    }

    function handleAdOverride() {
	var win = window,
	    args = splitQueryString(document.URL);

	if (args.google_ad_override) {
	    win.google_ad_override = args.google_ad_override;
	}
    }

    function detectFlashVersion() {
	var b = 0;

	if (navigator.plugins && navigator.mimeTypes.length) {
	    var a = navigator.plugins["Shockwave Flash"];
	    if (a && a.description) {
		b = a.description.replace(/([a-zA-Z]|\s)+/,"").split(".")[0];
	    }
	} else if (navigator.userAgent &&
                   navigator.userAgent.indexOf("Windows CE") >= 0) {
	    b = 3;
	    var d = 1;

	    while (d) {
		try {
		    d = new ActiveXObject("ShockwaveFlash.ShockwaveFlash." + (b+1));
		    b++;
		} catch(e) {
		    d = null;
		}
	    }
	} else if (detectBrowser("msie") && !window.opera) {
	    try {
		var d = new ActiveXObject("ShockwaveFlash.ShockwaveFlash.7");
	    } catch (e) {
		try{
		    var d = new ActiveXObject("ShockwaveFlash.ShockwaveFlash.6");
		    b = 6;
		    d.AllowScriptAccess = "always";
		} catch(e) {
		    if (b == 6) {
			return b;
		    }
		}

		try {
		    d = new ActiveXObject("ShockwaveFlash.ShockwaveFlash");
		} catch(e) {}
	    }

	    if (d != null) {
		b = d.GetVariable("$version").split(" ")[1].split(",")[0];
	    }
	}

	return b;
    };

    // This function establishes the location URL at which the 
    // ads are shown. 
    // 
    function setLocation(win, doc) {
	if (win.google_page_url == null) {

	    // Wow -- special URL massaging to extract meaningful values 
	    // from yieldmanager.com URLs. 
	    // 
	    if (specialSites[doc.domain] && doc.domain == "ad.yieldmanager.com") {
		var d = doc.URL.substring(doc.URL.lastIndexOf("http"));
		win.google_page_url = d;
		win.google_page_location = doc.location;
		win.google_referrer_url = d;
	    } else {
		win.google_page_url = doc.referrer;
		if (! isTooSmall(win, doc)) {
		    win.google_page_url = doc.location;
		    win.google_last_modified_time = Date.parse(doc.lastModified) / 1000;
		    win.google_referrer_url = doc.referrer;
		}
	    }
	} else {
	    win.google_page_location = doc.referrer;
	    if (! isTooSmall(win, doc)) {
		win.google_page_location = doc.location;
	    }
	}
    }

    var specialSites = {};
    specialSites["ad.yieldmanager.com"] = true;

    handleAdOverride();
    fillInUnsetVars(errorHandler);
    makeAds();
}) ()//allow users to comment, like, friend and upload to infoburp nodes and links from facebook.com (app)
//after adding the infoburp app to their page//allow users to comment and upload into nodes from googleplus.com
//after adding the infoburp app to their page//allow users to tweet directly into nodes from twitter.com (app)
//after adding the infoburp app to their page//code defining an audio node, a node containing audio which may often be a soundtrack linked
//to a video node.
//perform some process on audio, like a mixer, or softsynth for example//code defining bubbles and the effect they have on nodes
//shown as a circle surrounding a set of related nodes
//if the user zooms out enough, show the bubbles as a euler diagram.
//there is one master bubble, bubble0, which contains all other bubbles
//and by extension all the nodes and links on infoburp.

//bubbles form a type of euler diagraminterface WebCLBuffer : WebCLMemoryObject {
  WebCLBuffer createSubBuffer(CLenum flags, CLuint origin, CLuint size);
};//buy whuffie from infoburp or other users for cash.
//make sure that node content is available under a suitable open source / free / cc license.//take a node containing a boardmap with a flag stating whose move it is as input

//output possible moves as links to other boardmaps

//in this way, eventually every possible chess game is played.
	
	//find pieces that are free to move

	//find moves those pieces can take

	//output moves as links to resultant boardmaps

	//give the boardmap a whuffie score based on the current player's position + future.//http://en.wikipedia.org/wiki/Clique_(graph_theory)require_once('jsmin.php');

$files = glob("*.js");
$js = "";
foreach($files as $file) {
    $js .= JSMin::minify(file_get_contents($file));
}

file_put_contents("combined.js", $js); 
interface WebCLCommandQueue {

  ////////////////////////////////////////////////////////////////////////////
  //
  // Copying: Buffer <-> Buffer, Image <-> Image, Buffer <-> Image
  //

void enqueueCopyBuffer(
                    WebCLBuffer             srcBuffer,
                    WebCLBuffer             dstBuffer,
                    CLuint                  srcOffset,
                    CLuint                  dstOffset,
                    CLuint                  sizeInBytes, 
                    optional WebCLEvent[]?  eventWaitList,
                    optional WebCLEvent?    event);
                            
void enqueueCopyBufferRect(
                    WebCLBuffer             srcBuffer,
                    WebCLBuffer             dstBuffer, 
                    CLuint[3]               srcOrigin,
                    CLuint[3]               dstOrigin,
                    CLuint[3]               region, 
                    CLuint                  srcRowPitch,
                    CLuint                  srcSlicePitch,
                    CLuint                  dstRowPitch,
                    CLuint                  dstSlicePitch,
                    optional WebCLEvent[]?  eventWaitList,
                    optional WebCLEvent?    event);

void enqueueCopyImage(
                    WebCLImage              srcImage,
                    WebCLImage              dstImage, 
                    CLuint[3]               srcOrigin,
                    CLuint[3]               dstOrigin,
                    CLuint[3]               region, 
                    optional WebCLEvent[]?  eventWaitList,
                    optional WebCLEvent?    event);

void enqueueCopyImageToBuffer(
                    WebCLImage              srcImage,
                    WebCLBuffer             dstBuffer, 
                    CLuint[3]               srcOrigin,
                    CLuint[3]               region, 
                    CLuint                  dstOffset,
                    optional WebCLEvent[]?  eventWaitList,
                    optional WebCLEvent?    event);

void enqueueCopyBufferToImage(
                    WebCLBuffer             srcBuffer,
                    WebCLImage              dstImage, 
                    CLuint                  srcOffset,
                    CLuint[3]               dstOrigin,
                    CLuint[3]               region, 
                    optional WebCLEvent[]?  eventWaitList,
                    optional WebCLEvent?    event);

  ////////////////////////////////////////////////////////////////////////////
  //
  // Reading: Buffer -> Host, Image -> Host
  //

void enqueueReadBuffer(
                    WebCLBuffer             buffer,
                    CLboolean               blockingRead,
                    CLuint                  offset,
                    CLuint                  sizeInBytes, 
                    ArrayBuffer             ptr,
                    optional WebCLEvent[]?  eventWaitList, 
                    optional WebCLEvent?    event);
                            
void enqueueReadBufferRect(
                    WebCLBuffer             buffer,
                    CLboolean               blockingRead,
                    CLuint[3]               bufferOrigin,
                    CLuint[3]               hostOrigin, 
                    CLuint[3]               region,
                    CLuint                  bufferRowPitch,
                    CLuint                  bufferSlicePitch,
                    CLuint                  hostRowPitch,
                    CLuint                  hostSlicePitch,
                    ArrayBuffer             ptr,
                    optional WebCLEvent[]?  eventWaitList, 
                    optional WebCLEvent?    event);
  
void enqueueReadImage(
                    WebCLImage              image,
                    CLboolean               blockingRead, 
                    CLuint[3]               origin,
                    CLuint[3]               region,
                    CLuint                  rowPitch,
                    CLuint                  slicePitch, 
                    ArrayBuffer             ptr,
                    optional WebCLEvent[]?  eventWaitList,
                    optional WebCLEvent?    event);

  ////////////////////////////////////////////////////////////////////////////
  //
  // Writing: Host -> Buffer, Host -> Image
  //

void enqueueWriteBuffer(
                    WebCLBuffer             buffer,
                    CLboolean               blockingWrite, 
                    CLuint                  offset, 
                    CLuint                  sizeInBytes, 
                    ArrayBuffer             ptr,
                    optional WebCLEvent[]?  eventWaitList, 
                    optional WebCLEvent?    event);
                            
void enqueueWriteBufferRect(
                    WebCLBuffer             buffer,
                    CLboolean               blockingWrite,
                    CLuint[3]               bufferOrigin,
                    CLuint[3]               hostOrigin,
                    CLuint[3]               region,
                    CLuint                  bufferRowPitch,
                    CLuint                  bufferSlicePitch,
                    CLuint                  hostRowPitch,
                    CLuint                  hostSlicePitch,
                    ArrayBuffer             ptr,
                    optional WebCLEvent[]?  eventWaitList,
                    optional WebCLEvent?    event);
  
void enqueueWriteImage(
                    WebCLImage              image,
                    CLboolean               blockingWrite, 
                    CLuint[3]               origin,
                    CLuint[3]               region,
                    CLuint                  inputRowPitch,
                    CLuint                  inputSlicePitch, 
                    ArrayBuffer             ptr,
                    optional WebCLEvent[]?  eventWaitList,
                    optional WebCLEvent?    event);

  ////////////////////////////////////////////////////////////////////////////
  //
  // Acquiring and releasing WebGL objects
  //

  void enqueueAcquireGLObjects(WebCLMemoryObject[] memObjects,
                               optional WebCLEvent[]? eventWaitList,
                               optional WebCLEvent? event);
 
  void enqueueReleaseGLObjects(WebCLMemoryObject[] memObjects,
                               optional WebCLEvent[]? eventWaitList,
                               optional WebCLEvent? event);
  
  ////////////////////////////////////////////////////////////////////////////
  //
  // Executing kernels
  //

  void enqueueNDRangeKernel(WebCLKernel kernel, 
                            CLuint[]? offsets, CLuint[]? globals, CLuint[]? locals, 
                            optional WebCLEvent[]? eventWaitList,
                            optional WebCLEvent? event);
  
  void enqueueTask(WebCLKernel kernel, 
                   optional WebCLEvent[]? eventWaitList,
                   optional WebCLEvent? event);
  
  ////////////////////////////////////////////////////////////////////////////
  //
  // Synchronization
  //

  void enqueueMarker(optional WebCLEvent[]? eventWaitList, optional WebCLEvent? event);

  void enqueueBarrier(optional WebCLEvent[]? eventWaitList, optional WebCLEvent? event);
  
  void finish();
  
  void flush();

  ////////////////////////////////////////////////////////////////////////////
  //
  // Querying command queue information
  //

  any getInfo(CLenum name);
};//compare one hash to another, and give a % match result

//http://en.wikipedia.org/wiki/Damerau%E2%80%93Levenshtein_distance

//based on: http://en.wikibooks.org/wiki/Algorithm_implementation/Strings/Levenshtein_distance

//and:  http://en.wikipedia.org/wiki/Damerau%E2%80%93Levenshtein_distance


//http://www.dzone.com/snippets/javascript-implementation

function levenshtein( a, b )

{

var i;

var j;

var cost;

var d = new Array();

 

if ( a.length == 0 )

{

return b.length;

}

 

if ( b.length == 0 )

{

return a.length;

}

 

for ( i = 0; i <= a.length; i++ )

{

d[ i ] = new Array();

d[ i ][ 0 ] = i;

}

 

for ( j = 0; j <= b.length; j++ )

{

d[ 0 ][ j ] = j;

}

 

for ( i = 1; i <= a.length; i++ )

{

for ( j = 1; j <= b.length; j++ )

{

if ( a.charAt( i - 1 ) == b.charAt( j - 1 ) )

{

cost = 0;

}

else

{

cost = 1;

}

 

d[ i ][ j ] = Math.min( d[ i - 1 ][ j ] + 1, d[ i ][ j - 1 ] + 1, d[ i - 1 ][ j - 1 ] + cost );

 

if(

i > 1 &&

j > 1 && 

a.charAt(i - 1) == b.charAt(j-2) &&

a.charAt(i-2) == b.charAt(j-1)

){

d[i][j] = Math.min(

d[i][j],

d[i - 2][j - 2] + cost

)

 

}

}

}

 

return d[ a.length ][ b.length ];

}IB.config = {
	//configure how the interface looks
	node: {
		fillColor: 'white',
		strokeColor: 'green',
		dragLineColor: '#FF7E00',
		strokeColorEditing: '#FF7E00',
		strokeWidth: .15,
		padding: 10,
		textAdjust: 1,
		attraction: {
			"coloumb":4000,
			"attraction":4,
			"jiggle":0.001,
			"dumping":.08,
			"tu":0.1,
			"X_MIN":20,
			"X_MAX":1000,
			"Y_MIN":20,
			"Y_MAX":1000
		},
		repulsion: {
			"coloumb":4000,
			"attraction":-.000004,
			"jiggle":0.001,
			"dumping":.08,
			"tu":0.1,
			"X_MIN":20,
			"X_MAX":1000,
			"Y_MIN":20,
			"Y_MAX":1000
		}
	},
	//configure the x,y,w,h,zoom
	screen: {
		x: 0,
		y: 0,
		w: null,
		h: null,
		zoom: 3
	},
};
//scale down hosting by amount

hosting.scale.down(amount)

	{

	}

//scale up hosting by amount

hosting.scale.up(amount)

	{

	}//allow items listed on ebay to be added to infoburp as nodes, earning ebay affiliate revenue//send and receive emails from a remote email server
//uses socket.io

//every node,link and bubble is given a unique email adress like graeme.wolfendale@infoburp.com
//the infoburp system acts as an email system, storing, forwarding, sending and receiving
//emails.//if user logs in with facebook id

//allow them to post any node to their facebook


//connect to a remote ftp server. upload and download files.
//uses socket.io//connect to a git repository, push and pull project files.
//uses socket.io//connect to a googleplus account
//connect to a webserver using http protocol
//uses socket.io

	//take input remote url

		url=node.html

	//pull the requested url

		connect.network(url,data)

	//add the html returned as a node on infoburp

		IB.node.add(data)

//sparql connector

//sparql.js - take a hyperlink to a sparql endpoint in a node

//sparql endpoints automatically connect to other nodes, with a preference for attaching
//to nodes with a lot of whuffie.

//return sparql query results for all attached nodes.

//get input (node html of node linked to endpoint node)

//parse node contents into sparql query


	//*code needed - take endpoint.node.html and node.html as input, parse in a sparql query*


//endpoint.node.html in format 

//"<sparql:endpoint searchin>"

//example:

//endpoint.node.html"<sparql:dbpedia Pages>"

//node.html="city"

//queryStr = "select distinct ?Page where {<city> ?Page}" 



//what we are searching for (node content of node linked to endpoint node)

   	searchfor=selected.node.html

//where we are searching for it (hyperlink to the sparql endpoint)

   	endpoint=endpoint.node.html

//parse query where ?searchin = search for this type of resource

//this returns things that we talk about on infoburp

   	queryStr = "select distinct ?searchin where {<searchfor> ?searchin}" 

//prepare sparql to json query

   	function sparqlQueryJson(queryStr, endpoint, callback, isDebug) {

     	var querypart = "query=" + escape(queryStr);

     // HTTP request object.

     	var xmlhttp = null;

     	if(window.XMLHttpRequest) 	{

       		xmlhttp = new XMLHttpRequest();

    					} 
	else if(window.ActiveXObject) 	{

      // internet exploder support

      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");

    					}
	 else 				{

      	alert('Sorry, you should get a better browser..');

    					}

    // POST with JSON result format.

    	xmlhttp.open('POST', endpoint, true); 

    	xmlhttp.setRequestHeader('Content-type','application/x-www-form-urlencoded');

    	xmlhttp.setRequestHeader("Accept", "application/sparql-results+json");

    // callback to get the response

    	xmlhttp.onreadystatechange = function() {

      	if(xmlhttp.readyState == 4) 	{

        	if(xmlhttp.status == 200) 	{

          		// do with the results

          		if(isDebug) alert(xmlhttp.responseText);

          		callback(xmlhttp.responseText);

        					}
		else 				{

          		// error handler

          		// alert("Sparql query error: " + xmlhttp.status + " "

          		//    + xmlhttp.responseText);

        					}

      					}

    	};

    	// send query

    	xmlhttp.send(querypart);

    	// wait for callback

   	};
        
     		var query = "select * {?s ?p ?o} limit 5" ;

     	// define callback functions

     		function myCallback(str) {

       // convert result to JSON

       		var jsonObj = eval('(' + str + ')');

       // make table of results

       		var result = " <table border='2' cellpadding='9'>" ;

       		for(var i = 0; i<  jsonObj.results.bindings.length; i++) 
					{

         	result += " <tr> <td>" + jsonObj.results.bindings[i].s.value;

         	result += " </td><td>" + jsonObj.results.bindings[i].p.value;

         	result += " </td><td>" + jsonObj.results.bindings[i].o.value;

         	result += " </td></tr>";

       					}

       		result += "</table>" ;

       		document.getElementById("results").innerHTML = result;

    				}

    		// run query

    			sparqlQueryJson(query, endpoint, myCallback, true);

    		//this gives us sparql results in json format to plug into the rest of the code.//sql connector

//take a node with a mysql endpoint url, a username and a password.

//in the format <mysql:localhost,user:username,pass:password>

var endpoint

var username

var password

//turn it into a mysql endpoint node. run a query for any nodes that are linked
//to this endpoint node.

nodes: function(){
		$.ajax({
			url: 'action/remote.php?action=getAll',
			dataType: 'json',
			method: 'get',
			success:function(data){
				IB._nodes = data;
				IB.search.load();
			    IB.create.load(IB._nodes);
				IB.config.screen.zoom = IB.config.screen.h/(IB.update.calc(IB._nodes.totalWhuffie)/2);
			    // To make nodes spread around central node
			    IB._nodes.x = 0;
				IB._nodes.y = 0;
				IB.update.all();
				IB.event.loadAll();
			}
		});
//connect to a remote secure shell
//connect to a remote shell
//if user logs in with twitter id

//allow them to tweet any node

//allow adding arbitrary data as node contentinterface WebCLContext {

    WebCLBuffer createBuffer(CLenum memFlags, CLuint sizeInBytes, optional ArrayBuffer srcBuffer);

    WebCLCommandQueue createCommandQueue(optional WebCLDevice[]? devices, optional CLenum properties);

    WebCLBuffer createFromGLBuffer(CLenum memFlags, WebGLBuffer buffer);

    WebCLImage createFromGLRenderBuffer(CLenum memFlags, WebGLRenderbuffer renderbuffer);

    WebCLImage createFromGLTexture2D(CLenum memFlags, GLenum textureTarget, 
                                      GLint miplevel, WebGLTexture texture);

    WebCLImage createImage(CLenum memFlags, 
                           WebCLImageDescriptor descriptor,
                           optional ArrayBuffer srcBuffer);

    WebCLProgram createProgram(DOMString source);

    WebCLSampler createSampler(CLboolean normalizedCoords,
                               CLenum addressingMode,
                               CLenum filterMode);

    WebCLEvent createUserEvent();

    any getInfo(CLenum name);

    WebCLImageDescriptor[] getSupportedImageFormats(CLenum memFlags,
                                                    CLenum imageType);
};
dictionary WebCLImageDescriptor {
  CLenum channelOrder = 0x10B5;            // 0x10B5 == WebCL.RGBA
  CLenum channelType = 0x10D2;             // 0x10D2 == WebCL.UNORM_INT8, 8-bit colors normalized to [0, 1]
  CLuint width = 0, height = 0;
  CLuint rowPitch = 0;
};//read the node.html
//if it contains links to other urls, these urls are added as new nodes containing the urls
//linked to.
//in time these pages will be fetched, also.
//create a new node
IB.create = {
	load: function(){
		IB.create.loop();
	},
	loop: function(){
		for(var x in IB._nodes){
			var node = IB._nodes[x];
			IB.create.fixInt(node);
			IB.create.node(node);
			IB.create.nodeHtml(node);
			IB.update.nodeDetractLoad(node);
		}
		for(var x in IB._links){
			var link = IB._links[x];
			IB.create.link(link);
		}
	},
	fixInt: function(node){
		if(!parseInt(node.id)){
			//node.x = 0;
			//node.y = 0;
			node.xspeed = 4;
			node.yspeed = 4;
		} else {
			node.x = parseInt(node.x);
			node.y = parseInt(node.y);
			//node.x = IB.e.mouse.x;
			//node.y = IB.e.mouse.y;

		}
		//node.xspeed = 0;
		//node.yspeed = 0;
		node.whuffie = parseInt(node.whuffie);
		node.id = parseInt(node.id);
	},
	node: function(node){
		if(!node._){
			var w = node.whuffie;
			var h = node.whuffie;
			var o = IB._.rect(node.x, node.y, w, h);
			o.attr('fill',IB.config.node.fillColor)
				.attr('stroke',IB.config.node.strokeColor)
				.attr('stroke-width',IB.config.node.strokeWidth);
			node._ = o;
		}
	},
	nodeHtml: function(node){
		if(!node._html){
			var o = $('<div></div>')
				.addClass('node')
				.attr('IB_Id', node.id)
				.appendTo(IB.__html);
			var html = $('<div></div>')
				.addClass('html')
				.html(node.html)
				.appendTo(o);
			var voteUp = $('<button></button>')
				.addClass('vote')
				.addClass('voteUp')
				.html('')//&#x25B2;
				.appendTo(o);
			var voteDown = $('<button></button>')
				.addClass('vote')
				.addClass('voteDown')
				.html('')//&#x25BC;
				.appendTo(o);
			var editor = $('<div></div>')
				.addClass('editor')
				.appendTo(o);
			var textbox = $('<textarea></textarea>')
				.addClass('textbox')
				.html(node.html)
				.appendTo(editor);
			var editSave = $('<button></button>')
				.addClass('edit')
				.addClass('editSave')
				.html('')//&#x2718;
				.appendTo(editor);
			var editCancel = $('<button></button>')
				.addClass('edit')
				.addClass('editCancel')
				.html('')//&#x2610;
				.appendTo(editor);
			node._html = o;
		}
	},
	link: function(link){
		if(!link._){
			var o = IB._.path('M0,0L0,0');
			o.attr('stroke',IB.config.node.strokeColor)
				.attr('stroke-width',IB.config.node.strokeWidth);
			o.toBack();
			link._ = o;
		}
	},
};
interface WebCLDevice {
    any getInfo(CLenum name);
    object getExtension(DOMString extensionName);
    sequence<DOMString> getSupportedExtensions();
};//code implementing the infoburp distributed hash table network

//the hashes are the locality sensitive hashes produced by hash.process.node.js

//http://en.wikipedia.org/wiki/Distributed_hash_table

//music maker//e handler for keyboard and mouse interaction
IB.e = {
	x: 0,
	y: 0,
	sx: 0,
	sy: 0,
	dragging: false,

	load: function(){
		$(document.body).bind('mousedown', function(e){ IB.e.mouse.down(e); });
		$(document.body).bind('mouseup', function(e){ IB.e.mouse.up(e); });
		$(document.body).bind('mousemove', function(e){ IB.e.mouse.move(e); });
		$(document.body).bind('mousewheel', function(e){ IB.e.mouse.scroll(e); });
		$(document.body).bind('keydown', function(e){ IB.e.keys.down(e); });
		$(document.body).bind('keyup', function(e){ IB.e.keys.up(e); });
		IB.__html.find('.node').bind('mousedown', function(e){ IB.e.mouse.node.down(e, this); });
		IB.__html.find('.node').bind('mouseup', function(e){ IB.e.mouse.node.up(e, this); });
		IB.__html.find('.node').bind('click', function(e){ IB.e.mouse.node.click(e, this); });
		IB.__html.find('.node').bind('dblclick', function(e){ IB.e.mouse.node.dblclick(e, this); });
		IB.__html.find('.node').bind('mouseout', function(e){ IB.e.mouse.node.out(e, this); });
		IB.__html.find('.node *').not('.html').bind('mousedown', function(e){ e.stopPropagation() });
		IB.__html.find('.node .editSave').bind('mouseup', function(e){ IB.e.mouse.node.edit.save.up(e) });
		IB.__html.find('.node .editCancel').bind('mouseup', function(e){ IB.e.mouse.node.edit.cancel.up(e) });
		IB.__html.find('.node .voteUp').bind('mouseup', function(e){ IB.e.mouse.node.vote.up.up(e) });
		IB.__html.find('.node .voteDown').bind('mouseup', function(e){ IB.e.mouse.node.vote.down.up(e) });
		IB.e.mouse.followRegister($('#infoburp #addNode'));
	},
	
	moveX: function(x){
		var zoom = IB.config.screen.zoom;
		IB.config.screen.x += x/zoom;
	},
	moveY: function(y){
		var zoom = IB.config.screen.zoom;
		IB.config.screen.y += y/zoom;
	},
	moveXY: function(x, y){
		var zoom = IB.config.screen.zoom;
		IB.config.screen.x += x/zoom;
		IB.config.screen.y += y/zoom;
	},
	move2XY: function(x, y){
		IB.config.screen.x = x;
		IB.config.screen.y = y;
	},

	zoom: function(i){
		i /= 10;
		IB.config.screen.zoom = (IB.config.screen.zoom+i);
		if(IB.config.screen.zoom<.1)IB.config.screen.zoom = .1;
	},
};
IB.e.keys = {
	register: {},
	_keys: [],

	_map: {
		187: function(){
			IB.e.zoom(1);
		},
		189: function(){
			IB.e.zoom(-1);
		},
		37: function(){
			IB.e.moveX(10);
		},
		39: function(){
			IB.e.moveX(-10);
		},
		38: function(){
			IB.e.moveY(10);
		},
		40: function(){
			IB.e.moveY(-10);
		},
		13: function(){
			IB.e.startEditing();
		}
	},

	map: function(){
		for(var key in IB.e.keys._keys){
			var on = IB.e.keys._keys[key];
			if(on){
				if(IB.e.keys._map[key]){
					IB.e.keys._map[key]();
				}
			}
		}
	},
	
	down: function(e){
		e = e.which?e.which:e.keyCode;
		IB.e.keys._keys[e] = 1;
	},
	up: function(e){
		e = e.which?e.which:e.keyCode;
		IB.e.keys._keys[e] = 0;
	},
}IB.e.mouse = {
	dragging: false,
	x: 0,
	y: 0,
	sx: 0,
	sy: 0,

	_followRegister: [],
	followRegister: function(el){
		IB.e.mouse._followRegister.push(el);
	},
	follow: function(){
		for(var x in IB.e.mouse._followRegister){
			var el = IB.e.mouse._followRegister[x];
			el.css('left', IB.e.mouse.x);
			el.css('top', IB.e.mouse.y);
		}
	},

	down:function(e){
		IB.e.mouse.drag.start(e);
	},
	up:function(e){
		IB.e.mouse.drag.stop(e);
		IB.e.node.createChild(e);
	},
	move:function(e){
		IB.e.mouse.drag.do(e);
		IB.e.mouse.follow();
	},
	dblclick:function(e){
		IB.e.node.setCenter(e);
	},

	drag:{
		start: function(e){
			e.preventDefault();
			IB.e.mouse.dragging = 1;
			var zoom = IB.config.screen.zoom;
			IB.config.screen.sx = IB.config.screen.x;
			IB.config.screen.sy = IB.config.screen.y;
			IB.e.mouse.x = IB.e.mouse.sx = e.pageX;
			IB.e.mouse.y = IB.e.mouse.sy = e.pageY;
			return false;
		},
		stop: function(e){
			e.preventDefault();
			if(IB.e.mouse.dragging){
				var zoom = IB.config.screen.zoom;
				IB.e.mouse.dragging = 0;
				IB.__html.parent().removeClass('dragging');
			}
			return false;
		},
		do: function(e){
			e.preventDefault();
			IB.e.mouse.x = e.pageX;
			IB.e.mouse.y = e.pageY;
			IB.e.node.moveDragLine(e, IB.e.node._selected);
			if(IB.e.mouse.dragging){
				IB.__html.parent().addClass('dragging');
				if(IB.e.mouse.dragging){
				var zoom = IB.config.screen.zoom;
					var x = (IB.config.screen.sx +(IB.e.mouse.x-IB.e.mouse.sx)/zoom);
					var y = (IB.config.screen.sy +(IB.e.mouse.y-IB.e.mouse.sy)/zoom);
					IB.e.move2XY(x, y);
				}
			}
			return false;
		},
	},

	scroll: function(e){
		e.preventDefault();
		var delta = 0;
		if(!event)event = window.event;
		if(event.wheelDelta) {
			// IE and Opera
			delta = event.wheelDelta / 60;
		} else if (event.detail) {
			// W3C
			delta = -event.detail / 2;
		}
		IB.e.zoom(delta);
		return false;
	},


	node:{
		down: function(e, __html){
			e.stopPropagation();
			var node = IB.node.get($(__html).attr('IB_Id'));
			IB.e.node.drag.start(e);
			IB.e.node.select(e, node);
			return false;
		},
		up: function(e, __html){
			e.stopPropagation();
			var node = IB.node.get($(__html).attr('IB_Id'));
			IB.e.node.drag.stop(e);
			IB.e.node.edit.start(e, node);
			IB.e.node.createLink(e, node);
			return false;
		},
		click: function(e, __html){
			var node = IB.node.get($(__html).attr('IB_Id'));
			IB.e.node.clicking = 1;
			window.setTimeout(function(){
				if(IB.e.node.clicking){
					IB.e.node.drag.stop();
					IB.e.node.edit.start();
				}
			}, 500);
			return false;
		},
		dblclick: function(e, __html){
			var node = IB.node.get($(__html).attr('IB_Id'));
			IB.e.node.setCenter(e, __html);
			return false;
		},
		out: function(e, __html){
			var node = IB.node.get($(__html).attr('IB_Id'));
			IB.e.node.startDragLine(e, node);
			return false;
		},
		edit:{
			save:{
				up:function(e){
					IB.e.node.edit.save(e);
				}
			},
			cancel:{
				up:function(){
					IB.e.node.edit.stop(e);
				}
			},
		},
		vote:{
			up:{
				up:function(){
					IB.e.node.vote.up(e);
				}
			},
			down:{
				up:function(){
					IB.e.node.vote.down(e);
				}
			},
		},
	}
};IB.e.node = {
	editing: false,
	dragging: false,
	
	startDragLine: function(e, node){
		if(IB.e.node.dragging){
			if(node.id==IB.e.node._selected.id && !IB.e.node.dragLine){
				//create new node
				var zoom = IB.config.screen.zoom;
				var sw = IB.update.calc((node.whuffie), IB.config.node.strokeWidth);
				sw *= zoom;
				var x1 = node.x*zoom;
				var y1 = node.y*zoom;
				var x2 = IB.e.mouse.x-IB.config.screen.w/2;
				var y2 = IB.e.mouse.y-IB.config.screen.h/2;
				IB.e.node.dragLine = IB._.path('M'+x1+','+y1+'L'+x2+','+y2+'')
					.attr('stroke',IB.config.node.dragLineColor)
					.attr('stroke-width',sw);
				IB.e.node.dragLine.toBack();
			}
		}
	},
	moveDragLine: function(e, node){
		if(IB.e.node.dragging){
			//create new node
			if(IB.e.node.dragLine){
				var zoom = IB.config.screen.zoom;
				var x1 = node.x*zoom;
				var y1 = node.y*zoom;
				var x2 = IB.e.mouse.x-IB.config.screen.w/2-IB.config.screen.x*zoom;
				var y2 = IB.e.mouse.y-IB.config.screen.h/2-IB.config.screen.y*zoom;
				IB.e.node.dragLine.attr('path','M'+x1+','+y1+'L'+x2+','+y2);
			}
		}
	},
	stopDragLine: function(e, node){
		if(IB.e.node.dragLine){
			IB.e.node.dragLine.remove();
			IB.e.node.dragLine = 0;
		}
	},
	createChild: function(e){
		if(IB.e.node.dragging){
			//create new node
			var zoom = IB.config.screen.zoom;
			var x = (IB.e.mouse.x-IB.config.screen.w/2-IB.config.screen.x)/zoom;
			var y = (IB.e.mouse.y-IB.config.screen.h/2-IB.config.screen.y)/zoom;
			IB.node.createChild(IB.e.node._selected, x, y);
			IB.config.screen.x = -x;
			IB.config.screen.y = -y;
		}
		IB.e.node.edit.save();
		IB.e.node.drag.stop(e);
		IB.e.node.unselect();
		IB.e.node.stopDragLine();
	},
	createLink: function(e, child){
		if(IB.e.node.dragging){
			//create new node
			if(IB.e.node._selected.id!=child.id){
				IB.node.createLink(IB.e.node._selected, child);
				IB.e.node.edit.save();
				IB.e.node.drag.stop(e);
				IB.e.node.unselect();
			}
		}
		IB.e.node.stopDragLine();
	},
	setCenter: function(e, __html){
		e.stopPropagation();
		e.preventDefault();
		var node = IB.node.get($(__html).attr('IB_Id'));
		IB.e.node.clicking = 0;
		IB.e.move2XY(-node.x, -node.y);
		return false;
	},
	select: function(e, node){
		e.stopPropagation(e);
		if(IB.e.node._selected != node){
			e.preventDefault();
			IB.e.node.unselect();
			IB.e.node._selected = node;
			IB.e.node._selected._html.addClass('selected');
			IB.e.node._selected._.attr('stroke', IB.config.node.strokeColorEditing);
		}
		return false;
	},
	drag:{
		start: function(e){
			e.preventDefault();
			e.stopPropagation();
			IB.e.node.dragging = 1;
			IB.__html.parent().addClass('creating');
			return false;
		},
		stop: function(e){
			e.preventDefault();
			e.stopPropagation();
			window.setTimeout(function(){
				IB.e.node.dragging = 0;
			}, 100);
			IB.__html.parent().removeClass('creating');
			return false;
		},
	},
	unselect: function(node){
		if(!node)node = IB.e.node._selected;
		IB.e.node.edit.stop();
		if(IB.e.node._selected){
			node._html.removeClass('selected');
			node._.attr('stroke', IB.config.node.strokeColor);
		}
		IB.e.node._selected = null;
	},
	edit:{
		start: function(e){
			if(IB.e.node._selected && !IB.e.node.editing){
				IB.e.node.editing = 1;
				var html = IB.e.node._selected.html;
				IB.e.node._selected._html.find('.textbox').val(html);
				IB.e.node._selected._html.addClass('editing');
				IB.e.node._selected._html.find('.html').hide();
				IB.e.node._selected._html.find('.textbox').focus();
			}
		},
		stop: function(e){
			if(e)e.stopPropagation();
			if(IB.e.node._selected){
				IB.e.node.editing = 0;
				IB.e.node._selected._html.removeClass('editing');
				IB.e.node._selected._html.find('.html').show();
			}
		},
		save: function(e){
			if(IB.e.node._selected){
				IB.e.node.edit.stop();
				var node = IB.e.node._selected;
				var val = node._html.find('.textbox').val();
				IB.action.save(node.id, val, function(success){
					IB.e.node.edit.stop();
					if(success){
						node.html = val;
						node._html.find('.html').html(val);
					}
				});
			}
		},
	},
	vote:{
		up: function(e){
			e.stopPropagation();
			var id = IB.e.node._selected.id;
			IB.action.voteUp(id);
		},
		down: function(e){
			e.stopPropagation();
			var id = IB.e.node._selected.id;
			IB.action.voteDown(id);
		}
	}
};IB.e.node.mouse = {
	down: function(e, __html){
		e.stopPropagation();
		var node = IB.node.get($(__html).attr('IB_Id'));
		IB.e.node.startDragging();
		IB.e.node.select(e, node);
		return false;
	},
	up: function(e, __html){
		e.stopPropagation();
		var node = IB.node.get($(__html).attr('IB_Id'));
		IB.e.node.stopDragging();
		return false;
	},
	click: function(e, __html){
		e.stopPropagation();
		var node = IB.node.get($(__html).attr('IB_Id'));
		IB.e.node.clicking = 1;
		window.setTimeout(function(){
			if(IB.e.node.clicking){
				IB.e.node.stopDragging();
				IB.e.node.startEditing();
			}
		}, 500);
		return false;
	},
	edit:{
		save:{
			up:function(){

			},
			down:function(){
				
			}
		},
		cancel:{
			up:function(){

			},
			down:function(){
				
			}
		},
	},
	vote:{
		up:{
			up:function(){

			},
			down:function(){
				
			}
		},
		down:{
			up:function(){

			},
			down:function(){
				
			}
		},
	},
};[Constructor]
interface WebCLEvent {
    readonly attribute CLenum status;
    readonly attribute WebCLMemoryObject buffer;
    
    any   getInfo(CLenum name);
    any   getProfilingInfo(CLenum name);
    void  setUserEventStatus(CLenum executionStatus);
    void  setCallback(CLenum executionStatus, WebCLCallback notify, optional any userdata);
};//find the shortest path between two nodes

//http://en.wikipedia.org/wiki/Bellman%E2%80%93Ford_algorithm

//as paths(links) can have negative weight(whuffie), we choose the bellman ford algorithm

procedure BellmanFord(list vertices, list edges, vertex source)
   // This implementation takes in a graph, represented as lists of vertices
   // and edges, and modifies the vertices so that their distance and
   // predecessor attributes store the shortest paths.

   // Step 1: initialize graph
   for each vertex v in vertices:
       if v is source then v.distance := 0
       else v.distance := infinity
       v.predecessor := null

   // Step 2: relax edges repeatedly
   for i from 1 to size(vertices)-1:
       for each edge uv in edges: // uv is the edge from u to v
           u := uv.source
           v := uv.destination
           if u.distance + uv.weight < v.distance:
               v.distance := u.distance + uv.weight
               v.predecessor := u

   // Step 3: check for negative-weight cycles
   for each edge uv in edges:
       u := uv.source
       v := uv.destination
       if u.distance + uv.weight < v.distance:
           error "Graph contains a negative-weight cycle"/*All DHT topologies share some variant of the most essential property:
for any key , each node either has a node ID that owns  or has a link to
a node whose node ID is closer to , in terms of the keyspace distance defined
above. It is then easy to route a message to the owner of any key using the
following greedy algorithm (that is not necessarily globally optimal):
at each step, forward the message to the neighbor whose ID is closest to.
When there is no such neighbor, then we must have arrived at the closest node,
which is the owner of  as defined above. This style of routing is sometimes called
key-based routing.*/


//calculate a fractal//present a node to the user containing a flot graph of one of a few types.

//http://code.google.com/p/flot///produce a 256 bit long locality sensitive hash based on the node html.
//http://en.wikipedia.org/wiki/Locality-sensitive_hashing
//this hash is then used for idea gravity and the distributed hash table network.

interface WebCLImage : WebCLMemoryObject {
  WebCLImageDescriptor getInfo();
  GLint getGLtextureInfo(CLenum paramName);
};//take audio input
//run this to add the computer it is run on to infoburp
//as a machine node with varying levels

//0-machine node only
//1-machine node + user interface node - text only
//2-machine node + user interface node - 2d graphical
//3-machine node + user interface node - 3d graphical
//4-machine node + user interface node - 2d graphical + sound out
//5-machine node + user interface node - 3d graphical + video out
//6-machine node + user interface node - 2d graphical + sound in
//7-machine node + user interface node - 3d graphical + video in
//8-machine node + user interface node - 2d graphical + sound in/out
//9-machine node + user interface node - 3d graphical + video in/out

	//loop until crash 
	
	{
		init.infoburp(runlevel)
		kernel.infoburp(runlevel)
	}

	//error handler

	{

	}//initialise
var IB = {
	_: null,
	__: null,
	__html: null,
	_nodes: null,
	_links: null
};



$(document).ready(function(){
	IB.load.self();
}); 
//take keyboard input
//take mouse input//take music as input, for example a midi input port
//infoburp kernel

//manages the interaction of a single machine and user with infoburp as a whole

//loop until user quits or hardware fails if a server only node.

//main kernel loop

kernel.loop ()

	{
		//check connection, connect to infoburp.
			connect.network(infoburp);
		//download node to ram
			download.network(nodes);
		//save node to nodes folder
			save.file(nodes);
		//process node 
			process.node(nodes);
		//save node to nodes folder	
			save.file(nodes);
		//share nodes with infoburp network
			share.network(nodes);
	}
interface WebCLKernel {
    any getInfo(CLenum name);
    any getWorkGroupInfo(WebCLDevice device, CLenum name);
    void setArg(CLuint index, any value, optional CLtype type);
};
//The following enumerated values are available for specifying the type of kernel arguments in setArg. Vector types are specified by bitwise-OR'ing one of the scalar enums with exactly one of the vector enums (VEC2, VEC3, VEC4, VEC8, or VEC16). The special type LOCAL_MEMORY_SIZE is used to allocate memory for local variables.

interface WebCLKernelArgumentTypes {

  // Scalar types; may be bitwise-OR'ed with a vector type

  CLtype CHAR   = 0;
  CLtype UCHAR  = 1;
  CLtype SHORT  = 2;
  CLtype USHORT = 3;
  CLtype INT    = 4;
  CLtype UINT   = 5;
  CLtype LONG   = 6;
  CLtype ULONG  = 7;
  CLtype FLOAT  = 8;
  CLtype HALF   = 9;    // not supported in all implementations
  CLtype DOUBLE = 10;   // not supported in all implementations

  // Vector types; must be bitwise-OR'ed with a scalar type

  CLtype VEC2  = 0x0100;
  CLtype VEC3  = 0x0200;
  CLtype VEC4  = 0x0400;
  CLtype VEC8  = 0x0800;
  CLtype VEC16 = 0x1000;

  // Special types; must not be bitwise-OR'ed with any other type

  CLtype LOCAL_MEMORY_SIZE = 255;
};//define the license that the content of a node is available under

//public domain

//open/free

//closed

//private/encrypted

//unknown



//code defining links//load data - loads nodes, links and bubbles from files on the hard drive and in ram.

	//http://www.w3.org/TR/file-system-api/

//load file from disk

//determine what is stored

//cookies

//file api

	load.file(filename)	
		{
			function useAsyncFS(fs) {
  				// see getAsText example in [FILE-API-ED].
  				fs.root.getFile("filename", null, function (f) {
    				getAsText(f.file());
  										});

  
						}
	requestFileSystem(TEMPORARY, 1024 * 1024, function(fs) {
  	useAsyncFS(fs);
		});

	// In a worker:

		var tempFS = requestFileSystem(TEMPORARY, 1024 * 1024);
		var filename = tempFS.root.getFile("filename", {create: false});
		var writer = filename.createWriter();
		writer.seek(writer.length);
		writeDataToFile(writer);	
		}
//load all nodes from database
IB.load = {
	self:function(){
		IB.__ = $('#infoburp');
		IB.__html = IB.__.find('.html');
		var h = $(window).height();
		var w = $(window).width();
		IB.config.screen.h = h;
		IB.config.screen.w = w;
		IB._ = Raphael('infoburp', w, h);
		IB.e.move2XY(0, 0);
		IB.load.refresh();
	},
	refresh: function(){
		IB._.clear();
		IB.__html.html('');
		IB.load.nodes(function(){
			IB.load.links(function(){
				IB.load.rest();
			});
		});
	},
	nodes: function(CB){
		IB.action.get({
			action:'getNodes'
		}, function(data){
			IB._nodes = data;
			CB();
		});
	},
	links: function(CB){
		IB.action.get({
			action:'getLinks'
		}, function(data){
			IB._links = data;
			CB();
		});
	},
	rest: function(){
		IB.search.load();
		// create nodes and links
	    IB.create.load();
	    // default zoom
		//IB.config.screen.zoom = IB.config.screen.h/(IB.update.calc(IB._nodes.totalWhuffie)/2);
		// begin updating nodes
		IB.update.load();
		//event control
		IB.e.load();
	},
};
//code defining a single location on earth, by latitude and longitude.//login with facebook id

//https://developers.facebook.com/docs/reference/javascript/FB.login/

 FB.login(function(response) {
   if (response.authResponse) {
     console.log('Welcome!  Fetching your information.... ');
     FB.api('/me', function(response) {
       console.log('Good to see you, ' + response.name + '.');
     });
   } else {
     console.log('User cancelled login or did not fully authorize.');
   }
 });
//login with google id
//https://developers.google.com/gdata/docs/js-authsub

 function doLogin(){
    scope = "http://www.google.com/calendar/feeds";
    var token = google.accounts.user.login(scope);
  }
//login with open id
//http://code.google.com/p/openid-selector///login with twitter id
//https://dev.twitter.com/docs/anywhere/welcome#login-signup


 
T.signIn();
    		
//a machine node is a computer attached to infoburp which:

//stores data - stores nodes, links and bubbles as files on the hard drive and in ram.

	//http://www.w3.org/TR/file-system-api/

//performs calculations on data using javascript run on the cpu and gpu.

	//http://www.khronos.org/webcl/

//freely shares all data and calculation results with the rest of infoburp.

	//http://socket.io/#faq

//distributed and decentralised, based on node/link network graph structure.

	//no single point of failure

//rather than being push/pull, data is stored as locally and as redundantly as possible
//and "flows" around the graph to meet spikes in demand for certain content, while
//providing consistant, delay tolerant service, even on poor quality connections.

	//takes as input
	//the address of a few known other machine nodes

machine.node0.address="www.infoburp.com"
machine.node1.address="www.prubofni.com"
machine.node2.address="10.0.0.2"

//checks for succesful connection to network

	network.init();

//once connected, bootstrap process begins

	//download a list of servers you can connect to, and add them to the machine.node list on disk.

		network.get.machine.node(list,disk);

	//download the root node(0) to disk

		network.get.rootnode(disk);

	//download the most popular nodes to disk

		network.get.hotnodes(disk);

	//bootstrap done

	//begin normal operation, store process and communicate to/for the rest of infoburp

		network.server.start(store,process,communicate)

//loop 
	{
	//download an available node from a remote machine.node, that the local machine.node
	//does not already have, and store on the disk.
		network.get.newnode(disk);
	//check if normal node or executable node
		if newnode.type = "1" then 
  			{
			//normal node - store(do nothing)
			}
			{
			//executable node - process then store
			executable.node.run(node,disk);
			}
	//upload an available node from storage to a remote machine.node
		network.upload(disk);
	}
//end loop





//manager.advert.node.js
//manages the number of advert nodes visible to users to ensure profit after
//covering all costs

	//set desired profit per hour in GBP

		profit = 10;

	//get number of users

		usernum = IB.usernum;

	//get click rate

		clickrate = IB.clickrate;

	//get cpc

		cpc = IB.cpc;

	//calculate advertising revenue

		revenue = (usernum * clickrate) * cpc;

	//check costs

		cost = connect.amazon.hosting.get.cost

	//adjust hosting levels (cost), based on total(cost)

		if (cost > revenue)
			{
			//scale down the amazon cloud hosting, making the hosting cost go down
			connect.amazon.hosting.scale.down(1);
			//add an advert node
			advert.google.node.add(1)
			}
		if (revenue > (cost + profit)
			{
			//scale up the amazon cloud hosting, making the site core faster
			connect.amazon.hosting.scale.up(1);
			//remove an advert node
			advert.google.node.remove(1)
			}

	//check for and remove any advert nodes that do not give us revenue.

		check.advert.node();//calculate overall profit/loss

	//profit - advertising

	//profit - sale of whuffie

	//profit - commission

	//loss - programmer wages

	//loss - hosting costs

	//loss - other costs


//manage hosting according to cost and demand

//from different hosts

//infoburp ambient cloud 	- free

//amazon ec2 			- paid

//google compute engine 	- paid

//storm on demand 		- paid (with ssds)

//peer 1 hpc cloud		- paid (with gpus)
//http://www.peer1hosting.co.uk/cloud-hosting/high-performance-cloud-computing/key-features 

//having these different hosts gives us protection if an entire cloud goes down.




//code defining a node which contains a map of a particular part of the world.interface WebCLMemoryObject : Transferable {
  any getInfo(CLenum name);
  WebCLGLObjectInfo getGLObjectInfo();
};//code defining a 3d mesh or model//http://en.wikipedia.org/wiki/Chemical_file_format//music data in a node, for example a midi fileIB.node = {
	// get functions
	get: function(id){
		for(var x in IB._nodes){
			var node = IB._nodes[x];
			if(node.id==id)return node;
		}
	},
	children: function(id){
		var children = [];
		for(var x in IB._links){
			var link = IB._links[x];
			if(link.parent==id){
				children.push(IB.node.get(link.child));
			}
		}
		return children;
	},
	siblings: function(id){
		var siblings = [];
		for(var x in IB._links){
			var link = IB._links[x];
			if(link.parent==id || link.child==id){
				if(link.parent==id)siblings.push(IB.node.get(link.child));
				if(link.child==id)siblings.push(IB.node.get(link.parent));
			}
		}
		return siblings;
	},
	childrenWhuffie: function(id){
		var whuffie = 0;
		for(var x in IB._links){
			var link = IB._links[x];
			if(link.parent==id){
				whuffie += IB.node.get(link.child).whuffie;
			}
		}
		return whuffie;
	},
	totalWhuffie: function(id){
		var node = IB.node.get(id);
		var childrenWhuffie = IB.node.childrenWhuffie(id);
		return node.whuffie+childrenWhuffie;
	},

	//set functions
	updateChildNodePositions: function(node){
		var children = IB.node.children(node.id);
		var totalChildren = children.length;
		var childrenWhuffie = IB.node.childrenWhuffie(node.id);
		var circumference = childrenWhuffie;
		var averageTheta = circumference/totalChildren;
		var diameter = circumference/Math.PI;
		var radius = diameter/2;
		var theta = 0;
		var averageChildRadius = averageTheta/2;
		for(var x in children){
			var child = children[x];
			var childRadius = child.whuffie/2;
			var degrees = (theta/circumference)*360;
			var radians = degrees*(Math.PI/180);
			var childChildrenWhuffieRadius = IB.node.childrenWhuffie(child.id)/2;
			var whuffieRadius = node.whuffie/2;
			var extend = (whuffieRadius+childRadius+childChildrenWhuffieRadius)-averageChildRadius;
			child.x = parseInt(node.x) + (radius+extend)*Math.cos(radians);
			child.y = parseInt(node.y) + (radius+extend)*Math.sin(radians);
			theta += averageTheta;
		}
		IB.action.post({
			id:node.id,
			action:'updateChildNodePositions'
		});
	},
	createChild: function(parent, x, y){
		IB.action.post({
			id:parent.id,
			x:x,
			y:y,
			action:'createChild'
		}, function(data){
			IB.load.refresh();
		});
	},
	createLink: function(parent, child){
		IB.action.post({
			id:parent.id,
			child:child.id,
			action:'createLink'
		}, function(data){
			IB.load.refresh();
		});
	}
};//code for optical character recognition, to read books for example//music output, for example a midi output port
interface WebCLPlatform {
  object getInfo(CLenum name);
  WebCLDevice[] getDevices(CLenum deviceType);
  sequence<DOMString> getSupportedExtensions();
};//play the audio stored in a node

//use jplayer from jplayer.org
//play the video stored inside a node

//use jplayer from jplayer.org//code defining executable nodes

//performs calculations defined by the code content, on linked nodes, and produces
//linked child nodes as output.

//executable nodes contain javascript code inside <script></script> tags.

//they can take input from any connected nodes, and output to any other connected nodes.

//executable nodes enable visual programming on infoburp

//uses webcl
//https://cvs.khronos.org/svn/repos/registry/trunk/public/webcl/spec/latest/index.html


 var run()
	{
	//IB.node.run(node);
	//Select best available processing method, plain js for older browsers,
	//WebCL for modern browsers, and native client to run code in many languages.
		
		if(bestmethod.process.node) = nativeclient	
			{	
				//Creates a nativeclient computing context for execution of code 					//in many languages like c/c++
				//https://developers.google.com/native-client/overview#intro
				var process.node = new nativeclient();
			}
		if(bestmethod.process.node) = webcl
			{
				// Creates a webcl computing context
				var process.node = new WebCL();	
			}	
		if(bestmethod.process.node) = js	
			{	
				//Creates a js computing context
				var process.node = new Js();
			}
		if(bestmethod.process.node) = java	
			{	
				//Creates a java computing context
				var process.node = new Java();
			}
		
	}
interface WebCLProgram {
    any getInfo(CLenum name);

    any getBuildInfo(WebCLDevice device, CLenum name);

    void build(WebCLDevice[] devices, 
               DOMString? options, 
               optional WebCLCallback whenFinished,
               optional any userdata);

    WebCLKernel createKernel(DOMString kernelName);

    WebCLKernel[] createKernelsInProgram();
};//http://en.wikipedia.org/wiki/Quorum_(distributed_computing)

//temporarily store files in client ram, requires no permission and smooths peaks in demand
//as each user accessing data also stores it and provides access to it.

//load a file from ram


//temporarily store files in client ram, requires no permission and smooths peaks in demand
//as each user accessing data also stores it and provides access to it.

//save a file to ram//maintain a routing table of other peersinterface WebCLSampler {
    any getInfo(CLenum name);
};//save data - stores nodes, links and bubbles as files on the hard drive and in ram.

	//http://www.w3.org/TR/file-system-api/

//ask user before storing any data

//store node to disk

//use best available storage method

//cookies

//file api
	save.file(filename)

		{		
			function useAsyncFS(fs) {
 
  				// now we write to the file; see [FILE-WRITER-ED].
  				fs.root.getFile("filename", {create: true}, function (f) {
    				f.createWriter(writeDataToLogFile);
  						});
		}
			requestFileSystem(TEMPORARY, 1024 * 1024, function(fs) {
  		useAsyncFS(fs);
		});

	// In a worker:

		var tempFS = requestFileSystem(TEMPORARY, 1024 * 1024);
		var filename = tempFS.root.getFile("filename", {create: true});
		var writer = filename.createWriter();
		writer.seek(writer.length);
		writeDataToLogFile(writer);
		}



//search functions
//as a user types their query, zoom in on the nearest matching nodes, and highlight them.
//once they press return, zoom to matching node, or create a new node
//containing the search string.

IB.search = {
	__: $('#_search'),

	load: function(){
		IB.search.__ = $('#_search');
		IB.search.__.bind('keyup', function(e){
		//***change this to on press return
		//do a search
			IB.search.do();
		});
		IB.search.__.bind('focus', function(e){
			var value = IB.search.__.val();
			if(value=='search')$(this).val('');
		});
		IB.search.__.bind('blur', function(e){
			var value = IB.search.__.val();
			if(value=='')$(this).val('search');
		});
	},
	do: function(CB){
		if((typeof CB)!='function')CB = function(){};
		var value = IB.search.__.val();
		if(value!=''){
			IB.search.results(value, function(results){
				CB(results);
			});
		}
	},
	results: function(value, CB){
		$.ajax({
			url:'/action/action.php',
			data:{
				action:'search',
				value:value
			},
			success:function(results){
				CB(results);
			}
		})
	}
}//sell whuffie to other users or infoburp for products or services.
//allow a user to broadcast live from a microphone or webcam onto infoburp,
//where their video/audio is stored as a node as it is streamed, and can be watched later.
//support html5 getusermedia, and flash for older browsers.

//Grab the elements

var video = document.getElementsByTagName('video')[0],

heading = document.getElementsByTagName('h1')[0];

//test for getUserMedia

if(navigator.getUserMedia) {

  //setup callbacks

  navigator.getUserMedia('video', successCallback, errorCallback);

 

  //if everything if good then set the source of the video element to the mediastream

  function successCallback( stream ) {

    video.src = stream;

  }

 

  //If everything isn't ok then say so

  function errorCallback( error ) {

    heading.textContent =

        "An error occurred: [CODE " + error.code + "]";

  }

}

else {

  //show no support for getUserMedia

  message.tooltip =

      "Web camera streaming is not supported in this browser!";

}
//code defining text documents like ms word docs, allowing them to be added as nodes.//code defining a physical item//display tooltips in the bottom bar for whatever the mouse is over
//tooltip text is stored in a set of nodes

//take a 2d image as input, and output a transform of this image as a new node.//update the positions of nodes
IB.update = {
	updateInstance: 0,

	load: function(){
		window.setInterval(function(){
			IB.update.nodeDetract();
			IB.update.loop();
			IB.update.view();
			IB.e.keys.map();
		}, 10);
	},
	
    loop: function(){
		for(var x in IB._nodes){
			var node = IB._nodes[x];
			IB.update.linkSpring(node);
			// update nodes
			IB.update.node(node);
			// update nodes html
			IB.update.nodeHtml(node);
		}
		for(var x in IB._links){
			var link = IB._links[x];
			var parent = IB.node.get(link.parent);
			var child = IB.node.get(link.child);
			// update links
			IB.update.link(link, parent, child);
		}
	},

	view: function(){
		var w = IB.config.screen.w;
		var h = IB.config.screen.h;
		var x = IB.config.screen.x;
		var y = IB.config.screen.y;
		var zoom = IB.config.screen.zoom;
		x = (x*zoom)+(w/2);
		y = (y*zoom)+(h/2);
		IB._.setViewBox(-x, -y, w, h);
		IB.__html.css('left', x);
		IB.__html.css('top', y);
	},

	calc: function(i, multiplier){
		if(!multiplier)multiplier = 1;
		return Math.log(i)*multiplier;
	}
};
IB.update.link = function(link, parent, child){
	var zoom = IB.config.screen.zoom;
	var px = parent.x;
	var py = parent.y;
	var x = child.x;
	var y = child.y;
	var sw = IB.update.calc((child.whuffie+parent.whuffie)/2, IB.config.node.strokeWidth);
	sw = sw;
	px *= zoom;
	py *= zoom;
	x *= zoom;
	y *= zoom;
	sw *= zoom;
	link._.attr('path', 'M'+px+','+py+'L'+x+','+y)
		.attr('stroke-width',sw);
}



IB.update.linkSpringOld = function(node){
	if(node.id){
		//run spring
		var sibsVectorX = 0;
		var sibsVectorY = 0;
		var sibs = IB.node.siblings(node.id);
		for(var i in sibs){
			var sib = sibs[i];
			var sVectorX = sib.x - node.x;
			var sVectorY = sib.y - node.y;
			sibsVectorX += sVectorX;
			sibsVectorY += sVectorY;
		}

		var vectorX = sibsVectorX - node.x;
		var vectorY = sibsVectorY - node.y;
		var i = bods.i[node.id];
		var m = bods.mass[i];
		var kg = m*9.8;
		var vx = bods.vel.x[i];
		var vy = bods.vel.y[i];
		var xX = 1;
		var yX = 1;
		//calculate displacement
		//kg·m/s2 = -(kg/s2)*x
		var forceX = -(kg/(vectorX*vectorX))*xX;
		var forceY = -(kg/(vectorY*vectorY))*yX;
		//calculate the effect this force has on the mass of the node
		//Force = Mass * Acceleration 
		//acceleration = force / mass
		var accelerationX = forceX / m
		var accelerationY = forceY / m;
		//and finally add this effect to the x,y of the node
		bods.vel.x[i] += accelerationX;
		bods.vel.y[i] += accelerationY;
	}
}


IB.update.linkSpring = function(node){
	if(node.id){
		// run spring
		var sibs = IB.node.siblings(node.id);
		for(var i in sibs){
			// sibling
			var sib = sibs[i];
			// vector from sibling to node
			var vectorX = sib.x - node.x;
			var vectorY = sib.y - node.y;
			var slope = vectorY/vectorX;
			var magnitude = Math.sqrt(vectorX*vectorX+vectorY*vectorY);
			var radius = 100;
			var exceed = radius - magnitude;
			var i = bods.i[node.id];
			if(magnitude>=radius){
				var siblingIsMovingAwayFromNode = function(){
					var nx = node.x;
					var ny = node.y;
					var sx = sib.x;
					var sy = sib.y;
					var velX = bods.vel.x[i];
					var velY = bods.vel.y[i];
					if((sx>nx) && (sy>ny)){ //quadrant 1
						if(velX>0 && velY>0){
							return true;
						}
					}
					if((sx<nx) && (sy>ny)){ //quadrant 2
						if(velX<0 && velY>0){
							return true;
						}
					}
					if((sx<nx) && (sy<ny)){ //quadrant 3
						if(velX<0 && velY<0){
							return true;
						}
					}
					if((sx>nx) && (sy<ny)){ //quadrant 4
						if(velX>0 && velY<0){
							return true;
						}
					}
					return false;
				}
				if(siblingIsMovingAwayFromNode()){
					var springFactor = .001;
					var friction = 1;
					var velX = bods.vel.x[i];
					var velY = bods.vel.y[i];
					var vel = Math.sqrt(velX*velX+velY*velY);
					var tempSpringX = (bods.vel.x[i]+((vectorX*springFactor*vel)))/friction;
					var tempSpringY = (bods.vel.y[i]+((vectorY*springFactor*vel)))/friction;
					bods.vel.x[i] = tempSpringX;
					bods.vel.y[i] = tempSpringY;
				}
			}
		}
	}
}//................attraction
IB.update.nodeAttract = function(node1, node2){
	var P = IB.config.node.attraction;

	//nodes attract along link lines according to hookes law
	var xpDiff = node2.x-node1.x;
	var ypDiff = node2.y-node1.y;
	var xsign=xpDiff/Math.abs(xpDiff);
	var ysign=ypDiff/Math.abs(ypDiff);
	if (isNaN(xsign)) xsign=1;
	if (isNaN(ysign)) ysign=1;
	
	var Exceed = -(Math.sqrt(xpDiff*xpDiff+ypDiff*ypDiff))*P.attraction*node1.whuffie*node2.whuffie;
	
	var xExceed=xsign*Exceed;
	var yExceed=ysign*Exceed;
	var xpSpeed= P.dumping*(node2.xspeed+xExceed*P.tu);
	var ypSpeed= P.dumping*(node2.yspeed+yExceed*P.tu);
	var xInertion = xpSpeed*P.tu  + parseInt(xsign*xExceed)*P.tu*P.tu/2;
	var yInertion = ypSpeed*P.tu  + parseInt(ysign*yExceed)*P.tu*P.tu/2;
	if (isNaN(xInertion)) xInertion=0;
	if (isNaN(yInertion)) yInertion=0;
	
	node2.x += xInertion ; 
	node2.y += yInertion ; 
	//jiggle the node a bit to avoid stuck nodes
		var rando=Math.floor(Math.random()*5)
		if (rando = 1) node2.x += 1;
		if (rando = 2) node2.x -= 1;
		if (rando = 3) node2.y += 1;
		if (rando = 4) node2.y -= 1;
}
	//nodes repulse all other nodes (coulombs law)
	//bernes-hut optimised implementation
	/*
Copyright (c) 2012, Sameer Ansari - elucidation@gmail.com
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met: 

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer. 
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution. 

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies, 
either expressed or implied, of the FreeBSD Project.
*/
////////////
var DEBUG = 0; // Extra info in console (0=Off,1=Low,2=Absurd, 3=BNtree)
var DEBUGMAX = 5; // Levels of DEBUG

// Reality
// var MINMASS = 1e20;
// var MAXMASS = 1e30;
// var G = 6.673e-11; // Gravitational Constant
// var ETA = 0.01; // Softening constant
// var GFACTOR = 1.3; // Higher means distance has more effect (3 is reality)
// var dt; // Global DT set by html
// var MAXDEPTH = 50; // BN tree max depth ( one less than actual, example with maxdepth = 2, the levels are [0 1 2] )
// var BN_THETA = 0.5;
// var DISTANCE_MULTIPLE = 1e9; // # meters per pixel (ex 1, 1 meter per pixel)
// 1e3 = km, 1e6 = Mm, 1e9 = Gm, 149.60e9 = Au, 9.461e15 = LightYear, 30.857e15 = Parsec
var MINMASS = 1e2;
var MAXMASS = 1e10;
var G = 1e-5; // Gravitational Constant
var ETA = 10; // Softening constant
var GFACTOR = 1.3; // Higher means distance has more effect (3 is reality)

var DISTANCE_MULTIPLE = 2;

var INTERACTION_METHOD = "BN"; // BN or BRUTE, type of tree search to use
var MAXDEPTH = 50; // BN tree max depth ( one less than actual, example with maxdepth = 2, the levels are [0 1 2] )
var BN_THETA = 0.5;

var dt; // Global DT set by html
// Bodies struct containing all bodies
var bods;

//feed nodes into engine

//bods.pos = IB._nodes[x,y]
//bods.vel = IB._nodes[xpSpeed,ypSpeed]
//bods.mass = IB._nodes[(whuffie * -1)]

function resetBodies() {
	if (bods) {
		bods.pos = null;
		bods.vel = null;
		bods.mass = null;
	}

	bods = {pos:{x:new Array(),y:new Array()},
		id:new Array(),
		i:{},
		vel:{x:new Array(),y:new Array()},
		acc:{x:new Array(),y:new Array()},
		mass:new Array(),
		N:0};
}
resetBodies();

// Canvas Context
var c;

// Called by HTML with canvasId passed in
function initBN(canvasId) {
	canvasElement = document.getElementById(canvasId);
	c = canvasElement.getContext("2d");

	resetBodies();

	if (DEBUG) {
		console.log('Initialize BN complete.');
	}
}

function addBody(x,y,vx,vy,m,id) {
	bods.id [bods.N] = id;
	bods.i [id] = bods.N;
	bods.pos.x [bods.N] = x;
	bods.pos.y [bods.N] = y;
	bods.vel.x [bods.N] = vx;
	bods.vel.y [bods.N] = vy;
	bods.acc.x [bods.N] = 0;
	bods.acc.y [bods.N] = 0;
	bods.mass [bods.N] = m;
	bods.N = bods.N + 1;

	if (DEBUG) {
	    console.log("ADD BODY M: ",m," P:",x,",",y," V:",vx,",",vy,",",id);
	}
	if (bods.N >= 100 && DEBUG > 0) {
		setDEBUG(0); // temp check to keep debug off when too many bodies
	}
	if (!sysRunning) {bnBuildTree();}
}
// BN Tree code ------
var bnDepth=0, bnNumNodes=0, bnNumLeafs=0;
function bnSetTreeStats() {
	bnDepth=0, bnNumNodes=0, bnNumLeafs=0;
	bnSetTreeStatsRecurse(bnRoot,0);
}
function bnSetTreeStatsRecurse(node,depth) {
	// If body in node
	bnNumNodes += 1;
	bnDepth = Math.max(depth,bnDepth);

	if ( node.b.length > 0 ) {
		if (node.b != "PARENT") {
			bnNumLeafs += 1;
		}
		// Draw Children
		for (var i=0;i<4;i++){
			var child = node.nodes[i];
			if (child) { bnSetTreeStatsRecurse(child,depth+1) }
		}
	}
}

function bnDeleteTree() {
	if (bnRoot) {bnRoot = bnDeleteNode(bnRoot);}
}
function bnDeleteNode(node) {
	node.b = null;
	node.box = null;
	// For each child
	for (var i=0;i<4;i++) {
		if (node.nodes[i]) { // If child exists
			node.nodes[i] = bnDeleteNode(node.nodes[i]);
		}
	}
	return null;
}

var bnRoot;
function bnBuildTree() {
	bnDeleteTree(bnRoot); // Delete Tree to clear memory
	bnRoot = {b: [], // Body
		leaf:true,
		CoM: null, // center of mass
		nodes:[null,null,null,null],
		// x y x2 y2
		box:[0, 0, IB.config.screen.w, IB.config.screen.h]};

	// Add each body to tree
	for (var i=0;i<bods.N;i++) {
		if (pointInBBOX(bods.pos.x[i],bods.pos.y[i],bnRoot.box)) {
			bnAddBody(bnRoot,i,0);
		}
		else {
			if (DEBUG>=4) {console.log("Body ",i," has left the BNtree area. Not added");}
		}
	}
	if (DEBUG>=2) {
		console.log("BNtree Built: ",bnRoot);
	}
	bnSetTreeStats(); // Update bn tree stats
}

// BBOX = [x y x2 y2]
function pointInBBOX(x,y,BBOX) {
	if (x >= BBOX[0] && x <= BBOX[2] && y >= BBOX[1] && y <= BBOX[3]) {return true;}
	else {return false;}
}

function bnAddBody(node,i,depth) {
	if (DEBUG>=3) {
		console.log("bnAddBody(",node,",",i,",",depth,")");
	}
	// if node has body already
	if ( node.b.length > 0 ) { // not empty
		// Check if hit max depth
		if (depth > MAXDEPTH) {
			if (DEBUG>=3) {console.log('MAX DEPTH B',i);}
			node.b [node.b.length] = i; // Add body to same node since already at max depth
		} 
		else {
			var subBodies;
			if (!node.leaf) { // Same as saying node.b = "PARENT"
				// Node is a parent with children
				subBodies = [i];
			} else {
				// Node is a leaf node (no children), turn to parent
				subBodies = [node.b,i];
			}
			for (var k=0;k<subBodies.length;k++) {
				// Add body to children too		
				var quad = getQuad(subBodies[k],node.box);
				var child = node.nodes[quad];
				if (child) {
					// if quad has child, recurse with child
					bnAddBody(child,subBodies[k],depth+1);
				} else {
					// else add body to child
					node = bnMakeNode(node,quad,subBodies[k]);
				}
			}
			node.b = ["PARENT"];
			node.leaf = false; // Always going to turn into a parent if not already
		}
		// Update center of mass
		node.CoM[1] = (node.CoM[1]*node.CoM[0] + bods.pos.x[i]*bods.mass[i])/(node.CoM[0]+bods.mass[i]);
		node.CoM[2] = (node.CoM[2]*node.CoM[0] + bods.pos.y[i]*bods.mass[i])/(node.CoM[0]+bods.mass[i]);
		node.CoM[0] += bods.mass[i];
	} else { // else if node empty, add body
		node.b = [i];
		node.CoM = [bods.mass[i], bods.pos.x[i],bods.pos.y[i]]; // Center of Mass set to the position of single body
	}
}

function getQuad(i,box) {
	var mx = (box[0]+box[2])/2;
	var my = (box[1]+box[3])/2;
	if (bods.pos.x[i] < mx) { // Left
		if (bods.pos.y[i] < my) {return 0;} // Top
		else {return 2;} // Bottom
	}
	else { // right
		if (bods.pos.y[i] < my) {return 1;} // Top
		else {return 3;} // Bottom}
	}
}

function bnMakeNode(parent,quad,child) {
	if (DEBUG>=3) {
		console.log("bnMakeNode(",parent,",",quad,",",child,")");
	}
	var child = {b:[child],
		leaf:true,
		CoM : [bods.mass[child], bods.pos.x[child],bods.pos.y[child]], // Center of Mass set to the position of single body
		nodes:[null,null,null,null],
		box:[0,0,0,0]};

	switch (quad) {
		case 0: // Top Left
			child.box = [parent.box[0],
				parent.box[1],
				(parent.box[0]+parent.box[2])/2, 
				(parent.box[1]+parent.box[3])/2];
			break;
		case 1: // Top Right
			child.box = [(parent.box[0]+parent.box[2])/2,
				parent.box[1],
				parent.box[2], 
				(parent.box[1]+parent.box[3])/2];
			break;
		case 2: // Bottom Left
			child.box = [parent.box[0],
				(parent.box[1]+parent.box[3])/2,
				(parent.box[0]+parent.box[2])/2, 
				parent.box[3]];
			break;
		case 3: // Bottom Right
			child.box = [(parent.box[0]+parent.box[2])/2,
				(parent.box[1]+parent.box[3])/2,
				parent.box[2], 
				parent.box[3]];
			break;
	}
	parent.nodes[quad] = child;
	return parent;
}

function doBNtree(bI) {
	doBNtreeRecurse(bI,bnRoot);
}
function doBNtreeRecurse(bI,node) {
	if (node.leaf) {
		// If node is a leaf node
		for (var k=0;k<node.b.length;k++) {
			if (bI != node.b[k]) { // Skip self
				setAccel(bI,node.b[k],false);
				numChecks += 1;
			}
		}
	}
	else {
		var s = Math.min( node.box[2]-node.box[0] , node.box[3]-node.box[1] ); // Biggest side of box
		var d = getDist(bods.pos.x[bI],bods.pos.y[bI],
			node.CoM[1],node.CoM[2]);
		if (s/d < BN_THETA) {
			setAccelDirect(bI,node.CoM[0],node.CoM[1],node.CoM[2])
			numChecks += 1;
		}
		else {
			// Recurse for each child
			for (var k=0;k<4;k++) {
				if (node.nodes[k]) {doBNtreeRecurse(bI,node.nodes[k]);}
			}
		}
	}
}

function getDist(x,y,x2,y2) {
	return Math.sqrt(Math.pow(x2-x,2)+Math.pow(y2-y,2));
}

// Update accelerations using BN tree
function forceBNtree() {
	bnBuildTree(); // Build BN tree based on current pos
	numChecks = 0;
	for (var i=0;i<bods.N;i++) {
		// For each body
		doBNtree(i);
	}
}
// ------
// do_Both defaults true: Updates acceleration of bods[j] also (negative of bods[i])

function setAccel(i,j,do_Both) {
	do_Both = typeof(do_Both) != 'undefined' ? do_Both : true;

	// Get Force Vector between bodies i, j
	var F = getForceVec(i,j);

	// a = F/m
	// Body i
	bods.acc.x[i] += F[0]/bods.mass[i];
	bods.acc.y[i] += F[1]/bods.mass[i];

	if (do_Both) {
		// Body j, equal and opposite force
		bods.acc.x[j] -= F[0]/bods.mass[j];
		bods.acc.y[j] -= F[1]/bods.mass[j];
	}
}
function setAccelDirect(i,m,x,y) {
	// Set's accel according to given mass

	// get Force Vector between body i
	// and a virtual mass
	//   with mass m, at position cx,cy
	var F = getForceVecDirect(
		bods.mass[i],bods.pos.x[i],bods.pos.y[i],
		m,x,y);

	// Update acceleration of body
	bods.acc.x[i] += F[0]/bods.mass[i];
	bods.acc.y[i] += F[1]/bods.mass[i];
}

function getForceVec(i,j) {
	if (DEBUG>=10) {
		console.log("B",i," <-> B",j," : ",F);
	}
	return getForceVecDirect(
		bods.mass[i],bods.pos.x[i],bods.pos.y[i],
		bods.mass[j],bods.pos.x[j],bods.pos.y[j]);
}

function getForceVecDirect(m,x,y,m2,x2,y2) {
	// Determines force interaction between
	// bods[i] and bods[j], an adds to bods[i]
	var dx = x2-x;
	var dy = y2-y;
	var r = (getDist(x,y,x2,y2)+ETA) * DISTANCE_MULTIPLE;
	// F_{x|y} = d_{x|y}/r * G*M*m/r.^3;
	var F = G*m*m2/Math.pow(r,GFACTOR);

	return [ F*dx/r , F*dy/r ];
}


// Update accels by checking every body to each other
function forceBrute() {
	numChecks = 0;
	// Brute force O(n^2) comparisons
	for (var i=0;i<bods.N;i++) {
		for (var j=i+1;j<bods.N;j++) {
			setAccel(i,j);
			numChecks += 1;
		}
	}
}


var numChecks;
// Set accelerations of bodies based on gravity
function doForces() {
	// Zero accelerations
	for (var i=0;i<bods.N;i++) {
		bods.acc.x[i]=0;
		bods.acc.y[i]=0;
	}

	// Determine accelerations on all bodies
	switch (INTERACTION_METHOD) {
		case "BRUTE":
			forceBrute();
			break;
		case "BN":
			bnBuildTree(); // REMOVE WHEN doing forceBNtree!
			forceBNtree();
			break;
	}

	if (DEBUG>=2) {
		console.log("# Force Checks: ",numChecks);
	}
}

// Basic update system step by time step dt
var T = 0; // current system time
var dt = 0.01;
var stepTime;
function step() {
	var startTime = (new Date()).getTime();

	// Use integration method to step once by global dt
	leapfrog();

	stepTime = (new Date()).getTime()-startTime;

	T += dt;
	if (DEBUG>=2) {
	    console.log("STEP");
	}
	//if (!sysRunning) {refreshGraphics();} // Refresh graphics if paused
}
function forwardEuler() {
	doForces(); // Set/Update accelerations
	updatePos(dt); // Move full step
	updateVel(dt); // Move Velocities full step
}

function leapfrog() {
	updatePos(0.5*dt); // Move half step
	doForces(); // Set/Update accelerations
	updateVel(dt); // Move Velocities full step
	updatePos(0.5*dt); // Move half step
}

function updatePos(dt_step) {
	// Update body positions based on velocities
	for (var i=0;i<bods.N;i++) {
		var x = bods.vel.x[i]*dt_step;
		var y = bods.vel.y[i]*dt_step;
		bods.pos.x[i] += x;
		bods.pos.y[i] += y;
		var node = IB.node.get(bods.id[i]);
		var x = bods.pos.x[i];
		var y = bods.pos.y[i];
		node.x = x;
		node.y = y;
		
	}
}
function updateVel(dt_step) {
	// Update body velocities based on accelerations
	for (var i=0;i<bods.N;i++) {
		bods.vel.x[i] += bods.acc.x[i]*dt_step;
		bods.vel.y[i] += bods.acc.y[i]*dt_step;
		if(!bods.id[i]){
			bods.vel.x[i] = 0;
			bods.vel.y[i] = 0;
		}
	}
}


var sysTimer;
var sysRunning = false;
function startSys() {
	sysTimer = setInterval(step,10);
	gfxTimer = setInterval(refreshGraphics,1/60.0*1000);
	sysRunning = true;
	if (DEBUG) {
	    console.log("START SYSTEM ",T,"s");
	}
	refreshGraphics();
}
function pauseSys() {
	clearInterval(sysTimer);
	clearInterval(gfxTimer);
	sysRunning = false;
	if (DEBUG) {
	    console.log("STOP SYSTEM ",T,"s");
	}
	refreshGraphics();
}






//................repulsion
IB.update.nodeDetract = function(){
	//var P = IB.config.node.repulsion;
	var startTime = (new Date()).getTime();
	// Use integration method to step once by global dt
	leapfrog();

	stepTime = (new Date()).getTime()-startTime;

	T += dt;
	if (DEBUG>=2) {
	    console.log("STEP");
	}
}


IB.update.nodeDetractLoad = function(node){
	var x = node.x;
	var y = node.y;
	var vx = 0;
	var vy = 0;
	var m = -100000000*node.whuffie;
	var id = node.id;
	addBody(x,y,vx,vy,m,id);
	
}//feed engine output back into nodes

//IB._nodes[x,y] = bods.pos
//IB._nodes[xpSpeed,ypSpeed] = bods.vel

IB.update.node = function(node){ 
	var zoom = IB.config.screen.zoom;
	var x = node.x-node.whuffie/4;
	var y = node.y-node.whuffie/4;
	var w = node.whuffie/2;
	var h = node.whuffie/2;
	var r = (w+h)/4;
	var childrenWhuffie = IB.node.childrenWhuffie(node);
	var children = IB.node.children(node);
	var childrenAverageWhuffie = 1;
	if(children.length)childrenAverageWhuffie = childrenWhuffie/children.length;
	var sw = IB.update.calc(node.whuffie/childrenAverageWhuffie, IB.config.node.strokeWidth);
	x *= zoom;
	y *= zoom;
	w *= zoom;
	h *= zoom;
	r *= zoom;
	sw *= zoom;
	node._.attr('x', x)
		.attr('y', y)
		.attr('width', w)
		.attr('height', h)
		.attr('r', r)
		.attr('stroke-width',sw);
}

IB.update.nodeHtml = function(node){
	var zoom = IB.config.screen.zoom;
	var x = node.x-node.whuffie/4;
	var y = node.y-node.whuffie/4;
	var cw = node.whuffie/2;
	var ch = node.whuffie/2;
	var rw = Math.sqrt(cw*cw/2);
	var rh = Math.sqrt(ch*ch/2);
	var rx = x+(cw-rw)/2;
	var ry = y+(ch-rh)/2;
	var childrenWhuffie = IB.node.childrenWhuffie(node);
	var children = IB.node.children(node);
	var childrenAverageWhuffie = 1;
	if(children.length)childrenAverageWhuffie = childrenWhuffie/children.length;
	var sw = IB.update.calc(node.whuffie/childrenAverageWhuffie, IB.config.node.strokeWidth);
	var fs = '';
	if(node.type=='text')fs = IB.update.calc((Math.pow((node.whuffie/2),2)/node.html.length), IB.config.node.textAdjust);
	var lh = fs/10;
	var lines =(Math.pow((node.whuffie/2),2)%node.html.length);
	lines = (lines>1)?(lines>1):2;
	var pt = (node.whuffie/2-(fs*lines));
	rx *= zoom;
	ry *= zoom;
	rw *= zoom;
	rh *= zoom;
	sw *= zoom;
	fs *= zoom;
	lh *= zoom;
	node._html.css('left', rx)
		.css('top', ry)
		.css('width', rw)
		.css('height', rh)
		.css('font-size', fs);
	node._html.find('.html').css('top', pt);
	node._html.find('.edit').css('borderWidth', sw);
	node._html.find('.vote').css('borderWidth', sw);
}

IB.update.nodePositions = function(node){
	IB.update.updateInstance++;
	IB.update.nodePositionsRecursive();
}
IB.update.nodePositionsRecursive = function(node){
	if(!node)node = IB.node.get(0);
	if(!node.updated || node.updated!=IB.update.updateInstance){
		node.updated = IB.update.updateInstance;
		IB.node.updateChildNodePositions(node);
	}
	var children = IB.node.children(node.id);
	for(var x in children){
		var child = children[x];
		IB.update.nodePositionsRecursive(child);
	}
}


//when I add a node containing 
//<upload:path>
//the file is fetched and uploaded as the node content. if the path is a folder, all files in that path are uploaded.
//possibly use ocupload for this
//code defining a video node, which contains video content only, typically linked to
//it's soundtrack which is in an audio node.
//code for computer vision, recognising objects etc.//code defining whuffie, and it's transfer.;

//allow users to comment, like, friend and upload to infoburp nodes and links from facebook.com (app)
//after adding the infoburp app to their page//allow users to comment and upload into nodes from googleplus.com
//after adding the infoburp app to their page//allow users to tweet directly into nodes from twitter.com (app)
//after adding the infoburp app to their page//code defining an audio node, a node containing audio which may often be a soundtrack linked
//to a video node.
//perform some process on audio, like a mixer, or softsynth for example//code defining bubbles and the effect they have on nodes
//shown as a circle surrounding a set of related nodes
//if the user zooms out enough, show the bubbles as a euler diagram.
//there is one master bubble, bubble0, which contains all other bubbles
//and by extension all the nodes and links on infoburp.

//bubbles form a type of euler diagraminterface WebCLBuffer : WebCLMemoryObject {
  WebCLBuffer createSubBuffer(CLenum flags, CLuint origin, CLuint size);
};//buy whuffie from infoburp or other users for cash.
//make sure that node content is available under a suitable open source / free / cc license.//take a node containing a boardmap with a flag stating whose move it is as input

//output possible moves as links to other boardmaps

//in this way, eventually every possible chess game is played.
	
	//find pieces that are free to move

	//find moves those pieces can take

	//output moves as links to resultant boardmaps

	//give the boardmap a whuffie score based on the current player's position + future.//http://en.wikipedia.org/wiki/Clique_(graph_theory)require_once('jsmin.php');

$files = glob("*.js");
$js = "";
foreach($files as $file) {
    $js .= JSMin::minify(file_get_contents($file));
}

file_put_contents("combined.js", $js); 
interface WebCLCommandQueue {

  ////////////////////////////////////////////////////////////////////////////
  //
  // Copying: Buffer <-> Buffer, Image <-> Image, Buffer <-> Image
  //

void enqueueCopyBuffer(
                    WebCLBuffer             srcBuffer,
                    WebCLBuffer             dstBuffer,
                    CLuint                  srcOffset,
                    CLuint                  dstOffset,
                    CLuint                  sizeInBytes, 
                    optional WebCLEvent[]?  eventWaitList,
                    optional WebCLEvent?    event);
                            
void enqueueCopyBufferRect(
                    WebCLBuffer             srcBuffer,
                    WebCLBuffer             dstBuffer, 
                    CLuint[3]               srcOrigin,
                    CLuint[3]               dstOrigin,
                    CLuint[3]               region, 
                    CLuint                  srcRowPitch,
                    CLuint                  srcSlicePitch,
                    CLuint                  dstRowPitch,
                    CLuint                  dstSlicePitch,
                    optional WebCLEvent[]?  eventWaitList,
                    optional WebCLEvent?    event);

void enqueueCopyImage(
                    WebCLImage              srcImage,
                    WebCLImage              dstImage, 
                    CLuint[3]               srcOrigin,
                    CLuint[3]               dstOrigin,
                    CLuint[3]               region, 
                    optional WebCLEvent[]?  eventWaitList,
                    optional WebCLEvent?    event);

void enqueueCopyImageToBuffer(
                    WebCLImage              srcImage,
                    WebCLBuffer             dstBuffer, 
                    CLuint[3]               srcOrigin,
                    CLuint[3]               region, 
                    CLuint                  dstOffset,
                    optional WebCLEvent[]?  eventWaitList,
                    optional WebCLEvent?    event);

void enqueueCopyBufferToImage(
                    WebCLBuffer             srcBuffer,
                    WebCLImage              dstImage, 
                    CLuint                  srcOffset,
                    CLuint[3]               dstOrigin,
                    CLuint[3]               region, 
                    optional WebCLEvent[]?  eventWaitList,
                    optional WebCLEvent?    event);

  ////////////////////////////////////////////////////////////////////////////
  //
  // Reading: Buffer -> Host, Image -> Host
  //

void enqueueReadBuffer(
                    WebCLBuffer             buffer,
                    CLboolean               blockingRead,
                    CLuint                  offset,
                    CLuint                  sizeInBytes, 
                    ArrayBuffer             ptr,
                    optional WebCLEvent[]?  eventWaitList, 
                    optional WebCLEvent?    event);
                            
void enqueueReadBufferRect(
                    WebCLBuffer             buffer,
                    CLboolean               blockingRead,
                    CLuint[3]               bufferOrigin,
                    CLuint[3]               hostOrigin, 
                    CLuint[3]               region,
                    CLuint                  bufferRowPitch,
                    CLuint                  bufferSlicePitch,
                    CLuint                  hostRowPitch,
                    CLuint                  hostSlicePitch,
                    ArrayBuffer             ptr,
                    optional WebCLEvent[]?  eventWaitList, 
                    optional WebCLEvent?    event);
  
void enqueueReadImage(
                    WebCLImage              image,
                    CLboolean               blockingRead, 
                    CLuint[3]               origin,
                    CLuint[3]               region,
                    CLuint                  rowPitch,
                    CLuint                  slicePitch, 
                    ArrayBuffer             ptr,
                    optional WebCLEvent[]?  eventWaitList,
                    optional WebCLEvent?    event);

  ////////////////////////////////////////////////////////////////////////////
  //
  // Writing: Host -> Buffer, Host -> Image
  //

void enqueueWriteBuffer(
                    WebCLBuffer             buffer,
                    CLboolean               blockingWrite, 
                    CLuint                  offset, 
                    CLuint                  sizeInBytes, 
                    ArrayBuffer             ptr,
                    optional WebCLEvent[]?  eventWaitList, 
                    optional WebCLEvent?    event);
                            
void enqueueWriteBufferRect(
                    WebCLBuffer             buffer,
                    CLboolean               blockingWrite,
                    CLuint[3]               bufferOrigin,
                    CLuint[3]               hostOrigin,
                    CLuint[3]               region,
                    CLuint                  bufferRowPitch,
                    CLuint                  bufferSlicePitch,
                    CLuint                  hostRowPitch,
                    CLuint                  hostSlicePitch,
                    ArrayBuffer             ptr,
                    optional WebCLEvent[]?  eventWaitList,
                    optional WebCLEvent?    event);
  
void enqueueWriteImage(
                    WebCLImage              image,
                    CLboolean               blockingWrite, 
                    CLuint[3]               origin,
                    CLuint[3]               region,
                    CLuint                  inputRowPitch,
                    CLuint                  inputSlicePitch, 
                    ArrayBuffer             ptr,
                    optional WebCLEvent[]?  eventWaitList,
                    optional WebCLEvent?    event);

  ////////////////////////////////////////////////////////////////////////////
  //
  // Acquiring and releasing WebGL objects
  //

  void enqueueAcquireGLObjects(WebCLMemoryObject[] memObjects,
                               optional WebCLEvent[]? eventWaitList,
                               optional WebCLEvent? event);
 
  void enqueueReleaseGLObjects(WebCLMemoryObject[] memObjects,
                               optional WebCLEvent[]? eventWaitList,
                               optional WebCLEvent? event);
  
  ////////////////////////////////////////////////////////////////////////////
  //
  // Executing kernels
  //

  void enqueueNDRangeKernel(WebCLKernel kernel, 
                            CLuint[]? offsets, CLuint[]? globals, CLuint[]? locals, 
                            optional WebCLEvent[]? eventWaitList,
                            optional WebCLEvent? event);
  
  void enqueueTask(WebCLKernel kernel, 
                   optional WebCLEvent[]? eventWaitList,
                   optional WebCLEvent? event);
  
  ////////////////////////////////////////////////////////////////////////////
  //
  // Synchronization
  //

  void enqueueMarker(optional WebCLEvent[]? eventWaitList, optional WebCLEvent? event);

  void enqueueBarrier(optional WebCLEvent[]? eventWaitList, optional WebCLEvent? event);
  
  void finish();
  
  void flush();

  ////////////////////////////////////////////////////////////////////////////
  //
  // Querying command queue information
  //

  any getInfo(CLenum name);
};//compare one hash to another, and give a % match result

//http://en.wikipedia.org/wiki/Damerau%E2%80%93Levenshtein_distance

//based on: http://en.wikibooks.org/wiki/Algorithm_implementation/Strings/Levenshtein_distance

//and:  http://en.wikipedia.org/wiki/Damerau%E2%80%93Levenshtein_distance


//http://www.dzone.com/snippets/javascript-implementation

function levenshtein( a, b )

{

var i;

var j;

var cost;

var d = new Array();

 

if ( a.length == 0 )

{

return b.length;

}

 

if ( b.length == 0 )

{

return a.length;

}

 

for ( i = 0; i <= a.length; i++ )

{

d[ i ] = new Array();

d[ i ][ 0 ] = i;

}

 

for ( j = 0; j <= b.length; j++ )

{

d[ 0 ][ j ] = j;

}

 

for ( i = 1; i <= a.length; i++ )

{

for ( j = 1; j <= b.length; j++ )

{

if ( a.charAt( i - 1 ) == b.charAt( j - 1 ) )

{

cost = 0;

}

else

{

cost = 1;

}

 

d[ i ][ j ] = Math.min( d[ i - 1 ][ j ] + 1, d[ i ][ j - 1 ] + 1, d[ i - 1 ][ j - 1 ] + cost );

 

if(

i > 1 &&

j > 1 && 

a.charAt(i - 1) == b.charAt(j-2) &&

a.charAt(i-2) == b.charAt(j-1)

){

d[i][j] = Math.min(

d[i][j],

d[i - 2][j - 2] + cost

)

 

}

}

}

 

return d[ a.length ][ b.length ];

}IB.config = {
	//configure how the interface looks
	node: {
		fillColor: 'white',
		strokeColor: 'green',
		dragLineColor: '#FF7E00',
		strokeColorEditing: '#FF7E00',
		strokeWidth: .15,
		padding: 10,
		textAdjust: 1,
		attraction: {
			"coloumb":4000,
			"attraction":4,
			"jiggle":0.001,
			"dumping":.08,
			"tu":0.1,
			"X_MIN":20,
			"X_MAX":1000,
			"Y_MIN":20,
			"Y_MAX":1000
		},
		repulsion: {
			"coloumb":4000,
			"attraction":-.000004,
			"jiggle":0.001,
			"dumping":.08,
			"tu":0.1,
			"X_MIN":20,
			"X_MAX":1000,
			"Y_MIN":20,
			"Y_MAX":1000
		}
	},
	//configure the x,y,w,h,zoom
	screen: {
		x: 0,
		y: 0,
		w: null,
		h: null,
		zoom: 3
	},
};
//scale down hosting by amount

hosting.scale.down(amount)

	{

	}

//scale up hosting by amount

hosting.scale.up(amount)

	{

	}//allow items listed on ebay to be added to infoburp as nodes, earning ebay affiliate revenue//send and receive emails from a remote email server
//uses socket.io

//every node,link and bubble is given a unique email adress like graeme.wolfendale@infoburp.com
//the infoburp system acts as an email system, storing, forwarding, sending and receiving
//emails.//if user logs in with facebook id

//allow them to post any node to their facebook


//connect to a remote ftp server. upload and download files.
//uses socket.io//connect to a git repository, push and pull project files.
//uses socket.io//connect to a googleplus account
//connect to a webserver using http protocol
//uses socket.io

	//take input remote url

		url=node.html

	//pull the requested url

		connect.network(url,data)

	//add the html returned as a node on infoburp

		IB.node.add(data)

//sparql connector

//sparql.js - take a hyperlink to a sparql endpoint in a node

//sparql endpoints automatically connect to other nodes, with a preference for attaching
//to nodes with a lot of whuffie.

//return sparql query results for all attached nodes.

//get input (node html of node linked to endpoint node)

//parse node contents into sparql query


	//*code needed - take endpoint.node.html and node.html as input, parse in a sparql query*


//endpoint.node.html in format 

//"<sparql:endpoint searchin>"

//example:

//endpoint.node.html"<sparql:dbpedia Pages>"

//node.html="city"

//queryStr = "select distinct ?Page where {<city> ?Page}" 



//what we are searching for (node content of node linked to endpoint node)

   	searchfor=selected.node.html

//where we are searching for it (hyperlink to the sparql endpoint)

   	endpoint=endpoint.node.html

//parse query where ?searchin = search for this type of resource

//this returns things that we talk about on infoburp

   	queryStr = "select distinct ?searchin where {<searchfor> ?searchin}" 

//prepare sparql to json query

   	function sparqlQueryJson(queryStr, endpoint, callback, isDebug) {

     	var querypart = "query=" + escape(queryStr);

     // HTTP request object.

     	var xmlhttp = null;

     	if(window.XMLHttpRequest) 	{

       		xmlhttp = new XMLHttpRequest();

    					} 
	else if(window.ActiveXObject) 	{

      // internet exploder support

      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");

    					}
	 else 				{

      	alert('Sorry, you should get a better browser..');

    					}

    // POST with JSON result format.

    	xmlhttp.open('POST', endpoint, true); 

    	xmlhttp.setRequestHeader('Content-type','application/x-www-form-urlencoded');

    	xmlhttp.setRequestHeader("Accept", "application/sparql-results+json");

    // callback to get the response

    	xmlhttp.onreadystatechange = function() {

      	if(xmlhttp.readyState == 4) 	{

        	if(xmlhttp.status == 200) 	{

          		// do with the results

          		if(isDebug) alert(xmlhttp.responseText);

          		callback(xmlhttp.responseText);

        					}
		else 				{

          		// error handler

          		// alert("Sparql query error: " + xmlhttp.status + " "

          		//    + xmlhttp.responseText);

        					}

      					}

    	};

    	// send query

    	xmlhttp.send(querypart);

    	// wait for callback

   	};
        
     		var query = "select * {?s ?p ?o} limit 5" ;

     	// define callback functions

     		function myCallback(str) {

       // convert result to JSON

       		var jsonObj = eval('(' + str + ')');

       // make table of results

       		var result = " <table border='2' cellpadding='9'>" ;

       		for(var i = 0; i<  jsonObj.results.bindings.length; i++) 
					{

         	result += " <tr> <td>" + jsonObj.results.bindings[i].s.value;

         	result += " </td><td>" + jsonObj.results.bindings[i].p.value;

         	result += " </td><td>" + jsonObj.results.bindings[i].o.value;

         	result += " </td></tr>";

       					}

       		result += "</table>" ;

       		document.getElementById("results").innerHTML = result;

    				}

    		// run query

    			sparqlQueryJson(query, endpoint, myCallback, true);

    		//this gives us sparql results in json format to plug into the rest of the code.//sql connector

//take a node with a mysql endpoint url, a username and a password.

//in the format <mysql:localhost,user:username,pass:password>

var endpoint

var username

var password

//turn it into a mysql endpoint node. run a query for any nodes that are linked
//to this endpoint node.

nodes: function(){
		$.ajax({
			url: 'action/remote.php?action=getAll',
			dataType: 'json',
			method: 'get',
			success:function(data){
				IB._nodes = data;
				IB.search.load();
			    IB.create.load(IB._nodes);
				IB.config.screen.zoom = IB.config.screen.h/(IB.update.calc(IB._nodes.totalWhuffie)/2);
			    // To make nodes spread around central node
			    IB._nodes.x = 0;
				IB._nodes.y = 0;
				IB.update.all();
				IB.event.loadAll();
			}
		});
//connect to a remote secure shell
//connect to a remote shell
//if user logs in with twitter id

//allow them to tweet any node

//allow adding arbitrary data as node contentinterface WebCLContext {

    WebCLBuffer createBuffer(CLenum memFlags, CLuint sizeInBytes, optional ArrayBuffer srcBuffer);

    WebCLCommandQueue createCommandQueue(optional WebCLDevice[]? devices, optional CLenum properties);

    WebCLBuffer createFromGLBuffer(CLenum memFlags, WebGLBuffer buffer);

    WebCLImage createFromGLRenderBuffer(CLenum memFlags, WebGLRenderbuffer renderbuffer);

    WebCLImage createFromGLTexture2D(CLenum memFlags, GLenum textureTarget, 
                                      GLint miplevel, WebGLTexture texture);

    WebCLImage createImage(CLenum memFlags, 
                           WebCLImageDescriptor descriptor,
                           optional ArrayBuffer srcBuffer);

    WebCLProgram createProgram(DOMString source);

    WebCLSampler createSampler(CLboolean normalizedCoords,
                               CLenum addressingMode,
                               CLenum filterMode);

    WebCLEvent createUserEvent();

    any getInfo(CLenum name);

    WebCLImageDescriptor[] getSupportedImageFormats(CLenum memFlags,
                                                    CLenum imageType);
};
dictionary WebCLImageDescriptor {
  CLenum channelOrder = 0x10B5;            // 0x10B5 == WebCL.RGBA
  CLenum channelType = 0x10D2;             // 0x10D2 == WebCL.UNORM_INT8, 8-bit colors normalized to [0, 1]
  CLuint width = 0, height = 0;
  CLuint rowPitch = 0;
};//read the node.html
//if it contains links to other urls, these urls are added as new nodes containing the urls
//linked to.
//in time these pages will be fetched, also.
//create a new node
IB.create = {
	load: function(){
		IB.create.loop();
	},
	loop: function(){
		for(var x in IB._nodes){
			var node = IB._nodes[x];
			IB.create.fixInt(node);
			IB.create.node(node);
			IB.create.nodeHtml(node);
			IB.update.nodeDetractLoad(node);
		}
		for(var x in IB._links){
			var link = IB._links[x];
			IB.create.link(link);
		}
	},
	fixInt: function(node){
		if(!parseInt(node.id)){
			//node.x = 0;
			//node.y = 0;
			node.xspeed = 4;
			node.yspeed = 4;
		} else {
			node.x = parseInt(node.x);
			node.y = parseInt(node.y);
			//node.x = IB.e.mouse.x;
			//node.y = IB.e.mouse.y;

		}
		//node.xspeed = 0;
		//node.yspeed = 0;
		node.whuffie = parseInt(node.whuffie);
		node.id = parseInt(node.id);
	},
	node: function(node){
		if(!node._){
			var w = node.whuffie;
			var h = node.whuffie;
			var o = IB._.rect(node.x, node.y, w, h);
			o.attr('fill',IB.config.node.fillColor)
				.attr('stroke',IB.config.node.strokeColor)
				.attr('stroke-width',IB.config.node.strokeWidth);
			node._ = o;
		}
	},
	nodeHtml: function(node){
		if(!node._html){
			var o = $('<div></div>')
				.addClass('node')
				.attr('IB_Id', node.id)
				.appendTo(IB.__html);
			var html = $('<div></div>')
				.addClass('html')
				.html(node.html)
				.appendTo(o);
			var voteUp = $('<button></button>')
				.addClass('vote')
				.addClass('voteUp')
				.html('')//&#x25B2;
				.appendTo(o);
			var voteDown = $('<button></button>')
				.addClass('vote')
				.addClass('voteDown')
				.html('')//&#x25BC;
				.appendTo(o);
			var editor = $('<div></div>')
				.addClass('editor')
				.appendTo(o);
			var textbox = $('<textarea></textarea>')
				.addClass('textbox')
				.html(node.html)
				.appendTo(editor);
			var editSave = $('<button></button>')
				.addClass('edit')
				.addClass('editSave')
				.html('')//&#x2718;
				.appendTo(editor);
			var editCancel = $('<button></button>')
				.addClass('edit')
				.addClass('editCancel')
				.html('')//&#x2610;
				.appendTo(editor);
			node._html = o;
		}
	},
	link: function(link){
		if(!link._){
			var o = IB._.path('M0,0L0,0');
			o.attr('stroke',IB.config.node.strokeColor)
				.attr('stroke-width',IB.config.node.strokeWidth);
			o.toBack();
			link._ = o;
		}
	},
};
interface WebCLDevice {
    any getInfo(CLenum name);
    object getExtension(DOMString extensionName);
    sequence<DOMString> getSupportedExtensions();
};//code implementing the infoburp distributed hash table network

//the hashes are the locality sensitive hashes produced by hash.process.node.js

//http://en.wikipedia.org/wiki/Distributed_hash_table

//music maker//e handler for keyboard and mouse interaction
IB.e = {
	x: 0,
	y: 0,
	sx: 0,
	sy: 0,
	dragging: false,

	load: function(){
		$(document.body).bind('mousedown', function(e){ IB.e.mouse.down(e); });
		$(document.body).bind('mouseup', function(e){ IB.e.mouse.up(e); });
		$(document.body).bind('mousemove', function(e){ IB.e.mouse.move(e); });
		$(document.body).bind('mousewheel', function(e){ IB.e.mouse.scroll(e); });
		$(document.body).bind('keydown', function(e){ IB.e.keys.down(e); });
		$(document.body).bind('keyup', function(e){ IB.e.keys.up(e); });
		IB.__html.find('.node').bind('mousedown', function(e){ IB.e.mouse.node.down(e, this); });
		IB.__html.find('.node').bind('mouseup', function(e){ IB.e.mouse.node.up(e, this); });
		IB.__html.find('.node').bind('click', function(e){ IB.e.mouse.node.click(e, this); });
		IB.__html.find('.node').bind('dblclick', function(e){ IB.e.mouse.node.dblclick(e, this); });
		IB.__html.find('.node').bind('mouseout', function(e){ IB.e.mouse.node.out(e, this); });
		IB.__html.find('.node *').not('.html').bind('mousedown', function(e){ e.stopPropagation() });
		IB.__html.find('.node .editSave').bind('mouseup', function(e){ IB.e.mouse.node.edit.save.up(e) });
		IB.__html.find('.node .editCancel').bind('mouseup', function(e){ IB.e.mouse.node.edit.cancel.up(e) });
		IB.__html.find('.node .voteUp').bind('mouseup', function(e){ IB.e.mouse.node.vote.up.up(e) });
		IB.__html.find('.node .voteDown').bind('mouseup', function(e){ IB.e.mouse.node.vote.down.up(e) });
		IB.e.mouse.followRegister($('#infoburp #addNode'));
	},
	
	moveX: function(x){
		var zoom = IB.config.screen.zoom;
		IB.config.screen.x += x/zoom;
	},
	moveY: function(y){
		var zoom = IB.config.screen.zoom;
		IB.config.screen.y += y/zoom;
	},
	moveXY: function(x, y){
		var zoom = IB.config.screen.zoom;
		IB.config.screen.x += x/zoom;
		IB.config.screen.y += y/zoom;
	},
	move2XY: function(x, y){
		IB.config.screen.x = x;
		IB.config.screen.y = y;
	},

	zoom: function(i){
		i /= 10;
		IB.config.screen.zoom = (IB.config.screen.zoom+i);
		if(IB.config.screen.zoom<.1)IB.config.screen.zoom = .1;
	},
};
IB.e.keys = {
	register: {},
	_keys: [],

	_map: {
		187: function(){
			IB.e.zoom(1);
		},
		189: function(){
			IB.e.zoom(-1);
		},
		37: function(){
			IB.e.moveX(10);
		},
		39: function(){
			IB.e.moveX(-10);
		},
		38: function(){
			IB.e.moveY(10);
		},
		40: function(){
			IB.e.moveY(-10);
		},
		13: function(){
			IB.e.startEditing();
		}
	},

	map: function(){
		for(var key in IB.e.keys._keys){
			var on = IB.e.keys._keys[key];
			if(on){
				if(IB.e.keys._map[key]){
					IB.e.keys._map[key]();
				}
			}
		}
	},
	
	down: function(e){
		e = e.which?e.which:e.keyCode;
		IB.e.keys._keys[e] = 1;
	},
	up: function(e){
		e = e.which?e.which:e.keyCode;
		IB.e.keys._keys[e] = 0;
	},
}IB.e.mouse = {
	dragging: false,
	x: 0,
	y: 0,
	sx: 0,
	sy: 0,

	_followRegister: [],
	followRegister: function(el){
		IB.e.mouse._followRegister.push(el);
	},
	follow: function(){
		for(var x in IB.e.mouse._followRegister){
			var el = IB.e.mouse._followRegister[x];
			el.css('left', IB.e.mouse.x);
			el.css('top', IB.e.mouse.y);
		}
	},

	down:function(e){
		IB.e.mouse.drag.start(e);
	},
	up:function(e){
		IB.e.mouse.drag.stop(e);
		IB.e.node.createChild(e);
	},
	move:function(e){
		IB.e.mouse.drag.do(e);
		IB.e.mouse.follow();
	},
	dblclick:function(e){
		IB.e.node.setCenter(e);
	},

	drag:{
		start: function(e){
			e.preventDefault();
			IB.e.mouse.dragging = 1;
			var zoom = IB.config.screen.zoom;
			IB.config.screen.sx = IB.config.screen.x;
			IB.config.screen.sy = IB.config.screen.y;
			IB.e.mouse.x = IB.e.mouse.sx = e.pageX;
			IB.e.mouse.y = IB.e.mouse.sy = e.pageY;
			return false;
		},
		stop: function(e){
			e.preventDefault();
			if(IB.e.mouse.dragging){
				var zoom = IB.config.screen.zoom;
				IB.e.mouse.dragging = 0;
				IB.__html.parent().removeClass('dragging');
			}
			return false;
		},
		do: function(e){
			e.preventDefault();
			IB.e.mouse.x = e.pageX;
			IB.e.mouse.y = e.pageY;
			IB.e.node.moveDragLine(e, IB.e.node._selected);
			if(IB.e.mouse.dragging){
				IB.__html.parent().addClass('dragging');
				if(IB.e.mouse.dragging){
				var zoom = IB.config.screen.zoom;
					var x = (IB.config.screen.sx +(IB.e.mouse.x-IB.e.mouse.sx)/zoom);
					var y = (IB.config.screen.sy +(IB.e.mouse.y-IB.e.mouse.sy)/zoom);
					IB.e.move2XY(x, y);
				}
			}
			return false;
		},
	},

	scroll: function(e){
		e.preventDefault();
		var delta = 0;
		if(!event)event = window.event;
		if(event.wheelDelta) {
			// IE and Opera
			delta = event.wheelDelta / 60;
		} else if (event.detail) {
			// W3C
			delta = -event.detail / 2;
		}
		IB.e.zoom(delta);
		return false;
	},


	node:{
		down: function(e, __html){
			e.stopPropagation();
			var node = IB.node.get($(__html).attr('IB_Id'));
			IB.e.node.drag.start(e);
			IB.e.node.select(e, node);
			return false;
		},
		up: function(e, __html){
			e.stopPropagation();
			var node = IB.node.get($(__html).attr('IB_Id'));
			IB.e.node.drag.stop(e);
			IB.e.node.edit.start(e, node);
			IB.e.node.createLink(e, node);
			return false;
		},
		click: function(e, __html){
			var node = IB.node.get($(__html).attr('IB_Id'));
			IB.e.node.clicking = 1;
			window.setTimeout(function(){
				if(IB.e.node.clicking){
					IB.e.node.drag.stop();
					IB.e.node.edit.start();
				}
			}, 500);
			return false;
		},
		dblclick: function(e, __html){
			var node = IB.node.get($(__html).attr('IB_Id'));
			IB.e.node.setCenter(e, __html);
			return false;
		},
		out: function(e, __html){
			var node = IB.node.get($(__html).attr('IB_Id'));
			IB.e.node.startDragLine(e, node);
			return false;
		},
		edit:{
			save:{
				up:function(e){
					IB.e.node.edit.save(e);
				}
			},
			cancel:{
				up:function(){
					IB.e.node.edit.stop(e);
				}
			},
		},
		vote:{
			up:{
				up:function(){
					IB.e.node.vote.up(e);
				}
			},
			down:{
				up:function(){
					IB.e.node.vote.down(e);
				}
			},
		},
	}
};IB.e.node = {
	editing: false,
	dragging: false,
	
	startDragLine: function(e, node){
		if(IB.e.node.dragging){
			if(node.id==IB.e.node._selected.id && !IB.e.node.dragLine){
				//create new node
				var zoom = IB.config.screen.zoom;
				var sw = IB.update.calc((node.whuffie), IB.config.node.strokeWidth);
				sw *= zoom;
				var x1 = node.x*zoom;
				var y1 = node.y*zoom;
				var x2 = IB.e.mouse.x-IB.config.screen.w/2;
				var y2 = IB.e.mouse.y-IB.config.screen.h/2;
				IB.e.node.dragLine = IB._.path('M'+x1+','+y1+'L'+x2+','+y2+'')
					.attr('stroke',IB.config.node.dragLineColor)
					.attr('stroke-width',sw);
				IB.e.node.dragLine.toBack();
			}
		}
	},
	moveDragLine: function(e, node){
		if(IB.e.node.dragging){
			//create new node
			if(IB.e.node.dragLine){
				var zoom = IB.config.screen.zoom;
				var x1 = node.x*zoom;
				var y1 = node.y*zoom;
				var x2 = IB.e.mouse.x-IB.config.screen.w/2-IB.config.screen.x*zoom;
				var y2 = IB.e.mouse.y-IB.config.screen.h/2-IB.config.screen.y*zoom;
				IB.e.node.dragLine.attr('path','M'+x1+','+y1+'L'+x2+','+y2);
			}
		}
	},
	stopDragLine: function(e, node){
		if(IB.e.node.dragLine){
			IB.e.node.dragLine.remove();
			IB.e.node.dragLine = 0;
		}
	},
	createChild: function(e){
		if(IB.e.node.dragging){
			//create new node
			var zoom = IB.config.screen.zoom;
			var x = (IB.e.mouse.x-IB.config.screen.w/2-IB.config.screen.x)/zoom;
			var y = (IB.e.mouse.y-IB.config.screen.h/2-IB.config.screen.y)/zoom;
			IB.node.createChild(IB.e.node._selected, x, y);
			IB.config.screen.x = -x;
			IB.config.screen.y = -y;
		}
		IB.e.node.edit.save();
		IB.e.node.drag.stop(e);
		IB.e.node.unselect();
		IB.e.node.stopDragLine();
	},
	createLink: function(e, child){
		if(IB.e.node.dragging){
			//create new node
			if(IB.e.node._selected.id!=child.id){
				IB.node.createLink(IB.e.node._selected, child);
				IB.e.node.edit.save();
				IB.e.node.drag.stop(e);
				IB.e.node.unselect();
			}
		}
		IB.e.node.stopDragLine();
	},
	setCenter: function(e, __html){
		e.stopPropagation();
		e.preventDefault();
		var node = IB.node.get($(__html).attr('IB_Id'));
		IB.e.node.clicking = 0;
		IB.e.move2XY(-node.x, -node.y);
		return false;
	},
	select: function(e, node){
		e.stopPropagation(e);
		if(IB.e.node._selected != node){
			e.preventDefault();
			IB.e.node.unselect();
			IB.e.node._selected = node;
			IB.e.node._selected._html.addClass('selected');
			IB.e.node._selected._.attr('stroke', IB.config.node.strokeColorEditing);
		}
		return false;
	},
	drag:{
		start: function(e){
			e.preventDefault();
			e.stopPropagation();
			IB.e.node.dragging = 1;
			IB.__html.parent().addClass('creating');
			return false;
		},
		stop: function(e){
			e.preventDefault();
			e.stopPropagation();
			window.setTimeout(function(){
				IB.e.node.dragging = 0;
			}, 100);
			IB.__html.parent().removeClass('creating');
			return false;
		},
	},
	unselect: function(node){
		if(!node)node = IB.e.node._selected;
		IB.e.node.edit.stop();
		if(IB.e.node._selected){
			node._html.removeClass('selected');
			node._.attr('stroke', IB.config.node.strokeColor);
		}
		IB.e.node._selected = null;
	},
	edit:{
		start: function(e){
			if(IB.e.node._selected && !IB.e.node.editing){
				IB.e.node.editing = 1;
				var html = IB.e.node._selected.html;
				IB.e.node._selected._html.find('.textbox').val(html);
				IB.e.node._selected._html.addClass('editing');
				IB.e.node._selected._html.find('.html').hide();
				IB.e.node._selected._html.find('.textbox').focus();
			}
		},
		stop: function(e){
			if(e)e.stopPropagation();
			if(IB.e.node._selected){
				IB.e.node.editing = 0;
				IB.e.node._selected._html.removeClass('editing');
				IB.e.node._selected._html.find('.html').show();
			}
		},
		save: function(e){
			if(IB.e.node._selected){
				IB.e.node.edit.stop();
				var node = IB.e.node._selected;
				var val = node._html.find('.textbox').val();
				IB.action.save(node.id, val, function(success){
					IB.e.node.edit.stop();
					if(success){
						node.html = val;
						node._html.find('.html').html(val);
					}
				});
			}
		},
	},
	vote:{
		up: function(e){
			e.stopPropagation();
			var id = IB.e.node._selected.id;
			IB.action.voteUp(id);
		},
		down: function(e){
			e.stopPropagation();
			var id = IB.e.node._selected.id;
			IB.action.voteDown(id);
		}
	}
};IB.e.node.mouse = {
	down: function(e, __html){
		e.stopPropagation();
		var node = IB.node.get($(__html).attr('IB_Id'));
		IB.e.node.startDragging();
		IB.e.node.select(e, node);
		return false;
	},
	up: function(e, __html){
		e.stopPropagation();
		var node = IB.node.get($(__html).attr('IB_Id'));
		IB.e.node.stopDragging();
		return false;
	},
	click: function(e, __html){
		e.stopPropagation();
		var node = IB.node.get($(__html).attr('IB_Id'));
		IB.e.node.clicking = 1;
		window.setTimeout(function(){
			if(IB.e.node.clicking){
				IB.e.node.stopDragging();
				IB.e.node.startEditing();
			}
		}, 500);
		return false;
	},
	edit:{
		save:{
			up:function(){

			},
			down:function(){
				
			}
		},
		cancel:{
			up:function(){

			},
			down:function(){
				
			}
		},
	},
	vote:{
		up:{
			up:function(){

			},
			down:function(){
				
			}
		},
		down:{
			up:function(){

			},
			down:function(){
				
			}
		},
	},
};[Constructor]
interface WebCLEvent {
    readonly attribute CLenum status;
    readonly attribute WebCLMemoryObject buffer;
    
    any   getInfo(CLenum name);
    any   getProfilingInfo(CLenum name);
    void  setUserEventStatus(CLenum executionStatus);
    void  setCallback(CLenum executionStatus, WebCLCallback notify, optional any userdata);
};//find the shortest path between two nodes

//http://en.wikipedia.org/wiki/Bellman%E2%80%93Ford_algorithm

//as paths(links) can have negative weight(whuffie), we choose the bellman ford algorithm

procedure BellmanFord(list vertices, list edges, vertex source)
   // This implementation takes in a graph, represented as lists of vertices
   // and edges, and modifies the vertices so that their distance and
   // predecessor attributes store the shortest paths.

   // Step 1: initialize graph
   for each vertex v in vertices:
       if v is source then v.distance := 0
       else v.distance := infinity
       v.predecessor := null

   // Step 2: relax edges repeatedly
   for i from 1 to size(vertices)-1:
       for each edge uv in edges: // uv is the edge from u to v
           u := uv.source
           v := uv.destination
           if u.distance + uv.weight < v.distance:
               v.distance := u.distance + uv.weight
               v.predecessor := u

   // Step 3: check for negative-weight cycles
   for each edge uv in edges:
       u := uv.source
       v := uv.destination
       if u.distance + uv.weight < v.distance:
           error "Graph contains a negative-weight cycle"/*All DHT topologies share some variant of the most essential property:
for any key , each node either has a node ID that owns  or has a link to
a node whose node ID is closer to , in terms of the keyspace distance defined
above. It is then easy to route a message to the owner of any key using the
following greedy algorithm (that is not necessarily globally optimal):
at each step, forward the message to the neighbor whose ID is closest to.
When there is no such neighbor, then we must have arrived at the closest node,
which is the owner of  as defined above. This style of routing is sometimes called
key-based routing.*/


//calculate a fractal//present a node to the user containing a flot graph of one of a few types.

//http://code.google.com/p/flot///produce a 256 bit long locality sensitive hash based on the node html.
//http://en.wikipedia.org/wiki/Locality-sensitive_hashing
//this hash is then used for idea gravity and the distributed hash table network.

interface WebCLImage : WebCLMemoryObject {
  WebCLImageDescriptor getInfo();
  GLint getGLtextureInfo(CLenum paramName);
};//take audio input
//run this to add the computer it is run on to infoburp
//as a machine node with varying levels

//0-machine node only
//1-machine node + user interface node - text only
//2-machine node + user interface node - 2d graphical
//3-machine node + user interface node - 3d graphical
//4-machine node + user interface node - 2d graphical + sound out
//5-machine node + user interface node - 3d graphical + video out
//6-machine node + user interface node - 2d graphical + sound in
//7-machine node + user interface node - 3d graphical + video in
//8-machine node + user interface node - 2d graphical + sound in/out
//9-machine node + user interface node - 3d graphical + video in/out

	//loop until crash 
	
	{
		init.infoburp(runlevel)
		kernel.infoburp(runlevel)
	}

	//error handler

	{

	}//initialise
var IB = {
	_: null,
	__: null,
	__html: null,
	_nodes: null,
	_links: null
};



$(document).ready(function(){
	IB.load.self();
}); 
//take keyboard input
//take mouse input//take music as input, for example a midi input port
//infoburp kernel

//manages the interaction of a single machine and user with infoburp as a whole

//loop until user quits or hardware fails if a server only node.

//main kernel loop

kernel.loop ()

	{
		//check connection, connect to infoburp.
			connect.network(infoburp);
		//download node to ram
			download.network(nodes);
		//save node to nodes folder
			save.file(nodes);
		//process node 
			process.node(nodes);
		//save node to nodes folder	
			save.file(nodes);
		//share nodes with infoburp network
			share.network(nodes);
	}
interface WebCLKernel {
    any getInfo(CLenum name);
    any getWorkGroupInfo(WebCLDevice device, CLenum name);
    void setArg(CLuint index, any value, optional CLtype type);
};
//The following enumerated values are available for specifying the type of kernel arguments in setArg. Vector types are specified by bitwise-OR'ing one of the scalar enums with exactly one of the vector enums (VEC2, VEC3, VEC4, VEC8, or VEC16). The special type LOCAL_MEMORY_SIZE is used to allocate memory for local variables.

interface WebCLKernelArgumentTypes {

  // Scalar types; may be bitwise-OR'ed with a vector type

  CLtype CHAR   = 0;
  CLtype UCHAR  = 1;
  CLtype SHORT  = 2;
  CLtype USHORT = 3;
  CLtype INT    = 4;
  CLtype UINT   = 5;
  CLtype LONG   = 6;
  CLtype ULONG  = 7;
  CLtype FLOAT  = 8;
  CLtype HALF   = 9;    // not supported in all implementations
  CLtype DOUBLE = 10;   // not supported in all implementations

  // Vector types; must be bitwise-OR'ed with a scalar type

  CLtype VEC2  = 0x0100;
  CLtype VEC3  = 0x0200;
  CLtype VEC4  = 0x0400;
  CLtype VEC8  = 0x0800;
  CLtype VEC16 = 0x1000;

  // Special types; must not be bitwise-OR'ed with any other type

  CLtype LOCAL_MEMORY_SIZE = 255;
};//define the license that the content of a node is available under

//public domain

//open/free

//closed

//private/encrypted

//unknown



//code defining links//load data - loads nodes, links and bubbles from files on the hard drive and in ram.

	//http://www.w3.org/TR/file-system-api/

//load file from disk

//determine what is stored

//cookies

//file api

	load.file(filename)	
		{
			function useAsyncFS(fs) {
  				// see getAsText example in [FILE-API-ED].
  				fs.root.getFile("filename", null, function (f) {
    				getAsText(f.file());
  										});

  
						}
	requestFileSystem(TEMPORARY, 1024 * 1024, function(fs) {
  	useAsyncFS(fs);
		});

	// In a worker:

		var tempFS = requestFileSystem(TEMPORARY, 1024 * 1024);
		var filename = tempFS.root.getFile("filename", {create: false});
		var writer = filename.createWriter();
		writer.seek(writer.length);
		writeDataToFile(writer);	
		}
//load all nodes from database
IB.load = {
	self:function(){
		IB.__ = $('#infoburp');
		IB.__html = IB.__.find('.html');
		var h = $(window).height();
		var w = $(window).width();
		IB.config.screen.h = h;
		IB.config.screen.w = w;
		IB._ = Raphael('infoburp', w, h);
		IB.e.move2XY(0, 0);
		IB.load.refresh();
	},
	refresh: function(){
		IB._.clear();
		IB.__html.html('');
		IB.load.nodes(function(){
			IB.load.links(function(){
				IB.load.rest();
			});
		});
	},
	nodes: function(CB){
		IB.action.get({
			action:'getNodes'
		}, function(data){
			IB._nodes = data;
			CB();
		});
	},
	links: function(CB){
		IB.action.get({
			action:'getLinks'
		}, function(data){
			IB._links = data;
			CB();
		});
	},
	rest: function(){
		IB.search.load();
		// create nodes and links
	    IB.create.load();
	    // default zoom
		//IB.config.screen.zoom = IB.config.screen.h/(IB.update.calc(IB._nodes.totalWhuffie)/2);
		// begin updating nodes
		IB.update.load();
		//event control
		IB.e.load();
	},
};
//code defining a single location on earth, by latitude and longitude.//login with facebook id

//https://developers.facebook.com/docs/reference/javascript/FB.login/

 FB.login(function(response) {
   if (response.authResponse) {
     console.log('Welcome!  Fetching your information.... ');
     FB.api('/me', function(response) {
       console.log('Good to see you, ' + response.name + '.');
     });
   } else {
     console.log('User cancelled login or did not fully authorize.');
   }
 });
//login with google id
//https://developers.google.com/gdata/docs/js-authsub

 function doLogin(){
    scope = "http://www.google.com/calendar/feeds";
    var token = google.accounts.user.login(scope);
  }
//login with open id
//http://code.google.com/p/openid-selector///login with twitter id
//https://dev.twitter.com/docs/anywhere/welcome#login-signup


 
T.signIn();
    		
//a machine node is a computer attached to infoburp which:

//stores data - stores nodes, links and bubbles as files on the hard drive and in ram.

	//http://www.w3.org/TR/file-system-api/

//performs calculations on data using javascript run on the cpu and gpu.

	//http://www.khronos.org/webcl/

//freely shares all data and calculation results with the rest of infoburp.

	//http://socket.io/#faq

//distributed and decentralised, based on node/link network graph structure.

	//no single point of failure

//rather than being push/pull, data is stored as locally and as redundantly as possible
//and "flows" around the graph to meet spikes in demand for certain content, while
//providing consistant, delay tolerant service, even on poor quality connections.

	//takes as input
	//the address of a few known other machine nodes

machine.node0.address="www.infoburp.com"
machine.node1.address="www.prubofni.com"
machine.node2.address="10.0.0.2"

//checks for succesful connection to network

	network.init();

//once connected, bootstrap process begins

	//download a list of servers you can connect to, and add them to the machine.node list on disk.

		network.get.machine.node(list,disk);

	//download the root node(0) to disk

		network.get.rootnode(disk);

	//download the most popular nodes to disk

		network.get.hotnodes(disk);

	//bootstrap done

	//begin normal operation, store process and communicate to/for the rest of infoburp

		network.server.start(store,process,communicate)

//loop 
	{
	//download an available node from a remote machine.node, that the local machine.node
	//does not already have, and store on the disk.
		network.get.newnode(disk);
	//check if normal node or executable node
		if newnode.type = "1" then 
  			{
			//normal node - store(do nothing)
			}
			{
			//executable node - process then store
			executable.node.run(node,disk);
			}
	//upload an available node from storage to a remote machine.node
		network.upload(disk);
	}
//end loop





//manager.advert.node.js
//manages the number of advert nodes visible to users to ensure profit after
//covering all costs

	//set desired profit per hour in GBP

		profit = 10;

	//get number of users

		usernum = IB.usernum;

	//get click rate

		clickrate = IB.clickrate;

	//get cpc

		cpc = IB.cpc;

	//calculate advertising revenue

		revenue = (usernum * clickrate) * cpc;

	//check costs

		cost = connect.amazon.hosting.get.cost

	//adjust hosting levels (cost), based on total(cost)

		if (cost > revenue)
			{
			//scale down the amazon cloud hosting, making the hosting cost go down
			connect.amazon.hosting.scale.down(1);
			//add an advert node
			advert.google.node.add(1)
			}
		if (revenue > (cost + profit)
			{
			//scale up the amazon cloud hosting, making the site core faster
			connect.amazon.hosting.scale.up(1);
			//remove an advert node
			advert.google.node.remove(1)
			}

	//check for and remove any advert nodes that do not give us revenue.

		check.advert.node();//calculate overall profit/loss

	//profit - advertising

	//profit - sale of whuffie

	//profit - commission

	//loss - programmer wages

	//loss - hosting costs

	//loss - other costs


//manage hosting according to cost and demand

//from different hosts

//infoburp ambient cloud 	- free

//amazon ec2 			- paid

//google compute engine 	- paid

//storm on demand 		- paid (with ssds)

//peer 1 hpc cloud		- paid (with gpus)
//http://www.peer1hosting.co.uk/cloud-hosting/high-performance-cloud-computing/key-features 

//having these different hosts gives us protection if an entire cloud goes down.




//code defining a node which contains a map of a particular part of the world.interface WebCLMemoryObject : Transferable {
  any getInfo(CLenum name);
  WebCLGLObjectInfo getGLObjectInfo();
};//code defining a 3d mesh or model//http://en.wikipedia.org/wiki/Chemical_file_format//music data in a node, for example a midi fileIB.node = {
	// get functions
	get: function(id){
		for(var x in IB._nodes){
			var node = IB._nodes[x];
			if(node.id==id)return node;
		}
	},
	children: function(id){
		var children = [];
		for(var x in IB._links){
			var link = IB._links[x];
			if(link.parent==id){
				children.push(IB.node.get(link.child));
			}
		}
		return children;
	},
	siblings: function(id){
		var siblings = [];
		for(var x in IB._links){
			var link = IB._links[x];
			if(link.parent==id || link.child==id){
				if(link.parent==id)siblings.push(IB.node.get(link.child));
				if(link.child==id)siblings.push(IB.node.get(link.parent));
			}
		}
		return siblings;
	},
	childrenWhuffie: function(id){
		var whuffie = 0;
		for(var x in IB._links){
			var link = IB._links[x];
			if(link.parent==id){
				whuffie += IB.node.get(link.child).whuffie;
			}
		}
		return whuffie;
	},
	totalWhuffie: function(id){
		var node = IB.node.get(id);
		var childrenWhuffie = IB.node.childrenWhuffie(id);
		return node.whuffie+childrenWhuffie;
	},

	//set functions
	updateChildNodePositions: function(node){
		var children = IB.node.children(node.id);
		var totalChildren = children.length;
		var childrenWhuffie = IB.node.childrenWhuffie(node.id);
		var circumference = childrenWhuffie;
		var averageTheta = circumference/totalChildren;
		var diameter = circumference/Math.PI;
		var radius = diameter/2;
		var theta = 0;
		var averageChildRadius = averageTheta/2;
		for(var x in children){
			var child = children[x];
			var childRadius = child.whuffie/2;
			var degrees = (theta/circumference)*360;
			var radians = degrees*(Math.PI/180);
			var childChildrenWhuffieRadius = IB.node.childrenWhuffie(child.id)/2;
			var whuffieRadius = node.whuffie/2;
			var extend = (whuffieRadius+childRadius+childChildrenWhuffieRadius)-averageChildRadius;
			child.x = parseInt(node.x) + (radius+extend)*Math.cos(radians);
			child.y = parseInt(node.y) + (radius+extend)*Math.sin(radians);
			theta += averageTheta;
		}
		IB.action.post({
			id:node.id,
			action:'updateChildNodePositions'
		});
	},
	createChild: function(parent, x, y){
		IB.action.post({
			id:parent.id,
			x:x,
			y:y,
			action:'createChild'
		}, function(data){
			IB.load.refresh();
		});
	},
	createLink: function(parent, child){
		IB.action.post({
			id:parent.id,
			child:child.id,
			action:'createLink'
		}, function(data){
			IB.load.refresh();
		});
	}
};//code for optical character recognition, to read books for example//music output, for example a midi output port
interface WebCLPlatform {
  object getInfo(CLenum name);
  WebCLDevice[] getDevices(CLenum deviceType);
  sequence<DOMString> getSupportedExtensions();
};//play the audio stored in a node

//use jplayer from jplayer.org
//play the video stored inside a node

//use jplayer from jplayer.org//code defining executable nodes

//performs calculations defined by the code content, on linked nodes, and produces
//linked child nodes as output.

//executable nodes contain javascript code inside <script></script> tags.

//they can take input from any connected nodes, and output to any other connected nodes.

//executable nodes enable visual programming on infoburp

//uses webcl
//https://cvs.khronos.org/svn/repos/registry/trunk/public/webcl/spec/latest/index.html


 var run()
	{
	//IB.node.run(node);
	//Select best available processing method, plain js for older browsers,
	//WebCL for modern browsers, and native client to run code in many languages.
		
		if(bestmethod.process.node) = nativeclient	
			{	
				//Creates a nativeclient computing context for execution of code 					//in many languages like c/c++
				//https://developers.google.com/native-client/overview#intro
				var process.node = new nativeclient();
			}
		if(bestmethod.process.node) = webcl
			{
				// Creates a webcl computing context
				var process.node = new WebCL();	
			}	
		if(bestmethod.process.node) = js	
			{	
				//Creates a js computing context
				var process.node = new Js();
			}
		if(bestmethod.process.node) = java	
			{	
				//Creates a java computing context
				var process.node = new Java();
			}
		
	}
interface WebCLProgram {
    any getInfo(CLenum name);

    any getBuildInfo(WebCLDevice device, CLenum name);

    void build(WebCLDevice[] devices, 
               DOMString? options, 
               optional WebCLCallback whenFinished,
               optional any userdata);

    WebCLKernel createKernel(DOMString kernelName);

    WebCLKernel[] createKernelsInProgram();
};//http://en.wikipedia.org/wiki/Quorum_(distributed_computing)

//temporarily store files in client ram, requires no permission and smooths peaks in demand
//as each user accessing data also stores it and provides access to it.

//load a file from ram


//temporarily store files in client ram, requires no permission and smooths peaks in demand
//as each user accessing data also stores it and provides access to it.

//save a file to ram//maintain a routing table of other peersinterface WebCLSampler {
    any getInfo(CLenum name);
};//save data - stores nodes, links and bubbles as files on the hard drive and in ram.

	//http://www.w3.org/TR/file-system-api/

//ask user before storing any data

//store node to disk

//use best available storage method

//cookies

//file api
	save.file(filename)

		{		
			function useAsyncFS(fs) {
 
  				// now we write to the file; see [FILE-WRITER-ED].
  				fs.root.getFile("filename", {create: true}, function (f) {
    				f.createWriter(writeDataToLogFile);
  						});
		}
			requestFileSystem(TEMPORARY, 1024 * 1024, function(fs) {
  		useAsyncFS(fs);
		});

	// In a worker:

		var tempFS = requestFileSystem(TEMPORARY, 1024 * 1024);
		var filename = tempFS.root.getFile("filename", {create: true});
		var writer = filename.createWriter();
		writer.seek(writer.length);
		writeDataToLogFile(writer);
		}



//search functions
//as a user types their query, zoom in on the nearest matching nodes, and highlight them.
//once they press return, zoom to matching node, or create a new node
//containing the search string.

IB.search = {
	__: $('#_search'),

	load: function(){
		IB.search.__ = $('#_search');
		IB.search.__.bind('keyup', function(e){
		//***change this to on press return
		//do a search
			IB.search.do();
		});
		IB.search.__.bind('focus', function(e){
			var value = IB.search.__.val();
			if(value=='search')$(this).val('');
		});
		IB.search.__.bind('blur', function(e){
			var value = IB.search.__.val();
			if(value=='')$(this).val('search');
		});
	},
	do: function(CB){
		if((typeof CB)!='function')CB = function(){};
		var value = IB.search.__.val();
		if(value!=''){
			IB.search.results(value, function(results){
				CB(results);
			});
		}
	},
	results: function(value, CB){
		$.ajax({
			url:'/action/action.php',
			data:{
				action:'search',
				value:value
			},
			success:function(results){
				CB(results);
			}
		})
	}
}//sell whuffie to other users or infoburp for products or services.
//allow a user to broadcast live from a microphone or webcam onto infoburp,
//where their video/audio is stored as a node as it is streamed, and can be watched later.
//support html5 getusermedia, and flash for older browsers.

//Grab the elements

var video = document.getElementsByTagName('video')[0],

heading = document.getElementsByTagName('h1')[0];

//test for getUserMedia

if(navigator.getUserMedia) {

  //setup callbacks

  navigator.getUserMedia('video', successCallback, errorCallback);

 

  //if everything if good then set the source of the video element to the mediastream

  function successCallback( stream ) {

    video.src = stream;

  }

 

  //If everything isn't ok then say so

  function errorCallback( error ) {

    heading.textContent =

        "An error occurred: [CODE " + error.code + "]";

  }

}

else {

  //show no support for getUserMedia

  message.tooltip =

      "Web camera streaming is not supported in this browser!";

}
//code defining text documents like ms word docs, allowing them to be added as nodes.//code defining a physical item//display tooltips in the bottom bar for whatever the mouse is over
//tooltip text is stored in a set of nodes

//take a 2d image as input, and output a transform of this image as a new node.//update the positions of nodes
IB.update = {
	updateInstance: 0,

	load: function(){
		window.setInterval(function(){
			IB.update.nodeDetract();
			IB.update.loop();
			IB.update.view();
			IB.e.keys.map();
		}, 10);
	},
	
    loop: function(){
		for(var x in IB._nodes){
			var node = IB._nodes[x];
			IB.update.linkSpring(node);
			// update nodes
			IB.update.node(node);
			// update nodes html
			IB.update.nodeHtml(node);
		}
		for(var x in IB._links){
			var link = IB._links[x];
			var parent = IB.node.get(link.parent);
			var child = IB.node.get(link.child);
			// update links
			IB.update.link(link, parent, child);
		}
	},

	view: function(){
		var w = IB.config.screen.w;
		var h = IB.config.screen.h;
		var x = IB.config.screen.x;
		var y = IB.config.screen.y;
		var zoom = IB.config.screen.zoom;
		x = (x*zoom)+(w/2);
		y = (y*zoom)+(h/2);
		IB._.setViewBox(-x, -y, w, h);
		IB.__html.css('left', x);
		IB.__html.css('top', y);
	},

	calc: function(i, multiplier){
		if(!multiplier)multiplier = 1;
		return Math.log(i)*multiplier;
	}
};
IB.update.link = function(link, parent, child){
	var zoom = IB.config.screen.zoom;
	var px = parent.x;
	var py = parent.y;
	var x = child.x;
	var y = child.y;
	var sw = IB.update.calc((child.whuffie+parent.whuffie)/2, IB.config.node.strokeWidth);
	sw = sw;
	px *= zoom;
	py *= zoom;
	x *= zoom;
	y *= zoom;
	sw *= zoom;
	link._.attr('path', 'M'+px+','+py+'L'+x+','+y)
		.attr('stroke-width',sw);
}



IB.update.linkSpringOld = function(node){
	if(node.id){
		//run spring
		var sibsVectorX = 0;
		var sibsVectorY = 0;
		var sibs = IB.node.siblings(node.id);
		for(var i in sibs){
			var sib = sibs[i];
			var sVectorX = sib.x - node.x;
			var sVectorY = sib.y - node.y;
			sibsVectorX += sVectorX;
			sibsVectorY += sVectorY;
		}

		var vectorX = sibsVectorX - node.x;
		var vectorY = sibsVectorY - node.y;
		var i = bods.i[node.id];
		var m = bods.mass[i];
		var kg = m*9.8;
		var vx = bods.vel.x[i];
		var vy = bods.vel.y[i];
		var xX = 1;
		var yX = 1;
		//calculate displacement
		//kg·m/s2 = -(kg/s2)*x
		var forceX = -(kg/(vectorX*vectorX))*xX;
		var forceY = -(kg/(vectorY*vectorY))*yX;
		//calculate the effect this force has on the mass of the node
		//Force = Mass * Acceleration 
		//acceleration = force / mass
		var accelerationX = forceX / m
		var accelerationY = forceY / m;
		//and finally add this effect to the x,y of the node
		bods.vel.x[i] += accelerationX;
		bods.vel.y[i] += accelerationY;
	}
}


IB.update.linkSpring = function(node){
	if(node.id){
		// run spring
		var sibs = IB.node.siblings(node.id);
		for(var i in sibs){
			// sibling
			var sib = sibs[i];
			// vector from sibling to node
			var vectorX = sib.x - node.x;
			var vectorY = sib.y - node.y;
			var slope = vectorY/vectorX;
			var magnitude = Math.sqrt(vectorX*vectorX+vectorY*vectorY);
			var radius = 100;
			var exceed = radius - magnitude;
			var i = bods.i[node.id];
			if(magnitude>=radius){
				var siblingIsMovingAwayFromNode = function(){
					var nx = node.x;
					var ny = node.y;
					var sx = sib.x;
					var sy = sib.y;
					var velX = bods.vel.x[i];
					var velY = bods.vel.y[i];
					if((sx>nx) && (sy>ny)){ //quadrant 1
						if(velX>0 && velY>0){
							return true;
						}
					}
					if((sx<nx) && (sy>ny)){ //quadrant 2
						if(velX<0 && velY>0){
							return true;
						}
					}
					if((sx<nx) && (sy<ny)){ //quadrant 3
						if(velX<0 && velY<0){
							return true;
						}
					}
					if((sx>nx) && (sy<ny)){ //quadrant 4
						if(velX<0 && velY<0){
							return true;
						}
					}
					return false;
				}
				if(siblingIsMovingAwayFromNode()){
					var springFactor = .001;
					var friction = 1;
					var velX = bods.vel.x[i];
					var velY = bods.vel.y[i];
					var vel = Math.sqrt(velX*velX+velY*velY);
					var tempSpringX = (bods.vel.x[i]+((vectorX*springFactor*vel)))/friction;
					var tempSpringY = (bods.vel.y[i]+((vectorY*springFactor*vel)))/friction;
					bods.vel.x[i] = tempSpringX;
					bods.vel.y[i] = tempSpringY;
				}
			}
		}
	}
}//................attraction
IB.update.nodeAttract = function(node1, node2){
	var P = IB.config.node.attraction;

	//nodes attract along link lines according to hookes law
	var xpDiff = node2.x-node1.x;
	var ypDiff = node2.y-node1.y;
	var xsign=xpDiff/Math.abs(xpDiff);
	var ysign=ypDiff/Math.abs(ypDiff);
	if (isNaN(xsign)) xsign=1;
	if (isNaN(ysign)) ysign=1;
	
	var Exceed = -(Math.sqrt(xpDiff*xpDiff+ypDiff*ypDiff))*P.attraction*node1.whuffie*node2.whuffie;
	
	var xExceed=xsign*Exceed;
	var yExceed=ysign*Exceed;
	var xpSpeed= P.dumping*(node2.xspeed+xExceed*P.tu);
	var ypSpeed= P.dumping*(node2.yspeed+yExceed*P.tu);
	var xInertion = xpSpeed*P.tu  + parseInt(xsign*xExceed)*P.tu*P.tu/2;
	var yInertion = ypSpeed*P.tu  + parseInt(ysign*yExceed)*P.tu*P.tu/2;
	if (isNaN(xInertion)) xInertion=0;
	if (isNaN(yInertion)) yInertion=0;
	
	node2.x += xInertion ; 
	node2.y += yInertion ; 
	//jiggle the node a bit to avoid stuck nodes
		var rando=Math.floor(Math.random()*5)
		if (rando = 1) node2.x += 1;
		if (rando = 2) node2.x -= 1;
		if (rando = 3) node2.y += 1;
		if (rando = 4) node2.y -= 1;
}
	//nodes repulse all other nodes (coulombs law)
	//bernes-hut optimised implementation
	/*
Copyright (c) 2012, Sameer Ansari - elucidation@gmail.com
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met: 

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer. 
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution. 

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies, 
either expressed or implied, of the FreeBSD Project.
*/
////////////
var DEBUG = 0; // Extra info in console (0=Off,1=Low,2=Absurd, 3=BNtree)
var DEBUGMAX = 5; // Levels of DEBUG

// Reality
// var MINMASS = 1e20;
// var MAXMASS = 1e30;
// var G = 6.673e-11; // Gravitational Constant
// var ETA = 0.01; // Softening constant
// var GFACTOR = 1.3; // Higher means distance has more effect (3 is reality)
// var dt; // Global DT set by html
// var MAXDEPTH = 50; // BN tree max depth ( one less than actual, example with maxdepth = 2, the levels are [0 1 2] )
// var BN_THETA = 0.5;
// var DISTANCE_MULTIPLE = 1e9; // # meters per pixel (ex 1, 1 meter per pixel)
// 1e3 = km, 1e6 = Mm, 1e9 = Gm, 149.60e9 = Au, 9.461e15 = LightYear, 30.857e15 = Parsec
var MINMASS = 1e2;
var MAXMASS = 1e10;
var G = 1e-5; // Gravitational Constant
var ETA = 10; // Softening constant
var GFACTOR = 1.3; // Higher means distance has more effect (3 is reality)

var DISTANCE_MULTIPLE = 2;

var INTERACTION_METHOD = "BN"; // BN or BRUTE, type of tree search to use
var MAXDEPTH = 50; // BN tree max depth ( one less than actual, example with maxdepth = 2, the levels are [0 1 2] )
var BN_THETA = 0.5;

var dt; // Global DT set by html
// Bodies struct containing all bodies
var bods;

//feed nodes into engine

//bods.pos = IB._nodes[x,y]
//bods.vel = IB._nodes[xpSpeed,ypSpeed]
//bods.mass = IB._nodes[(whuffie * -1)]

function resetBodies() {
	if (bods) {
		bods.pos = null;
		bods.vel = null;
		bods.mass = null;
	}

	bods = {pos:{x:new Array(),y:new Array()},
		id:new Array(),
		i:{},
		vel:{x:new Array(),y:new Array()},
		acc:{x:new Array(),y:new Array()},
		mass:new Array(),
		N:0};
}
resetBodies();

// Canvas Context
var c;

// Called by HTML with canvasId passed in
function initBN(canvasId) {
	canvasElement = document.getElementById(canvasId);
	c = canvasElement.getContext("2d");

	resetBodies();

	if (DEBUG) {
		console.log('Initialize BN complete.');
	}
}

function addBody(x,y,vx,vy,m,id) {
	bods.id [bods.N] = id;
	bods.i [id] = bods.N;
	bods.pos.x [bods.N] = x;
	bods.pos.y [bods.N] = y;
	bods.vel.x [bods.N] = vx;
	bods.vel.y [bods.N] = vy;
	bods.acc.x [bods.N] = 0;
	bods.acc.y [bods.N] = 0;
	bods.mass [bods.N] = m;
	bods.N = bods.N + 1;

	if (DEBUG) {
	    console.log("ADD BODY M: ",m," P:",x,",",y," V:",vx,",",vy,",",id);
	}
	if (bods.N >= 100 && DEBUG > 0) {
		setDEBUG(0); // temp check to keep debug off when too many bodies
	}
	if (!sysRunning) {bnBuildTree();}
}
// BN Tree code ------
var bnDepth=0, bnNumNodes=0, bnNumLeafs=0;
function bnSetTreeStats() {
	bnDepth=0, bnNumNodes=0, bnNumLeafs=0;
	bnSetTreeStatsRecurse(bnRoot,0);
}
function bnSetTreeStatsRecurse(node,depth) {
	// If body in node
	bnNumNodes += 1;
	bnDepth = Math.max(depth,bnDepth);

	if ( node.b.length > 0 ) {
		if (node.b != "PARENT") {
			bnNumLeafs += 1;
		}
		// Draw Children
		for (var i=0;i<4;i++){
			var child = node.nodes[i];
			if (child) { bnSetTreeStatsRecurse(child,depth+1) }
		}
	}
}

function bnDeleteTree() {
	if (bnRoot) {bnRoot = bnDeleteNode(bnRoot);}
}
function bnDeleteNode(node) {
	node.b = null;
	node.box = null;
	// For each child
	for (var i=0;i<4;i++) {
		if (node.nodes[i]) { // If child exists
			node.nodes[i] = bnDeleteNode(node.nodes[i]);
		}
	}
	return null;
}

var bnRoot;
function bnBuildTree() {
	bnDeleteTree(bnRoot); // Delete Tree to clear memory
	bnRoot = {b: [], // Body
		leaf:true,
		CoM: null, // center of mass
		nodes:[null,null,null,null],
		// x y x2 y2
		box:[0, 0, IB.config.screen.w, IB.config.screen.h]};

	// Add each body to tree
	for (var i=0;i<bods.N;i++) {
		if (pointInBBOX(bods.pos.x[i],bods.pos.y[i],bnRoot.box)) {
			bnAddBody(bnRoot,i,0);
		}
		else {
			if (DEBUG>=4) {console.log("Body ",i," has left the BNtree area. Not added");}
		}
	}
	if (DEBUG>=2) {
		console.log("BNtree Built: ",bnRoot);
	}
	bnSetTreeStats(); // Update bn tree stats
}

// BBOX = [x y x2 y2]
function pointInBBOX(x,y,BBOX) {
	if (x >= BBOX[0] && x <= BBOX[2] && y >= BBOX[1] && y <= BBOX[3]) {return true;}
	else {return false;}
}

function bnAddBody(node,i,depth) {
	if (DEBUG>=3) {
		console.log("bnAddBody(",node,",",i,",",depth,")");
	}
	// if node has body already
	if ( node.b.length > 0 ) { // not empty
		// Check if hit max depth
		if (depth > MAXDEPTH) {
			if (DEBUG>=3) {console.log('MAX DEPTH B',i);}
			node.b [node.b.length] = i; // Add body to same node since already at max depth
		} 
		else {
			var subBodies;
			if (!node.leaf) { // Same as saying node.b = "PARENT"
				// Node is a parent with children
				subBodies = [i];
			} else {
				// Node is a leaf node (no children), turn to parent
				subBodies = [node.b,i];
			}
			for (var k=0;k<subBodies.length;k++) {
				// Add body to children too		
				var quad = getQuad(subBodies[k],node.box);
				var child = node.nodes[quad];
				if (child) {
					// if quad has child, recurse with child
					bnAddBody(child,subBodies[k],depth+1);
				} else {
					// else add body to child
					node = bnMakeNode(node,quad,subBodies[k]);
				}
			}
			node.b = ["PARENT"];
			node.leaf = false; // Always going to turn into a parent if not already
		}
		// Update center of mass
		node.CoM[1] = (node.CoM[1]*node.CoM[0] + bods.pos.x[i]*bods.mass[i])/(node.CoM[0]+bods.mass[i]);
		node.CoM[2] = (node.CoM[2]*node.CoM[0] + bods.pos.y[i]*bods.mass[i])/(node.CoM[0]+bods.mass[i]);
		node.CoM[0] += bods.mass[i];
	} else { // else if node empty, add body
		node.b = [i];
		node.CoM = [bods.mass[i], bods.pos.x[i],bods.pos.y[i]]; // Center of Mass set to the position of single body
	}
}

function getQuad(i,box) {
	var mx = (box[0]+box[2])/2;
	var my = (box[1]+box[3])/2;
	if (bods.pos.x[i] < mx) { // Left
		if (bods.pos.y[i] < my) {return 0;} // Top
		else {return 2;} // Bottom
	}
	else { // right
		if (bods.pos.y[i] < my) {return 1;} // Top
		else {return 3;} // Bottom}
	}
}

function bnMakeNode(parent,quad,child) {
	if (DEBUG>=3) {
		console.log("bnMakeNode(",parent,",",quad,",",child,")");
	}
	var child = {b:[child],
		leaf:true,
		CoM : [bods.mass[child], bods.pos.x[child],bods.pos.y[child]], // Center of Mass set to the position of single body
		nodes:[null,null,null,null],
		box:[0,0,0,0]};

	switch (quad) {
		case 0: // Top Left
			child.box = [parent.box[0],
				parent.box[1],
				(parent.box[0]+parent.box[2])/2, 
				(parent.box[1]+parent.box[3])/2];
			break;
		case 1: // Top Right
			child.box = [(parent.box[0]+parent.box[2])/2,
				parent.box[1],
				parent.box[2], 
				(parent.box[1]+parent.box[3])/2];
			break;
		case 2: // Bottom Left
			child.box = [parent.box[0],
				(parent.box[1]+parent.box[3])/2,
				(parent.box[0]+parent.box[2])/2, 
				parent.box[3]];
			break;
		case 3: // Bottom Right
			child.box = [(parent.box[0]+parent.box[2])/2,
				(parent.box[1]+parent.box[3])/2,
				parent.box[2], 
				parent.box[3]];
			break;
	}
	parent.nodes[quad] = child;
	return parent;
}

function doBNtree(bI) {
	doBNtreeRecurse(bI,bnRoot);
}
function doBNtreeRecurse(bI,node) {
	if (node.leaf) {
		// If node is a leaf node
		for (var k=0;k<node.b.length;k++) {
			if (bI != node.b[k]) { // Skip self
				setAccel(bI,node.b[k],false);
				numChecks += 1;
			}
		}
	}
	else {
		var s = Math.min( node.box[2]-node.box[0] , node.box[3]-node.box[1] ); // Biggest side of box
		var d = getDist(bods.pos.x[bI],bods.pos.y[bI],
			node.CoM[1],node.CoM[2]);
		if (s/d < BN_THETA) {
			setAccelDirect(bI,node.CoM[0],node.CoM[1],node.CoM[2])
			numChecks += 1;
		}
		else {
			// Recurse for each child
			for (var k=0;k<4;k++) {
				if (node.nodes[k]) {doBNtreeRecurse(bI,node.nodes[k]);}
			}
		}
	}
}

function getDist(x,y,x2,y2) {
	return Math.sqrt(Math.pow(x2-x,2)+Math.pow(y2-y,2));
}

// Update accelerations using BN tree
function forceBNtree() {
	bnBuildTree(); // Build BN tree based on current pos
	numChecks = 0;
	for (var i=0;i<bods.N;i++) {
		// For each body
		doBNtree(i);
	}
}
// ------
// do_Both defaults true: Updates acceleration of bods[j] also (negative of bods[i])

function setAccel(i,j,do_Both) {
	do_Both = typeof(do_Both) != 'undefined' ? do_Both : true;

	// Get Force Vector between bodies i, j
	var F = getForceVec(i,j);

	// a = F/m
	// Body i
	bods.acc.x[i] += F[0]/bods.mass[i];
	bods.acc.y[i] += F[1]/bods.mass[i];

	if (do_Both) {
		// Body j, equal and opposite force
		bods.acc.x[j] -= F[0]/bods.mass[j];
		bods.acc.y[j] -= F[1]/bods.mass[j];
	}
}
function setAccelDirect(i,m,x,y) {
	// Set's accel according to given mass

	// get Force Vector between body i
	// and a virtual mass
	//   with mass m, at position cx,cy
	var F = getForceVecDirect(
		bods.mass[i],bods.pos.x[i],bods.pos.y[i],
		m,x,y);

	// Update acceleration of body
	bods.acc.x[i] += F[0]/bods.mass[i];
	bods.acc.y[i] += F[1]/bods.mass[i];
}

function getForceVec(i,j) {
	if (DEBUG>=10) {
		console.log("B",i," <-> B",j," : ",F);
	}
	return getForceVecDirect(
		bods.mass[i],bods.pos.x[i],bods.pos.y[i],
		bods.mass[j],bods.pos.x[j],bods.pos.y[j]);
}

function getForceVecDirect(m,x,y,m2,x2,y2) {
	// Determines force interaction between
	// bods[i] and bods[j], an adds to bods[i]
	var dx = x2-x;
	var dy = y2-y;
	var r = (getDist(x,y,x2,y2)+ETA) * DISTANCE_MULTIPLE;
	// F_{x|y} = d_{x|y}/r * G*M*m/r.^3;
	var F = G*m*m2/Math.pow(r,GFACTOR);

	return [ F*dx/r , F*dy/r ];
}


// Update accels by checking every body to each other
function forceBrute() {
	numChecks = 0;
	// Brute force O(n^2) comparisons
	for (var i=0;i<bods.N;i++) {
		for (var j=i+1;j<bods.N;j++) {
			setAccel(i,j);
			numChecks += 1;
		}
	}
}


var numChecks;
// Set accelerations of bodies based on gravity
function doForces() {
	// Zero accelerations
	for (var i=0;i<bods.N;i++) {
		bods.acc.x[i]=0;
		bods.acc.y[i]=0;
	}

	// Determine accelerations on all bodies
	switch (INTERACTION_METHOD) {
		case "BRUTE":
			forceBrute();
			break;
		case "BN":
			bnBuildTree(); // REMOVE WHEN doing forceBNtree!
			forceBNtree();
			break;
	}

	if (DEBUG>=2) {
		console.log("# Force Checks: ",numChecks);
	}
}

// Basic update system step by time step dt
var T = 0; // current system time
var dt = 0.01;
var stepTime;
function step() {
	var startTime = (new Date()).getTime();

	// Use integration method to step once by global dt
	leapfrog();

	stepTime = (new Date()).getTime()-startTime;

	T += dt;
	if (DEBUG>=2) {
	    console.log("STEP");
	}
	//if (!sysRunning) {refreshGraphics();} // Refresh graphics if paused
}
function forwardEuler() {
	doForces(); // Set/Update accelerations
	updatePos(dt); // Move full step
	updateVel(dt); // Move Velocities full step
}

function leapfrog() {
	updatePos(0.5*dt); // Move half step
	doForces(); // Set/Update accelerations
	updateVel(dt); // Move Velocities full step
	updatePos(0.5*dt); // Move half step
}

function updatePos(dt_step) {
	// Update body positions based on velocities
	for (var i=0;i<bods.N;i++) {
		var x = bods.vel.x[i]*dt_step;
		var y = bods.vel.y[i]*dt_step;
		bods.pos.x[i] += x;
		bods.pos.y[i] += y;
		var node = IB.node.get(bods.id[i]);
		var x = bods.pos.x[i];
		var y = bods.pos.y[i];
		node.x = x;
		node.y = y;
		
	}
}
function updateVel(dt_step) {
	// Update body velocities based on accelerations
	for (var i=0;i<bods.N;i++) {
		bods.vel.x[i] += bods.acc.x[i]*dt_step;
		bods.vel.y[i] += bods.acc.y[i]*dt_step;
		if(!bods.id[i]){
			bods.vel.x[i] = 0;
			bods.vel.y[i] = 0;
		}
	}
}


var sysTimer;
var sysRunning = false;
function startSys() {
	sysTimer = setInterval(step,10);
	gfxTimer = setInterval(refreshGraphics,1/60.0*1000);
	sysRunning = true;
	if (DEBUG) {
	    console.log("START SYSTEM ",T,"s");
	}
	refreshGraphics();
}
function pauseSys() {
	clearInterval(sysTimer);
	clearInterval(gfxTimer);
	sysRunning = false;
	if (DEBUG) {
	    console.log("STOP SYSTEM ",T,"s");
	}
	refreshGraphics();
}






//................repulsion
IB.update.nodeDetract = function(){
	//var P = IB.config.node.repulsion;
	var startTime = (new Date()).getTime();
	// Use integration method to step once by global dt
	leapfrog();

	stepTime = (new Date()).getTime()-startTime;

	T += dt;
	if (DEBUG>=2) {
	    console.log("STEP");
	}
}


IB.update.nodeDetractLoad = function(node){
	var x = node.x;
	var y = node.y;
	var vx = 0;
	var vy = 0;
	var m = -100000000*node.whuffie;
	var id = node.id;
	addBody(x,y,vx,vy,m,id);
	
}//feed engine output back into nodes

//IB._nodes[x,y] = bods.pos
//IB._nodes[xpSpeed,ypSpeed] = bods.vel

IB.update.node = function(node){ 
	var zoom = IB.config.screen.zoom;
	var x = node.x-node.whuffie/4;
	var y = node.y-node.whuffie/4;
	var w = node.whuffie/2;
	var h = node.whuffie/2;
	var r = (w+h)/4;
	var childrenWhuffie = IB.node.childrenWhuffie(node);
	var children = IB.node.children(node);
	var childrenAverageWhuffie = 1;
	if(children.length)childrenAverageWhuffie = childrenWhuffie/children.length;
	var sw = IB.update.calc(node.whuffie/childrenAverageWhuffie, IB.config.node.strokeWidth);
	x *= zoom;
	y *= zoom;
	w *= zoom;
	h *= zoom;
	r *= zoom;
	sw *= zoom;
	node._.attr('x', x)
		.attr('y', y)
		.attr('width', w)
		.attr('height', h)
		.attr('r', r)
		.attr('stroke-width',sw);
}

IB.update.nodeHtml = function(node){
	var zoom = IB.config.screen.zoom;
	var x = node.x-node.whuffie/4;
	var y = node.y-node.whuffie/4;
	var cw = node.whuffie/2;
	var ch = node.whuffie/2;
	var rw = Math.sqrt(cw*cw/2);
	var rh = Math.sqrt(ch*ch/2);
	var rx = x+(cw-rw)/2;
	var ry = y+(ch-rh)/2;
	var childrenWhuffie = IB.node.childrenWhuffie(node);
	var children = IB.node.children(node);
	var childrenAverageWhuffie = 1;
	if(children.length)childrenAverageWhuffie = childrenWhuffie/children.length;
	var sw = IB.update.calc(node.whuffie/childrenAverageWhuffie, IB.config.node.strokeWidth);
	var fs = '';
	if(node.type=='text')fs = IB.update.calc((Math.pow((node.whuffie/2),2)/node.html.length), IB.config.node.textAdjust);
	var lh = fs/10;
	var lines =(Math.pow((node.whuffie/2),2)%node.html.length);
	lines = (lines>1)?(lines>1):2;
	var pt = (node.whuffie/2-(fs*lines));
	rx *= zoom;
	ry *= zoom;
	rw *= zoom;
	rh *= zoom;
	sw *= zoom;
	fs *= zoom;
	lh *= zoom;
	node._html.css('left', rx)
		.css('top', ry)
		.css('width', rw)
		.css('height', rh)
		.css('font-size', fs);
	node._html.find('.html').css('top', pt);
	node._html.find('.edit').css('borderWidth', sw);
	node._html.find('.vote').css('borderWidth', sw);
}

IB.update.nodePositions = function(node){
	IB.update.updateInstance++;
	IB.update.nodePositionsRecursive();
}
IB.update.nodePositionsRecursive = function(node){
	if(!node)node = IB.node.get(0);
	if(!node.updated || node.updated!=IB.update.updateInstance){
		node.updated = IB.update.updateInstance;
		IB.node.updateChildNodePositions(node);
	}
	var children = IB.node.children(node.id);
	for(var x in children){
		var child = children[x];
		IB.update.nodePositionsRecursive(child);
	}
}


//when I add a node containing 
//<upload:path>
//the file is fetched and uploaded as the node content. if the path is a folder, all files in that path are uploaded.
//possibly use ocupload for this
//code defining a video node, which contains video content only, typically linked to
//it's soundtrack which is in an audio node.
//code for computer vision, recognising objects etc.//code defining whuffie, and it's transfer.;

