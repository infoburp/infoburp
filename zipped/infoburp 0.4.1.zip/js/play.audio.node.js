//play the audio stored in a node

//use jplayer from jplayer.org
