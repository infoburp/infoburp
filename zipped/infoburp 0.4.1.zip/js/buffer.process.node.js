interface WebCLBuffer : WebCLMemoryObject {
  WebCLBuffer createSubBuffer(CLenum flags, CLuint origin, CLuint size);
};