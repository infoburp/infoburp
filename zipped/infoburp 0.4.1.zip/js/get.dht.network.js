//get a specified node, link or bubble from the dht network.

function network.get(address)
	{
	//get data stored at specified address on infoburp network.
	//if data is stored on a server outside infoburp, download it into the infoburp network.
	}