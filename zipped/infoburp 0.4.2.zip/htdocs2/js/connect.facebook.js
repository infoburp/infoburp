//if user logs in with facebook id

//allow them to post any node to their facebook


