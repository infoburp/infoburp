//allow users to comment and upload into nodes from googleplus.com
//after adding the infoburp app to their page