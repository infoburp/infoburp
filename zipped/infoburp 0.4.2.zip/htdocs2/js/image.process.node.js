interface WebCLImage : WebCLMemoryObject {
  WebCLImageDescriptor getInfo();
  GLint getGLtextureInfo(CLenum paramName);
};