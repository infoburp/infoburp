interface WebCLSampler {
    any getInfo(CLenum name);
};