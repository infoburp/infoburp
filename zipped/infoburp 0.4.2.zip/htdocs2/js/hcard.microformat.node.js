//http://microformatshiv.com/constructors.htm

var domNode = document.getElementById('hcard');
var jsonObject = navigator.microformats.get('hCard', domNode);
node.html = JSON.stringify(jsonObject);
