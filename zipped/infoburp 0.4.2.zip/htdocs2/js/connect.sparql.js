//sparql connector

//sparql.js - take a hyperlink to a sparql endpoint in a node

//sparql endpoints automatically connect to other nodes, with a preference for attaching
//to nodes with a lot of whuffie.

//return sparql query results for all attached nodes.

//get input (node html of node linked to endpoint node)

//parse node contents into sparql query


	//*code needed - take endpoint.node.html and node.html as input, parse in a sparql query*


//endpoint.node.html in format 

//"<sparql:endpoint searchin>"

//example:

//endpoint.node.html"<sparql:dbpedia Pages>"

//node.html="city"

//queryStr = "select distinct ?Page where {<city> ?Page}" 



//what we are searching for (node content of node linked to endpoint node)

   	searchfor=selected.node.html

//where we are searching for it (hyperlink to the sparql endpoint)

   	endpoint=endpoint.node.html

//parse query where ?searchin = search for this type of resource

//this returns things that we talk about on infoburp

   	queryStr = "select distinct ?searchin where {<searchfor> ?searchin}" 

//prepare sparql to json query

   	function sparqlQueryJson(queryStr, endpoint, callback, isDebug) {

     	var querypart = "query=" + escape(queryStr);

     // HTTP request object.

     	var xmlhttp = null;

     	if(window.XMLHttpRequest) 	{

       		xmlhttp = new XMLHttpRequest();

    					} 
	else if(window.ActiveXObject) 	{

      // internet exploder support

      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");

    					}
	 else 				{

      	alert('Sorry, you should get a better browser..');

    					}

    // POST with JSON result format.

    	xmlhttp.open('POST', endpoint, true); 

    	xmlhttp.setRequestHeader('Content-type','application/x-www-form-urlencoded');

    	xmlhttp.setRequestHeader("Accept", "application/sparql-results+json");

    // callback to get the response

    	xmlhttp.onreadystatechange = function() {

      	if(xmlhttp.readyState == 4) 	{

        	if(xmlhttp.status == 200) 	{

          		// do with the results

          		if(isDebug) alert(xmlhttp.responseText);

          		callback(xmlhttp.responseText);

        					}
		else 				{

          		// error handler

          		// alert("Sparql query error: " + xmlhttp.status + " "

          		//    + xmlhttp.responseText);

        					}

      					}

    	};

    	// send query

    	xmlhttp.send(querypart);

    	// wait for callback

   	};
        
     		var query = "select * {?s ?p ?o} limit 5" ;

     	// define callback functions

     		function myCallback(str) {

       // convert result to JSON

       		var jsonObj = eval('(' + str + ')');

       // make table of results

       		var result = " <table border='2' cellpadding='9'>" ;

       		for(var i = 0; i<  jsonObj.results.bindings.length; i++) 
					{

         	result += " <tr> <td>" + jsonObj.results.bindings[i].s.value;

         	result += " </td><td>" + jsonObj.results.bindings[i].p.value;

         	result += " </td><td>" + jsonObj.results.bindings[i].o.value;

         	result += " </td></tr>";

       					}

       		result += "</table>" ;

       		document.getElementById("results").innerHTML = result;

    				}

    		// run query

    			sparqlQueryJson(query, endpoint, myCallback, true);

    		//this gives us sparql results in json format to plug into the rest of the code.