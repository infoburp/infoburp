//http://microformatshiv.com/constructors.htm

var domNode = document.getElementById('adr');
var jsonObject = navigator.microformats.get('adr', domNode);
node.html = JSON.stringify(jsonObject);
