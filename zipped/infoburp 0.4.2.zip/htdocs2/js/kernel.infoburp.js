//infoburp kernel

//manages the interaction of a single machine and user with infoburp as a whole

//loop until user quits or hardware fails if a server only node.

//main kernel loop

kernel.loop ()

	{
		//check connection, connect to infoburp.
			connect.network(infoburp);
		//download node to ram
			download.network(nodes);
		//save node to nodes folder
			save.file(nodes);
		//process node 
			process.node(nodes);
		//save node to nodes folder	
			save.file(nodes);
		//share nodes with infoburp network
			share.network(nodes);
	}
