IB.update.link = function(link, parent, child){
	var zoom = IB.config.screen.zoom;
	var px = parent.x;
	var py = parent.y;
	var x = child.x;
	var y = child.y;
	var sw = IB.update.calc((child.whuffie+parent.whuffie)/2, IB.config.node.strokeWidth);
	sw = sw;
	px *= zoom;
	py *= zoom;
	x *= zoom;
	y *= zoom;
	sw *= zoom;
	link._.attr('path', 'M'+px+','+py+'L'+x+','+y)
		.attr('stroke-width',sw);
}




IB.update.linkSpring = function(node){
	if(node.id){
		// run spring
		var sibs = IB.node.siblings(node.id);
		for(var i in sibs){
			// sibling
			var sib = sibs[i];
			// vector from sibling to node
			var vectorX = node.x - sib.x;
			var vectorY = node.y - sib.y;
			if (vectorX<0) vectorX *= -1;
			if (vectorY<0) vectorY *= -1;
			//calculate magnitude
			var magnitude = Math.sqrt((vectorX*vectorX)+(vectorY*vectorY));
			//define variables
			var i = bods.i[node.id];
			var velX = bods.vel.x[i];
			var velY = bods.vel.y[i];
			var vel = Math.sqrt((velX*velX)+(velY*velY));
			var spring = 400;
			var friction = 10;
			var mass = bods.mass[i];
			//hookes law and newtons law (springs with friction)
			
			var velocity = ( ( ( (spring*magnitude) ) + ( ( friction*vel ) *-1 ) ) / mass ) ;
			//calculate slope angle
			var slopeangle = Math.atan(vectorY/vectorX);
			//sohcahtoa
			//cosx = a/h
			var tempSpringX = Math.cos(slopeangle) * velocity;
			//sinx = o/h
			var tempSpringY = Math.sin(slopeangle) * velocity;
			//update node position
			//node.x += tempSpringX;
			//node.y += tempSpringY;
		}
	}
}
