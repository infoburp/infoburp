//login with open id
//http://code.google.com/p/openid-selector/