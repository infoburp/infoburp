//sql connector

//take a node with a mysql endpoint url, a username and a password.

//in the format <mysql:localhost,user:username,pass:password>

var endpoint

var username

var password

//turn it into a mysql endpoint node. run a query for any nodes that are linked
//to this endpoint node.

nodes: function(){
		$.ajax({
			url: 'action/remote.php?action=getAll',
			dataType: 'json',
			method: 'get',
			success:function(data){
				IB._nodes = data;
				IB.search.load();
			    IB.create.load(IB._nodes);
				IB.config.screen.zoom = IB.config.screen.h/(IB.update.calc(IB._nodes.totalWhuffie)/2);
			    // To make nodes spread around central node
			    IB._nodes.x = 0;
				IB._nodes.y = 0;
				IB.update.all();
				IB.event.loadAll();
			}
		});
