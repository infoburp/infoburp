//manage routing over the dht network.
