//load data - loads nodes, links and bubbles from files on the hard drive and in ram.

	//http://www.w3.org/TR/file-system-api/

//load file from disk

//determine what is stored

//cookies

//file api

	load.file(filename)	
		{
			function useAsyncFS(fs) {
  				// see getAsText example in [FILE-API-ED].
  				fs.root.getFile("filename", null, function (f) {
    				getAsText(f.file());
  										});

  
						}
	requestFileSystem(TEMPORARY, 1024 * 1024, function(fs) {
  	useAsyncFS(fs);
		});

	// In a worker:

		var tempFS = requestFileSystem(TEMPORARY, 1024 * 1024);
		var filename = tempFS.root.getFile("filename", {create: false});
		var writer = filename.createWriter();
		writer.seek(writer.length);
		writeDataToFile(writer);	
		}
