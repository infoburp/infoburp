//temporarily store files in client ram, requires no permission and smooths peaks in demand
//as each user accessing data also stores it and provides access to it.

//load a file from ram


