IB.e.mouse = {
	dragging: false,
	x: 0,
	y: 0,
	sx: 0,
	sy: 0,

	_followRegister: [],
	followRegister: function(el){
		IB.e.mouse._followRegister.push(el);
	},
	follow: function(){
		for(var x in IB.e.mouse._followRegister){
			var el = IB.e.mouse._followRegister[x];
			el.css('left', IB.e.mouse.x);
			el.css('top', IB.e.mouse.y);
		}
	},

	down:function(e){
		IB.e.mouse.drag.start(e);
	},
	up:function(e){
		IB.e.mouse.drag.stop(e);
		IB.e.node.createChild(e);
	},
	move:function(e){
		IB.e.mouse.drag.do(e);
		IB.e.mouse.follow();
	},
	dblclick:function(e){
		IB.e.node.setCenter(e);
	},

	drag:{
		start: function(e){
			e.preventDefault();
			IB.e.mouse.dragging = 1;
			var zoom = IB.config.screen.zoom;
			IB.config.screen.sx = IB.config.screen.x;
			IB.config.screen.sy = IB.config.screen.y;
			IB.e.mouse.x = IB.e.mouse.sx = e.pageX;
			IB.e.mouse.y = IB.e.mouse.sy = e.pageY;
			return false;
		},
		stop: function(e){
			e.preventDefault();
			if(IB.e.mouse.dragging){
				var zoom = IB.config.screen.zoom;
				IB.e.mouse.dragging = 0;
				IB.__html.parent().removeClass('dragging');
			}
			return false;
		},
		do: function(e){
			e.preventDefault();
			IB.e.mouse.x = e.pageX;
			IB.e.mouse.y = e.pageY;
			IB.e.node.moveDragLine(e, IB.e.node._selected);
			if(IB.e.mouse.dragging){
				IB.__html.parent().addClass('dragging');
				if(IB.e.mouse.dragging){
				var zoom = IB.config.screen.zoom;
					var x = (IB.config.screen.sx +(IB.e.mouse.x-IB.e.mouse.sx)/zoom);
					var y = (IB.config.screen.sy +(IB.e.mouse.y-IB.e.mouse.sy)/zoom);
					IB.e.move2XY(x, y);
				}
			}
			return false;
		},
	},

	scroll: function(e){
		e.preventDefault();
		var delta = 0;
		if(!event)event = window.event;
		if(event.wheelDelta) {
			// IE and Opera
			delta = event.wheelDelta / 60;
		} else if (event.detail) {
			// W3C
			delta = -event.detail / 2;
		}
		IB.e.zoom(delta);
		return false;
	},


	node:{
		down: function(e, __html){
			e.stopPropagation();
			var node = IB.node.get($(__html).attr('IB_Id'));
			IB.e.node.drag.start(e);
			IB.e.node.select(e, node);
			return false;
		},
		up: function(e, __html){
			e.stopPropagation();
			var node = IB.node.get($(__html).attr('IB_Id'));
			IB.e.node.drag.stop(e);
			IB.e.node.edit.start(e, node);
			IB.e.node.createLink(e, node);
			return false;
		},
		click: function(e, __html){
			var node = IB.node.get($(__html).attr('IB_Id'));
			IB.e.node.clicking = 1;
			window.setTimeout(function(){
				if(IB.e.node.clicking){
					IB.e.node.drag.stop();
					IB.e.node.edit.start();
				}
			}, 500);
			return false;
		},
		dblclick: function(e, __html){
			var node = IB.node.get($(__html).attr('IB_Id'));
			IB.e.node.setCenter(e, __html);
			return false;
		},
		out: function(e, __html){
			var node = IB.node.get($(__html).attr('IB_Id'));
			IB.e.node.startDragLine(e, node);
			return false;
		},
		edit:{
			save:{
				up:function(e){
					IB.e.node.edit.save(e);
				}
			},
			cancel:{
				up:function(){
					IB.e.node.edit.stop(e);
				}
			},
		},
		vote:{
			up:{
				up:function(){
					IB.e.node.vote.up(e);
				}
			},
			down:{
				up:function(){
					IB.e.node.vote.down(e);
				}
			},
		},
	}
};