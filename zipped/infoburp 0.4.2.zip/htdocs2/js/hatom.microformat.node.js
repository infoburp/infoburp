//http://microformatshiv.com/constructors.htm

var domNode = document.getElementById('hatom');
var jsonObject = navigator.microformats.get('hEntry', domNode);
node.html = JSON.stringify(jsonObject);
