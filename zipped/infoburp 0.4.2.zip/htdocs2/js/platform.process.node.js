interface WebCLPlatform {
  object getInfo(CLenum name);
  WebCLDevice[] getDevices(CLenum deviceType);
  sequence<DOMString> getSupportedExtensions();
};