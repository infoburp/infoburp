//http://microformatshiv.com/constructors.htm

var domNode = document.getElementById('xfn');
var jsonObject = navigator.microformats.get('XFN', domNode);
node.html = JSON.stringify(jsonObject);
