//initialise
var IB = {
	_: null,
	__: null,
	__html: null,
	_nodes: null,
	_links: null
};



$(document).ready(function(){
	IB.load.self();
}); 
