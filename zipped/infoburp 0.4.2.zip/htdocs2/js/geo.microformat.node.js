//http://microformatshiv.com/constructors.htm

var domNode = document.getElementById('geo');
var jsonObject = navigator.microformats.get('geo', domNode);
node.html = JSON.stringify(jsonObject);
