////code defining an advert node, which contains an advert, which when clicked by a user
//produces income for infoburp

//advert nodes cannot have children, have the whuffie of the parent node, and cannot
//be voted up or down. this means they can be freely added and removed from the 
//graph as requirements change.


		//amazon product buy advert - commission

		//https://github.com/Exeu/Amazon-ECS-PHP-Library

		//http://petewilliams.info/blog/2009/07/javascript-amazon-associate-link-localiser/
	
		//for example, I add a node a about a book, and the book is 
		//sold to me through amazon.

//set the subject of the advert node (parent node html)
		subject = parent.node.html;

		//spawn an advertising node with a suitable subject for it's parent node
		spawn.advert.amazon.node(subject)
		
			{
			/**
 * Search for any AMAZON product links and replace with a referral link to the visitor's local Amazon site
 * @author Pete Williams
 * @url http://petewilliams.info/blog/2009/07/javascript-amazon-associate-link-localiser/
 * @version 1.7.2
 */
 
/* ENTER YOUR AFFILIATE IDs BELOW - You can leave any blank that you don't have accounts for */
var arrAffiliates = {
	'com'   : '',
	'co.uk'	: '',
	'de'	: '',
	'fr'	: '',
	'ca'	: '',
	'co.jp'	: '',
	'jp'	: '',
	'it'	: '',
	'cn'	: '',
	'es'	: ''
};

// OPTIONAL - if your PHP file is in the same directory as the current page, then leave this as it is. Otherwise insert the path to the file here
var strUrlAjax = 'action/localise.advert.amazon.node.php';

var arrLinksToCheck=[];
var strTld;
var strAffiliateId;

function linkAmazon(objLink,strAsin)
{
this.arrLinkObjects=new Array(objLink);
if(strAsin){this.strAsin=strAsin}
this.affiliateLink=function()
{
for(intLink=0;
intLink<this.arrLinkObjects.length;intLink++)
{this.arrLinkObjects[intLink].href="http://www.amazon."+this.getActualTld()+"/exec/obidos/ASIN/"+this.strAsin+"/"+getAffiliateId(arrTldActual[1])}};
this.searchLink=function()
{
var objRegexTitle=new RegExp("amazon.[a-zA-Z.]{2,5}/([A-Za-z-]*)/dp");
arrResult=objRegexTitle.exec(this.arrLinkObjects[0].href);if(arrResult)
{strTitle=arrResult[1].replace(/-/g,"%20");
this.writeSearchLink(strTitle)
}
else
{
strUrlProduct=strUrlAjax+"?strAction=search&strLink="+this.arrLinkObjects[0].href;
objScript=document.createElement("script");
objScript.src=strUrlProduct;
document.getElementsByTagName("head")[0].appendChild(objScript)}};
this.addLink=function(objLink){this.arrLinkObjects.push(objLink)};
this.writeSearchLink=function(strTitle)
{
for(intSearchLink=0;
intSearchLink<this.arrLinkObjects.length;intSearchLink++)
{
this.arrLinkObjects[intSearchLink].href="http://www.amazon."+strTld+"/s?keywords="+strTitle+"&tag="+strAffiliateId}};
this.getAffiliateUrl=function()
{
return"http://www.amazon."+strTld+"/exec/obidos/ASIN/"+this.strAsin+"/"+strAffiliateId};
this.localiseLink=function()
{
for(i=0;i<this.arrLinkObjects.length;i++)
{
this.arrLinkObjects[i].href=this.getAffiliateUrl()}};
this.getActualTld=function(){var c=new RegExp("amazon.(.*?)/");
arrTldActual=c.exec(this.arrLinkObjects[0].href);
return arrTldActual[1]
}}
function findLocation()
{
if(typeof google!="undefined"&&google.loader.ClientLocation!=null)
{
var strCountry=google.loader.ClientLocation.address.country_code;
checkAmazonLinks(strCountry)}else{objScript=document.createElement("script");
objScript.src="http://freegeoip.net/json/?callback=checkAmazonLinks";
document.getElementsByTagName("head")[0].appendChild(objScript)
}}
function checkAmazonLinks(strCountry)
{
var objRegexAsin=new RegExp("/([A-Z0-9]{10})");
if(strCountry)
{
if(typeof strCountry.country_code!="undefined")
{
strCountry=strCountry.country_code
}
switch(strCountry)
{
case'GB':case'IE':strTld='co.uk';break;case'AT':strTld='de';
break;case'PT':strTld='es';
break;
default:strTld=(arrAffiliates[strCountry.toLowerCase()]!=null?strCountry.toLowerCase():'com');
break}strAffiliateId=getAffiliateId(strTld)
}
var arrLinks=document.getElementsByTagName("a");
for(i=0,j=arrLinks.length;i<j;i++)
{
var intIndex=arrLinks[i].href.toLowerCase().indexOf("amazon.");
if(intIndex>0&&intIndex<arrLinks[i].href.substring(8).indexOf("/")+8&&arrLinks[i].href.indexOf("/review/")<0)
{
var arrResults=objRegexAsin.exec(arrLinks[i].href);
if(arrResults){if(typeof(arrLinksToCheck[arrResults[1]])=="undefined")
{
objLink=new linkAmazon(arrLinks[i],arrResults[1]);
if(strTld&&strTld==objLink.getActualTld())
{
objLink.affiliateLink()
}
else
{
arrLinksToCheck[arrResults[1]]=objLink
}}
else
{
arrLinksToCheck[arrResults[1]].addLink(arrLinks[i])
}}
else
{
var intPreTag=arrLinks[i].href.indexOf("tag=");
if(!strTld){objLink=new linkAmazon(arrLinks[i]);
strTldChecked=objLink.getActualTld()
}
else
{
strTldChecked=strTld
}
if(intPreTag>0)
{
intPreTag+=4;var intPostTag=arrLinks[i].href.substring(intPreTag).indexOf("&");
if(intPostTag<0)
{
intPostTag=arrLinks[i].href.length-intPreTag
}
arrLinks[i].href=arrLinks[i].href.substring(0,intPreTag)+getAffiliateId(strTldChecked)+arrLinks[i].href.substring((intPostTag+intPreTag));
intPath=arrLinks[i].href.indexOf("/",arrLinks[i].href.indexOf("amazon"));
arrLinks[i].href="http://www.amazon."+strTldChecked+arrLinks[i].href.substring(intPath)
}
else
{
intPath=arrLinks[i].href.indexOf("/",arrLinks[i].href.indexOf("amazon"));
arrLinks[i].href=arrLinks[i].href.substring(0,arrLinks[i].href.indexOf("amazon."))+"amazon."+strTldChecked+arrLinks[i].href.substring(intPath)+(arrLinks[i].href.indexOf("?")>0?"&":"?")+"tag="+getAffiliateId(strTldChecked)
}
}
}
}
if(strTld)
{
var strLinksToCheck="";
for(strKey in arrLinksToCheck)
{
if(typeof arrLinksToCheck[strKey].strAsin!="undefined")
{
strLinksToCheck+=arrLinksToCheck[strKey].strAsin+"|"
}
}
if(strLinksToCheck.length)
{
var strUrlAjaxLinks=strUrlAjax+"?strTld="+strTld+"&strAffiliateId="+strAffiliateId+"&strLinks="+strLinksToCheck;
strUrlAjaxLinks=strUrlAjaxLinks.substring(0,strUrlAjaxLinks.length-1);
objScript=document.createElement("script");
objScript.src=strUrlAjaxLinks;
document.getElementsByTagName("head")[0].appendChild(objScript)
}
}
}
function getAffiliateId(strTLD)
{
return(arrAffiliates[strTLD]?arrAffiliates[strTLD]:arrAffiliatesSpares[strTLD])
}
if(window.addEventListener)
{
window.addEventListener("load",findLocation,false)
}
else
{
window.attachEvent("onload",findLocation)
}
var arrAffiliatesSpares={'co.uk':'pcrev05','com':'petewill-20','de':'petewill05-21','fr':'petewill-21','ca':'petewill00-20','co.jp':'petewill-22','jp':'petewill-22','it':'petewill04-21','cn':'petewill-23','es':'petewill0d4-21'};	
			}

