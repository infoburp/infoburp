//create a new node
IB.create = {
	load: function(){
		IB.create.loop();
	},
	loop: function(){
		for(var x in IB._nodes){
			var node = IB._nodes[x];
			IB.create.fixInt(node);
			IB.create.node(node);
			IB.create.nodeHtml(node);
			IB.update.nodeDetractLoad(node);
		}
		for(var x in IB._links){
			var link = IB._links[x];
			IB.create.link(link);
		}
	},
	fixInt: function(node){
		if(!parseInt(node.id)){
			//node.x = 0;
			//node.y = 0;
			node.xspeed = 4;
			node.yspeed = 4;
		} else {
			node.x = parseInt(node.x);
			node.y = parseInt(node.y);
			//node.x = IB.e.mouse.x;
			//node.y = IB.e.mouse.y;

		}
		//node.xspeed = 0;
		//node.yspeed = 0;
		node.whuffie = parseInt(node.whuffie);
		node.id = parseInt(node.id);
	},
	node: function(node){
		if(!node._){
			var w = node.whuffie;
			var h = node.whuffie;
			var o = IB._.rect(node.x, node.y, w, h);
			o.attr('fill',IB.config.node.fillColor)
				.attr('stroke',IB.config.node.strokeColor)
				.attr('stroke-width',IB.config.node.strokeWidth);
			node._ = o;
		}
	},
	nodeHtml: function(node){
		if(!node._html){
			var o = $('<div></div>')
				.addClass('node')
				.attr('IB_Id', node.id)
				.appendTo(IB.__html);
			var html = $('<div></div>')
				.addClass('html')
				.html(node.html)
				.appendTo(o);
			var voteUp = $('<button></button>')
				.addClass('vote')
				.addClass('voteUp')
				.html('')//&#x25B2;
				.appendTo(o);
			var voteDown = $('<button></button>')
				.addClass('vote')
				.addClass('voteDown')
				.html('')//&#x25BC;
				.appendTo(o);
			var editor = $('<div></div>')
				.addClass('editor')
				.appendTo(o);
			var textbox = $('<textarea></textarea>')
				.addClass('textbox')
				.html(node.html)
				.appendTo(editor);
			var editSave = $('<button></button>')
				.addClass('edit')
				.addClass('editSave')
				.html('')//&#x2718;
				.appendTo(editor);
			var editCancel = $('<button></button>')
				.addClass('edit')
				.addClass('editCancel')
				.html('')//&#x2610;
				.appendTo(editor);
			node._html = o;
		}
	},
	link: function(link){
		if(!link._){
			var o = IB._.path('M0,0L0,0');
			o.attr('stroke',IB.config.node.strokeColor)
				.attr('stroke-width',IB.config.node.strokeWidth);
			o.toBack();
			link._ = o;
		}
	},
};
