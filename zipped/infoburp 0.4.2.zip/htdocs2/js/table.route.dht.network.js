//maintain a routing table of other peers

//hard coded master peers

dht.network.peer(www.infoburp.com,www.prubofni.com);

//dynamic peer table + peer discovery




