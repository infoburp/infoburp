//code defining executable nodes

//performs calculations defined by the code content, on linked nodes, and produces
//linked child nodes as output.

//executable nodes contain javascript code inside <script></script> tags.

//they can take input from any connected nodes, and output to any other connected nodes.

//executable nodes enable visual programming on infoburp

//uses webcl
//https://cvs.khronos.org/svn/repos/registry/trunk/public/webcl/spec/latest/index.html


 var run()
	{
	//IB.node.run(node);
	//Select best available processing method, plain js for older browsers,
	//WebCL for modern browsers, and native client to run code in many languages.
		
		if(bestmethod.process.node) = nativeclient	
			{	
				//Creates a nativeclient computing context for execution of code 					//in many languages like c/c++
				//https://developers.google.com/native-client/overview#intro
				var process.node = new nativeclient();
			}
		if(bestmethod.process.node) = webcl
			{
				// Creates a webcl computing context
				var process.node = new WebCL();	
			}	
		if(bestmethod.process.node) = js	
			{	
				//Creates a js computing context
				var process.node = new Js();
			}
		if(bestmethod.process.node) = java	
			{	
				//Creates a java computing context
				var process.node = new Java();
			}
		
	}
