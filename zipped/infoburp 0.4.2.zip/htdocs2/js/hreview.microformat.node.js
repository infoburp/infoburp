//http://microformatshiv.com/constructors.htm

var domNode = document.getElementById('hreview');
var jsonObject = navigator.microformats.get('hReview', domNode);
node.html = JSON.stringify(jsonObject);
