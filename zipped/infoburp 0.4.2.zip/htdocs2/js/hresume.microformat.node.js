//http://microformatshiv.com/constructors.htm

var domNode = document.getElementById('hresume');
var jsonObject = navigator.microformats.get('hResume', domNode);
node.html = JSON.stringify(jsonObject);
