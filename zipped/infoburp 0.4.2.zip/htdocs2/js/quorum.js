//http://en.wikipedia.org/wiki/Quorum_(distributed_computing)

//machine nodes that give good answers earn whuffie. bad answers lose whuffie.

