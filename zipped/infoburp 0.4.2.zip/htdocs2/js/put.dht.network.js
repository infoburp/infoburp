//put a node, link or bubble onto the dht network.

//data is node, link or bubble to be stored.
//address is locality sensitive hash for that data.



function put.dht.network(address,data)
	{
	//put data to the infoburp dht network.
	address = hash.process.node(node.html);
	data = node.html;
	socket.send('address,data,put');
	}

	
