IB.update.node = function(node){ 
	var zoom = IB.config.screen.zoom;
	var x = node.x-node.whuffie/4;
	var y = node.y-node.whuffie/4;
	var w = node.whuffie/2;
	var h = node.whuffie/2;
	var r = (w+h)/4;
	var childrenWhuffie = IB.node.childrenWhuffie(node);
	var children = IB.node.children(node);
	var childrenAverageWhuffie = 1;
	if(children.length)childrenAverageWhuffie = childrenWhuffie/children.length;
	var sw = IB.update.calc(node.whuffie/childrenAverageWhuffie, IB.config.node.strokeWidth);
	x *= zoom;
	y *= zoom;
	w *= zoom;
	h *= zoom;
	r *= zoom;
	sw *= zoom;
	node._.attr('x', x)
		.attr('y', y)
		.attr('width', w)
		.attr('height', h)
		.attr('r', r)
		.attr('stroke-width',sw);
}

IB.update.nodeHtml = function(node){
	var zoom = IB.config.screen.zoom;
	var x = node.x-node.whuffie/4;
	var y = node.y-node.whuffie/4;
	var cw = node.whuffie/2;
	var ch = node.whuffie/2;
	var rw = Math.sqrt(cw*cw/2);
	var rh = Math.sqrt(ch*ch/2);
	var rx = x+(cw-rw)/2;
	var ry = y+(ch-rh)/2;
	var childrenWhuffie = IB.node.childrenWhuffie(node);
	var children = IB.node.children(node);
	var childrenAverageWhuffie = 1;
	if(children.length)childrenAverageWhuffie = childrenWhuffie/children.length;
	var sw = IB.update.calc(node.whuffie/childrenAverageWhuffie, IB.config.node.strokeWidth);
	var fs = '';
	if(node.type=='text')fs = IB.update.calc((Math.pow((node.whuffie/2),2)/node.html.length), IB.config.node.textAdjust);
	var lh = fs/10;
	var lines =(Math.pow((node.whuffie/2),2)%node.html.length);
	lines = (lines>1)?(lines>1):2;
	var pt = (node.whuffie/2-(fs*lines));
	rx *= zoom;
	ry *= zoom;
	rw *= zoom;
	rh *= zoom;
	sw *= zoom;
	fs *= zoom;
	lh *= zoom;
	node._html.css('left', rx)
		.css('top', ry)
		.css('width', rw)
		.css('height', rh)
		.css('font-size', fs);
	node._html.find('.html').css('top', pt);
	node._html.find('.edit').css('borderWidth', sw);
	node._html.find('.vote').css('borderWidth', sw);
}

IB.update.nodePositions = function(node){
	IB.update.updateInstance++;
	IB.update.nodePositionsRecursive();
}
IB.update.nodePositionsRecursive = function(node){
	if(!node)node = IB.node.get(0);
	if(!node.updated || node.updated!=IB.update.updateInstance){
		node.updated = IB.update.updateInstance;
		IB.node.updateChildNodePositions(node);
	}
	var children = IB.node.children(node.id);
	for(var x in children){
		var child = children[x];
		IB.update.nodePositionsRecursive(child);
	}
}


