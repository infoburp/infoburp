//display tooltips in the bottom bar for whatever the mouse is over
//tooltip text is stored in a set of nodes

