//code defining bubbles and the effect they have on nodes
//shown as a circle surrounding a set of related nodes
//if the user zooms out enough, show the bubbles as a euler diagram.
//there is one master bubble, bubble0, which contains all other bubbles
//and by extension all the nodes and links on infoburp.

//bubbles form a type of euler diagram