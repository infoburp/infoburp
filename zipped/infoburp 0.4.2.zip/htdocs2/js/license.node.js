//define the license that the content of a node is available under

//public domain

//open/free

//closed

//private/encrypted

//unknown



