//http://microformatshiv.com/constructors.htm

var domNode = document.getElementById('hcalendar');
var jsonObject = navigator.microformats.get('hCalendar', domNode);
node.html = JSON.stringify(jsonObject);
