//play the video stored inside a node

//use jplayer from jplayer.org