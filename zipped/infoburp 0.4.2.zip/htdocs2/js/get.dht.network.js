//get a specified node, link or bubble from the dht network.

function get.dht.network(address)
	{
	//get data stored at specified address on infoburp network.
	//if data is stored on a server outside infoburp, download it into the infoburp network.

		//send a request for the data
			socket.send('address,data,get');
		//listen for the reply
			socket.on('data', function(msg){
    		// data incoming
			node.html = data;
			});
	}
