/*All DHT topologies share some variant of the most essential property:
for any key , each node either has a node ID that owns  or has a link to
a node whose node ID is closer to , in terms of the keyspace distance defined
above. It is then easy to route a message to the owner of any key using the
following greedy algorithm (that is not necessarily globally optimal):
at each step, forward the message to the neighbor whose ID is closest to.
When there is no such neighbor, then we must have arrived at the closest node,
which is the owner of  as defined above. This style of routing is sometimes called
key-based routing.*/


//when forwarding data, also store it locally in a cache for sharing.

	//listen for incoming data
		socket.on('data', function(msg){
    			// data incoming
			//forward route data on the infoburp dht network.
				address = hash.process.node(data);
				socket.send('address,data,put');
			});
	
